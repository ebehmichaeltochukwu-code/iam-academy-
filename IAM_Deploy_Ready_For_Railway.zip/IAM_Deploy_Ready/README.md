# IAM — Institute of Artist Management

A standalone, Nigeria-first, self-paced online academy. **Not built with Lovable.** Original Python/FastAPI application using SQLite and server-rendered responsive templates.

## Included

- Mobile-ready public website: marketing, syllabus, FAQs, tuition and admissions.
- 8-week professional artist management course (24 original written lessons, 8 case studies, 32 quiz questions, final capstone).
- Third-party YouTube companion embeds for every lesson. **Ten distinct video links are used across 24 lessons**, selected by topic; repetition is intentional. Videos are not owned by IAM, not downloaded, and must be reviewed for embed availability before production launch.
- Student applications with password-protected accounts, pending/approved/rejected decisions, portal status.
- Tuition of ₦100,000 (environment configurable); Paystack initialization and **server-side** verification after keys are supplied. Without keys, online payments stay disabled. Manual bank-payment verification via management console requires staff to independently confirm funds in the real bank account.
- Student progress, 8 quizzes, automatic scoring (75% pass threshold), unlimited retakes, 8 written submissions and staff approval/revisions (final capstone enforces 800–1,500 words).
- Academy-issued PDF completion certificate only when **24 lessons complete + 8 quiz passes + 8 submissions approved**; public certificate verification link.
- Admin: applications, payment ledger, audit records, review of written projects, video companion override editor.
- Responsive light/dark IAM branding using the approved IAM logo with the graduation cap and music note.

## Run locally

```bash
cd iam_academy
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export IAM_APP_SECRET="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"
python manage.py                # you choose a real admin email and password
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000.

## Test

```bash
pip install httpx pytest
python -m pytest -q
```

## Production checklist (mandatory before taking real applicants or payments)

1. Register/clear the IAM name and confirm which educational and business registrations, tax obligations, and data-protection requirements apply in Nigeria. **No accreditation is claimed by this project.** Ask Nigerian counsel to review admissions, refunds, privacy, consumer protection and certificate wording.
2. Deploy behind HTTPS; set `IAM_APP_SECRET` to a random long secret, `IAM_HTTPS=1`, and `IAM_BASE_URL` to the actual HTTPS domain. Store `IAM_DATABASE` in persistent storage with secure backups. SQLite suits pilot use; move to managed PostgreSQL for multi-instance scale.
3. Run `python manage.py` one time in the deployed environment using your private email; **no default admin is shipped**.
4. Provision Paystack secret key securely with the correct business account; complete live-provider callback tests and webhook reconciliation before collecting production payments. Current verification is on authenticated return, **not** a webhook or an end-to-end reconciliation system. A student who closes the browser after paying may require rechecking the payment; build a signed webhook and reconciliation job before production.
5. Add verified admissions contact information, domain email, transactional email delivery (decisions, receipts, password reset), privacy policy, terms of sale, refund policy, cookie notice if needed, bot protection, IP login throttling, backup procedures and monitoring. These are not fully implemented yet.
6. Commission course review from artist managers, producers, entertainment lawyers, and Nigerian rights experts; confirm local copyright/CMO references. Third-party videos may be geo-restricted or have embedding disabled.
7. The 8-week structure is a **recommended learning path**, not a server-enforced minimum elapsed time. Student access begins upon verified tuition; no subscription expiration is applied.
8. Admins can change companion video IDs but not all lesson text through the dashboard; edit `content.py` and redeploy to revise curriculum text or questions.

## Important limits

This is a locally tested application package, **not a deployed public website**. No payment provider account is connected. No email delivery, production monitoring, refunds, fraud screening, invoices, or regulatory accreditation are included. Student completion confirmation is self-attested when marking lessons as complete; only quizzes and practical submissions have additional evaluation. IAM should pilot and strengthen review before offering a credential to paying learners.

## Tech and security summary

- FastAPI/Jinja2 + SQLite, server-side input checks, signed HTTP-only session cookies, per-session CSRF on state-changing forms, scrypt password hashes, role checking on protected routes, server-side payment verification of amount/reference/currency, audit ledger of critical actions, and randomized certificate IDs.
- Pending admin account creation is CLI only; password reset is manual until email integration is built.
- For production, add rate limits, headers/CSP, anti-fraud and full privacy compliance controls and perform independent security review.

## File layout

- `app.py`: web app, auth, workflows, payments, certificates
- `content.py`: original 8-week curriculum and video/source metadata
- `templates/`: page HTML
- `static/`: styling, script, approved IAM image
- `manage.py`: create admin account interactively
- `create_course_reader.py`: regenerate the course review PDF
- `docs/IAM_8_Week_Course_Reader.pdf`: complete owner review copy of the course
- `tests/`: functional tests

## V2: Everything in one IAM website

**All experiences are combined in one application, one hostname and one database.** Public pages, applications, tuition tracking, self-paced learning, assignments, certification and management review do not require separate websites or separate deployments. A single, shared IAM header, approved logo and responsive menu provide consistent navigation throughout.

- **Public experience:** `/` for the homepage and programme journey, `/curriculum` for all modules, `/apply` for admissions.
- **One IAM login:** `/login` authenticates all users. `/portal` automatically opens the student or staff workspace based on permissions.
- **Student workspace:** `/dashboard`, `/lesson/<lesson-id>`, `/quiz/<week>`, assignments, certificate PDF, plus `/course-handbook` for eligible enrolled students.
- **Management workspace:** `/admin`, with applications, payment reviews, assessment grading, student records and video management. Every student row reports lesson, quiz, assignment and certificate progress.
- **Public verification:** `/verify` lets employers or third parties check an IAM-issued certificate ID.

**Only ONE server and ONE domain are required.** URLs above are pages within the same site, not independently deployed websites. The single course-reader PDF is bundled inside the website and delivered from the authenticated student portal. The included ZIP contains the entire deployable IAM application.

### What this does not mean

A single website still contains multiple secure pages. It should **not** expose the management dashboard to visitors or reveal paid course materials before approval and verified payment. IAM has not yet been hosted on a real domain or linked to a live Paystack account; production policy and security work remains as described above.
