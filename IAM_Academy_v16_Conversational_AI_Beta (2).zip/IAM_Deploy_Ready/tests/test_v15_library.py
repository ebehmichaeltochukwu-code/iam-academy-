import json,pathlib
from fastapi.testclient import TestClient
from app import app

root=pathlib.Path(__file__).parents[1]

def test_curated_library_is_usable_and_traces_to_sources():
    library=json.loads((root/'static'/'iam-knowledge-v15.json').read_text())
    assert len(library['topics'])>=40
    assert len(library['sources'])>=20
    sources={s['id']:s for s in library['sources']}
    for topic in library['topics']:
        assert topic['guidance'] and topic['exercise']
        assert topic['source_ids']
        for ref in topic['source_ids']:
            assert ref in sources, (topic['title'],ref)
    for source in sources.values():
        assert source['url'].startswith('https://')

def test_companion_page_and_library_endpoints():
    client=TestClient(app)
    page=client.get('/study-companion')
    assert page.status_code==200
    assert 'IAM AI Study Companion' in page.text
    assert 'iam-ai-v16.js' in page.text
    assert 'Enable real local AI' in page.text
    library=client.get('/static/iam-knowledge-v15.json')
    assert library.status_code==200
    assert library.json()['edition']=='2026-10'
