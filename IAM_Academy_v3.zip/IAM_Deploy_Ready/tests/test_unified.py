"""IAM one-website navigation, authorization, and dashboard tests."""
import re
from fastapi.testclient import TestClient
import app as iam

def login(client,email,password):
    page=client.get('/login').text
    csrf=re.search(r'name="csrf"[^>]*value="([^"]+)"',page).group(1)
    return client.post('/login',data={'csrf':csrf,'email':email,'password':password},follow_redirects=True)

def test_one_site_public_and_protected(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'website.db')
    iam.init_db()
    anonymous=TestClient(iam.app)
    home=anonymous.get('/')
    assert home.status_code==200
    assert 'AN INSTITUTE FOR THE PEOPLE BEHIND THE SOUND' in home.text
    assert 'iam-monogram.webp' in home.text
    assert '<a' in home.text and 'href="/portal"' in home.text
    assert anonymous.get('/portal',follow_redirects=False).headers['location']=='/login'
    assert anonymous.get('/course-handbook',follow_redirects=False).headers['location']=='/login'
    assert anonymous.get('/verify').status_code==200
    assert anonymous.get('/verify?code=IAM-NO-SUCH-CODE',follow_redirects=False).headers['location']=='/verify/IAM-NO-SUCH-CODE'
    with iam.db() as c:
      c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('IAM Admin','admin@example.net',iam.password_hash('SecureAdmin1234!')))
      c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'student','pending','unpaid')",('Nkechi Ude','student@example.net',iam.password_hash('SecureStudent1234!')))
    management=TestClient(iam.app)
    assert 'Management console' in login(management,'admin@example.net','SecureAdmin1234!').text
    assert management.get('/portal',follow_redirects=False).headers['location']=='/admin'
    assert management.get('/course-handbook').content[:4]==b'%PDF'
    student_tab=management.get('/admin?tab=students')
    assert student_tab.status_code==200 and 'Student records' in student_tab.text and 'Nkechi Ude' in student_tab.text
    assert '0 / 24' in student_tab.text
    student=TestClient(iam.app)
    assert 'Under review' in login(student,'student@example.net','SecureStudent1234!').text
    assert student.get('/portal',follow_redirects=False).headers['location']=='/dashboard'
    assert student.get('/course-handbook',follow_redirects=False).headers['location']=='/dashboard'
    with iam.db() as c:
      c.execute("UPDATE users SET application_status='approved',payment_status='paid' WHERE email='student@example.net'")
    content=student.get('/dashboard').text
    assert 'Continue learning' in content
    assert 'href="/lesson/w1l1"' in content
    assert student.get('/course-handbook').content[:4]==b'%PDF'
    assert student.get('/admin',follow_redirects=False).headers['location']=='/login'
    anonymous.close(); management.close(); student.close()
