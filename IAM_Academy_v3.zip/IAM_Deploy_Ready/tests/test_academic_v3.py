import re
from fastapi.testclient import TestClient
import app as iam

def csrf(page):
    return re.search(r'name="csrf"[^>]*value="([^"]+)"',page).group(1)

def test_homepage_and_password_and_admissions(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'academy_v3.db')
    iam.init_db()
    anon=TestClient(iam.app)
    home=anon.get('/')
    assert home.status_code==200
    assert 'data-carousel' in home.text and home.text.count('data-slide')==3
    assert 'academic.css' in home.text
    form=anon.get('/apply')
    assert '8 characters or more' in form.text
    assert not iam.acceptable_student_password('password123')
    assert iam.acceptable_student_password('RiverSong9')
    assert iam.acceptable_student_password('lighthouse54')
    data={'csrf':csrf(form.text),'full_name':'Student Nwosu','email':'nwosu@example.org','password':'RiverSong9','experience':'New to music management','motivation':'I want to study artist management to help independent artists navigate contracts and audiences.'}
    response=anon.post('/apply',data=data,follow_redirects=True)
    assert response.status_code==200 and 'Under review' in response.text
    assert anon.get('/admin',follow_redirects=False).headers['location']=='/login'
    with iam.db() as c:
        c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('IAM Owner','owner@example.org',iam.password_hash('LongSecureStaffPassword2026')))
        c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'reviewer','approved','paid')",('IAM Reviewer','reviewer@example.org',iam.password_hash('LongSecureReviewerPassword2026')))
    staff=TestClient(iam.app)
    login=staff.get('/login')
    staff.post('/login',data={'csrf':csrf(login.text),'email':'owner@example.org','password':'LongSecureStaffPassword2026'})
    applications=staff.get('/admin?tab=applications')
    assert applications.status_code==200 and 'View application' in applications.text
    with iam.db() as c:
        student_id=c.execute('SELECT id FROM users WHERE email=?',('nwosu@example.org',)).fetchone()['id']
    detail=staff.get(f'/admin/applicant/{student_id}')
    assert detail.status_code==200 and 'Student Nwosu' in detail.text
    updated=staff.post(f'/admin/applicant/{student_id}',data={'csrf':csrf(detail.text),'decision':'approved','note':'Motivation clear and readiness suitable.'},follow_redirects=True)
    assert 'Decision history' in updated.text and 'Motivation clear' in updated.text
    with iam.db() as c:
        assert c.execute('SELECT COUNT(*) FROM admissions_reviews WHERE applicant_id=?',(student_id,)).fetchone()[0]==1
    reviewer=TestClient(iam.app)
    page=reviewer.get('/login')
    reviewer.post('/login',data={'csrf':csrf(page.text),'email':'reviewer@example.org','password':'LongSecureReviewerPassword2026'})
    resp=reviewer.post(f'/admin/payment/{student_id}',data={'csrf':csrf(reviewer.get('/admin').text),'reference':'BANKREF1234'})
    assert resp.status_code==403
    assert anon.get('/dashboard').status_code==200
