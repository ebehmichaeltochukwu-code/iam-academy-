"""Vocabulary tooltips across lessons, Module 3 workshops and advanced modules.
All glossary data and logic are local static files; no user-data or grading change.
"""
import json
import re
from pathlib import Path
from fastapi.testclient import TestClient
import app as iam

GL_PATH=Path('static/iam-glossary-v28.json')

def test_curated_definitions_are_unique_beginner_friendly_and_contextual():
    items=json.loads(GL_PATH.read_text())
    assert len(items)>=180
    assert len({x['term'].casefold() for x in items})==len(items)
    allterms={y.casefold() for x in items for y in [x['term'],*x['aliases']]}
    assert len(allterms)==sum(1+len(x['aliases']) for x in items)
    for entry in items:
        assert len(entry['meaning'])>=30 and len(entry['example'])>30
        assert not any(word in entry['meaning'].lower() for word in ('always guaranteed', 'endorse iam academy'))
    for term in ['Artist manager','EPK','ISRC','Master recording','Publishing','Mechanical royalty','Split sheet','Press pitch','Sync licence','Technical rider','Timestamp','A&R','Marketing funnel','Burnout']:
        assert term.casefold() in allterms


def test_server_assets_and_professional_lessons_render_without_removing_earlier_features(monkeypatch,tmp_path):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'v28.db')
    iam.init_db()
    with iam.db() as con:
        con.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('Glossary Administrator','v28@example.com',iam.password_hash('ProfessionalPassword2026!')))
    with TestClient(iam.app) as client:
        login=client.get('/login')
        csrf=re.search(r'name="csrf"[^>]*value="([^"]+)"',login.text).group(1)
        assert client.post('/login',data={'csrf':csrf,'email':'v28@example.com','password':'ProfessionalPassword2026!'},follow_redirects=False).status_code==303
        for path in ['/lesson/'+id for id in iam.LESSONS]+['/module/3/epk','/module/3/timestamps']+['/career/masterclass/'+str(i) for i in range(9,14)]:
            resp=client.get(path)
            assert resp.status_code==200,path
            assert '/static/iam-glossary-v28.js?v=28' in resp.text,path
            assert '/static/iam-glossary-v28.css?v=28' in resp.text,path
        lesson=client.get('/lesson/w4l1').text
        assert 'Read the complete lesson article' in lesson
        assert 'Supplementary videos and artist experiences' in lesson
        assert 'href="/module/3/epk"' in client.get('/lesson/w3l1').text
        assert 'href="/module/3/timestamps"' in client.get('/lesson/w3l1').text
        assert 'How to Create and Use Timestamps as an Artist Manager' in client.get('/module/3/timestamps').text
        assert 'EPK: Create a Professional Artist Press Kit' in client.get('/module/3/epk').text
        assert client.get('/static/iam-glossary-v28.json').status_code==200
        assert client.get('/static/iam-glossary-v28.js').status_code==200
        assert client.get('/static/iam-glossary-v28.css').status_code==200
    assert len(iam.LESSONS)==24
    assert len(iam.WEEKS)==8
    assert len(iam.WEEKS[2]['lessons'])==3


def test_term_glossary_does_not_include_external_ai_calls():
    src=Path('static/iam-glossary-v28.js').read_text()
    assert "fetch('/static/iam-glossary-v28.json'" in src
    assert 'document.createTreeWalker' in src
    assert 'pointerenter' in src
    assert "addEventListener('click'" in src
    assert "e.key==='Escape'" in src
    assert "dialog.showModal" in src
    assert 'navigator.mediaDevices' not in src
    assert 'api.openai.com' not in src
