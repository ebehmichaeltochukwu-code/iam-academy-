"""Paid, standalone Module 3 EPK workshop; does not alter grading or progress."""
import re
from fastapi.testclient import TestClient
import app as iam


def _create_user(monkeypatch, tmp_path, role='student', paid='paid'):
    monkeypatch.setattr(iam, 'DB_PATH', tmp_path / ('epk_'+role+'_'+paid+'.db'))
    iam.init_db()
    with iam.db() as db:
        db.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,?,?,?)",('IAM Learner','iam-epk@example.com',iam.password_hash('StrongIAMpassword123!'),role,'approved',paid))
    client=TestClient(iam.app)
    login=client.get('/login')
    csrf=re.search(r'name="csrf"[^>]*value="([^"]+)"',login.text).group(1)
    response=client.post('/login', data={'csrf':csrf,'email':'iam-epk@example.com','password':'StrongIAMpassword123!'},follow_redirects=False)
    assert response.status_code==303
    return client


def test_epk_route_protected(monkeypatch, tmp_path):
    with TestClient(iam.app) as anonymous:
        assert anonymous.get('/module/3/epk', follow_redirects=False).status_code==303
    with _create_user(monkeypatch,tmp_path,'student','unpaid') as unpaid:
        response=unpaid.get('/module/3/epk',follow_redirects=False)
        assert response.status_code==303
        assert response.headers['location']=='/dashboard'
    with _create_user(monkeypatch,tmp_path,'student','paid') as paid:
        r=paid.get('/module/3/epk')
        assert r.status_code==200
        for snippet in ['Electronic Press Kit','Professional Artist Press Kit','4ZquO8fgcLo','Copy EPK template','Nigerian artist-management case study','Knowledge check']:
            assert snippet in r.text,snippet
        dash=paid.get('/dashboard')
        assert 'Create an Electronic Press Kit (EPK)' in dash.text
        assert 'href="/module/3/epk"' in dash.text
        assert paid.get('/static/v26-epk.css').status_code==200
    with _create_user(monkeypatch,tmp_path,'admin','paid') as admin:
        assert admin.get('/module/3/epk').status_code==200


def test_epk_bonus_preserves_certificate_rules():
    assert len(iam.LESSONS)==24
    assert len(iam.WEEKS)==8
    assert len(iam.WEEKS[2]['lessons'])==3
