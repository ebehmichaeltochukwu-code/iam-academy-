"""IAM module 3 bonus timestamp workshop regression checks."""
import re
from pathlib import Path
from fastapi.testclient import TestClient
import app as iam


def user_session(monkeypatch, tmp_path, role='student', payment='paid', application='approved'):
    monkeypatch.setattr(iam, 'DB_PATH', tmp_path / ('timestamp_'+role+'_'+payment+'_'+application+'.db'))
    iam.init_db()
    with iam.db() as db:
        db.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,?,?,?)", ('Timestamp Learner','timestamp-learner@example.com',iam.password_hash('StrongIAMpassword123!'),role,application,payment))
    client=TestClient(iam.app)
    page=client.get('/login')
    token=re.search(r'name="csrf"[^>]*value="([^"]+)"',page.text).group(1)
    login=client.post('/login',data={'csrf':token,'email':'timestamp-learner@example.com','password':'StrongIAMpassword123!'},follow_redirects=False)
    assert login.status_code==303
    return client


def test_timestamp_workshop_access(monkeypatch,tmp_path):
    with TestClient(iam.app) as anonymous:
        assert anonymous.get('/module/3/timestamps',follow_redirects=False).status_code==303
    with user_session(monkeypatch,tmp_path,'student','unpaid') as unpaid:
        page=unpaid.get('/module/3/timestamps',follow_redirects=False)
        assert page.status_code==303
        assert page.headers['location']=='/dashboard'
    with user_session(monkeypatch,tmp_path,'student','paid','pending') as unapproved:
        assert unapproved.get('/module/3/timestamps',follow_redirects=False).status_code==303
    with user_session(monkeypatch,tmp_path,'student','paid') as student:
        r=student.get('/module/3/timestamps')
        assert r.status_code==200
        for chunk in ['How to Create and Use Timestamps as an Artist Manager',
                      'YouTube Chapter Timestamp Builder','Generate chapter list','Generate share link',
                      'WJ4Vqw9eWFY','00:00','video chapters','approval','Electronic Press Kit']:
            assert chunk.lower() in r.text.lower(),chunk
        dash=student.get('/dashboard')
        assert 'href="/module/3/timestamps"' in dash.text
        assert 'href="/module/3/epk"' in dash.text
        l=student.get('/lesson/3-1')
        assert l.status_code==200
        assert 'href="/module/3/timestamps"' in l.text
        epk=student.get('/module/3/epk')
        assert 'href="/module/3/timestamps"' in epk.text
        assert student.get('/static/v27-timestamps.js').status_code==200
        assert student.get('/static/v27-timestamps.css').status_code==200
    with user_session(monkeypatch,tmp_path,'admin','paid') as admin:
        assert admin.get('/module/3/timestamps').status_code==200
    with user_session(monkeypatch,tmp_path,'reviewer','paid') as reviewer:
        assert reviewer.get('/module/3/timestamps').status_code==200


def test_timestamp_workshop_does_not_touch_grading():
    assert len(iam.LESSONS)==24
    assert len(iam.WEEKS)==8
    assert len(iam.WEEKS[2]['lessons'])==3
    assert any("YouTube chapters" in t for t in [Path('templates/module_timestamps.html').read_text()])


def test_local_only_builder_has_safe_url_validation():
    js=Path('static/v27-timestamps.js').read_text()
    assert "url.protocol!=='https:'" in js
    assert "!/[A-Za-z0-9_-]{11}/" not in js  # avoid accidental unanchored matcher
    assert '/^[A-Za-z0-9_-]{11}$/' in js
    assert '10 seconds' in js
    assert 'navigator.clipboard.writeText' in js
    assert 'fetch(' not in js
