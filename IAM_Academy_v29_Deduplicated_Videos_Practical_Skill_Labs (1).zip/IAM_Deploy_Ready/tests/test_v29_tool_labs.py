"""V29: deduplicated videos and genuine portfolio labs for paid lessons."""
import re
import app as iam
from fastapi.testclient import TestClient
from lesson_media_v29 import primary,extras,check_duplicates
from skill_labs_v29 import LABS,ADVANCED_LABS

def test_no_recycled_core_youtube():
    assert len(LABS)==24
    assert check_duplicates()>=23
    for lid in iam.LESSONS:
        lab=LABS[lid]
        assert len(lab[2])>=5
        assert all(len(s)>32 for s in lab[2])
        assert lab[3]
        assert len({v['id'] for v in extras(lid, primary(lid)[0] if primary(lid) else None)})==len(extras(lid))
    assert set(ADVANCED_LABS)==set(range(9,14))

def test_built_lessons_render(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam.sqlite3');iam.init_db()
    with iam.db() as db:
      db.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('Admin','v29-admin@iam.test',iam.password_hash('StrongPassphrase12345!')))
    with TestClient(iam.app) as client:
      token=re.search(r'name="csrf"[^>]*value="([^"]+)"',client.get('/login').text).group(1)
      response=client.post('/login',data=dict(csrf=token,email='v29-admin@iam.test',password='StrongPassphrase12345!'),follow_redirects=False)
      assert response.status_code==303
      for lid in iam.LESSONS:
        r=client.get('/lesson/'+lid);assert r.status_code==200,lid
        assert 'id="hands-on-skill-lab"' in r.text,lid
        assert 'Official step-by-step documentation' in r.text,lid
        assert 'Read the complete lesson article' in r.text,lid
        assert 'id="supplementary-videos"' in r.text,lid
      for week in range(9,14):
        r=client.get('/career/masterclass/'+str(week));assert r.status_code==200
        assert 'ADVANCED MANAGER WORKSHOP' in r.text
        assert '{{skill_lab' not in r.text
        assert '<title>' in r.text and 'ADVANCED MANAGER WORKSHOP' not in r.text.split('</title>')[0]

def test_paid_content_protected():
  with TestClient(iam.app) as c:
    assert c.get('/lesson/w5l1',follow_redirects=False).status_code==303
    assert c.get('/career/masterclass/10',follow_redirects=False).status_code==303
