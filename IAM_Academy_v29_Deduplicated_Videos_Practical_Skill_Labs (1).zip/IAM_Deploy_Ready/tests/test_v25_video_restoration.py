"""Regression: real supplementary videos render in every paid lesson, while
full reading, permissions and student progress remain intact.
"""
import re
from fastapi.testclient import TestClient
import app as iam
from curated_media_v25 import (select_lesson_video_cards, supplementary_for_advanced,
                                VERIFIED_ARTIST_VIDEOS)


def _admin_client(monkeypatch, tmp_path):
    monkeypatch.setattr(iam, 'DB_PATH', tmp_path / 'v25-private-test.db')
    iam.init_db()
    with iam.db() as d:
        d.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",
                  ('IAM Director','iam-v25-admin@example.com',iam.password_hash('StrongPassphrase12345!')))
    client=TestClient(iam.app)
    csrf=re.search(r'name="csrf"[^>]*value="([^"]+)"',client.get('/login').text).group(1)
    assert client.post('/login',data={'csrf':csrf,'email':'iam-v25-admin@example.com',
                                     'password':'StrongPassphrase12345!'},follow_redirects=False).status_code==303
    return client


def test_all_paid_lessons_have_topic_specific_media():
    assert len(iam.LESSONS)==24
    for lesson_id,(_,lesson) in iam.LESSONS.items():
        cards=select_lesson_video_cards(lesson)
        assert cards, lesson_id
        assert all(card['id'] != iam.VIDEOS[lesson['video_key']][0] for card in cards)
        assert all(card['id']!='g4XcSnJQd78' for card in cards), lesson_id
        assert len({c['id'] for c in cards})==len(cards)
        assert all(c['task'] and c['focus'] and c['url'].startswith('https://www.youtube.com/watch?v=') for c in cards)
    for week in range(9,14):
        assert supplementary_for_advanced(week), week
    assert set(VERIFIED_ARTIST_VIDEOS) == {'davido_team','asa_studio','asa_legacy','burna_identity'}


def test_paid_classroom_renders_both_long_readings_and_supplementary_video(tmp_path,monkeypatch):
    with TestClient(iam.app) as noauth:
        assert noauth.get('/lesson/w2l2',follow_redirects=False).status_code==303
    with _admin_client(monkeypatch,tmp_path) as client:
        for lesson_id in iam.LESSONS:
            response=client.get('/lesson/'+lesson_id)
            assert response.status_code==200
            assert 'Supplementary videos and artist experiences' in response.text,lesson_id
            assert 'id="supplementary-videos"' in response.text,lesson_id
            assert 'Read the complete lesson article' in response.text,lesson_id
            assert 'Official step-by-step documentation' in response.text,lesson_id
            assert 'Step-by-step practice' in response.text,lesson_id
        for week in range(9,14):
            response=client.get('/career/masterclass/'+str(week))
            assert response.status_code==200
            assert 'ADVANCED MANAGER WORKSHOP' in response.text
        assert 'coWfP4ck4lA' in client.get('/lesson/w3l3').text
        assert 'r01o45-CoWY' in client.get('/lesson/w2l3').text
        assert 'Dwo42-7Xjis' in client.get('/lesson/w5l2').text
        assert 'g4XcSnJQd78' not in client.get('/lesson/w5l2').text
        assert client.get('/static/v25-media.css').status_code==200
        assert 'v23-video-viewer.js' in client.get('/lesson/w1l2').text
