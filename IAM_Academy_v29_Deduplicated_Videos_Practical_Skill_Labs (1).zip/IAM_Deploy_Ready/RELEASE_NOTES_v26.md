# IAM Academy Version 26 — Module 3 EPK Workshop

Built on V25. Adds **EPK: Create a Professional Artist Press Kit** as a separate paid-course **bonus practical lesson** for Module 3, Communication, Conflict & Leadership.

## Learning experience
- New student-only `/module/3/epk` route with IAM-admin preview.
- Full IAM-authored reading: EPK purpose; eight core assets; journalist, festival and sponsor versions; approval, source verification and media rights.
- Embedded, publisher-attributed Ditto Music EPK instructional video with an expanded in-platform player and original-publisher fallback.
- Fictional Nigerian emerging-artist case, reusable editable-by-copy outline, eight knowledge check questions, press pitch and portfolio assignment.
- New workshop cards in the enrolled student dashboard, Module 3 lesson pages and public curriculum outline.
- Responsive standalone styling, print-to-PDF option, and direct return to the Module 3 dashboard.

## Non-regression assurances
- The original 24 required lessons and all eight assessed modules are unchanged.
- Module 3 remains three assessed lessons. EPK is additional guided practice; it does not alter certificates, payment or quiz requirements.
- No change to any student database, secrets, private notes or Railway settings.
- 54 automated application tests passed locally, including V24/V25 lesson/video regressions and EPK paid-access checks.

## External learning source
- Ditto Music, How to Make an Electronic Press Kit for YOUR Music, YouTube https://www.youtube.com/watch?v=4ZquO8fgcLo
- Bandzoogle, EPK Guide https://bandzoogle.com/features/epk
- Bandzoogle, EPK Help https://bandzoogle.com/help/articles/379-creating-an-epk

## Deployment
1. Upload the unextracted V26 ZIP to the existing GitHub repository's main branch.
2. Update only the Railway iam-web Custom Start Command to use its new URL and verified SHA256.
3. Commit/apply in production, then verify `IAM_VERSION_26_MODULE_3_EPK_READY`, `/health` HTTP 200, and actual student preview access.
4. Keep the existing /data volume, app secrets and admin settings unchanged.
