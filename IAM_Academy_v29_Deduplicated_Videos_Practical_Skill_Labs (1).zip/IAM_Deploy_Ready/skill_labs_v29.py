"""Original hands-on IAM skill labs. No paid third-party APIs or learner data export."""
from html import escape

# Each set of steps is a practical workflow, not a generic request to 'research'.
LABS={
'w1l1':('Google Docs / role matrix','Map who decides what in an artist career',[
'Create a document named Artist–Manager Responsibilities and insert a table with Decision, Artist, Manager, Specialist and Approval columns.',
'List at least eight decisions including release timing, fees, artwork, passwords, bookings, medical privacy, collaborators and press statements.',
'Mark which decisions the artist retains and which actions the manager may carry out only with written approval.',
'Add the booking agent, accountant and lawyer as distinct roles; do not claim the manager automatically replaces them.',
'Ask a fictional or consenting artist to challenge two assignments, revise the matrix and add a version date.'],'One-page decision and approval matrix'),
'w1l2':('YouTube Studio / permissions register','Protect the artist’s accounts without sharing passwords',[
'Create an access register with Platform, Account Owner, Delegate, Role, Reason, Review Date and Revoked columns.',
'Read YouTube Studio Settings > Permissions in the official guide. Identify the lowest suitable role for an editor.',
'Simulate an invitation to a collaborator using a dummy address; do not invite a real person during practice.',
'Write an approval procedure for changing public artist information and for removing access after a contract ends.',
'Review the register for excess privileges and add a 30-day access review.'],'Artist-account permissions register'),
'w1l3':('Google Sheets / artist intake','Run the first 30 days as a documented discovery project',[
'Open a blank sheet and create tabs labelled Catalogue, Accounts, Agreements, Audience, Money and Open Questions.',
'Enter a fictional artist, three demo songs and a known/unknown status for ownership, metadata and release approvals.',
'Record which audience figures were actually verified and note sources and dates instead of guessing growth.',
'List at least ten interview questions and tag each with Artist, Manager, Lawyer or Accountant as the owner.',
'Prioritise five actions for Days 1–7, 8–14 and 15–30, with written artist sign-off points.'],'30-day intake audit with action owners'),
'w2l1':('Phone audio player / listening sheet','Give evidence-based listening feedback',[
'Choose a song you own or have permission to analyse; listen once without pausing and write the intended mood.',
'Listen a second time and write exact timestamps for the first vocal, first chorus and main hook.',
'Listen a third time for balance, lyrical intelligibility, transitions and a possible replay moment.',
'Separate observable facts from subjective taste in two spreadsheet columns.',
'Write one respectful suggestion, one experiment and one question for the artist before involving the producer.'],'Three-pass listening report'),
'w2l2':('YouTube Chapters / song map','Map a song structure using timestamps',[
'Choose a video uploaded by the artist or a practice clip you can legally review.',
'Play it from the beginning, mark the intro, verse, pre-chorus, chorus, bridge and outro only where they exist.',
'Write mm:ss labels that accurately match the beginning of each section.',
'Compare the first chorus position with the artist’s intended audience experience; do not assume a single genre formula.',
'If preparing YouTube chapters, verify a 00:00 start, three or more chapters and at least ten seconds per chapter.'],'Timestamped song structure map'),
'w2l3':('Shared document / creative notes','Give a producer usable revisions without overstepping',[
'Write a feedback document with Timecode, Observation, Possible Effect, Suggested Test and Artist Decision columns.',
'Using a consenting fictional clip, write two observations that avoid labels such as bad, weak or amateur.',
'Propose one optional test for vocal clarity or the length of the intro without ordering the artist to change it.',
'Specify who evaluates a test mix and who has the creative approval right.',
'Close the request with a target date, a respectful review meeting and a record of the artist’s final choice.'],'Producer-ready creative feedback sheet'),
'w3l1':('Google Docs / decision memo','Prepare a constructive disagreement',[
'Start a decision memo with one shared goal and two legitimate options for an upcoming single release.',
'Ask the artist’s point of view before introducing a sales or scheduling concern.',
'For each option write evidence, benefits, risks, owner and earliest safe decision time.',
'Identify the decision rights agreed in your management relationship.',
'Record the agreed next step in respectful language and schedule a follow-up.'],'Artist-first disagreement decision memo'),
'w3l2':('Incident log / meeting notes','Repair a missed deadline without blaming the artist',[
'Write a fictional case in which a promotional asset was late and a journalist missed an agreed deadline.',
'Separate known facts, unknown facts, impact and urgent corrective actions into four sections.',
'Draft a private Situation–Behaviour–Impact–Request conversation.',
'Agree on responsibility, recovery task, due date and the message to the external partner.',
'Document lessons learned while removing unnecessary personal information from shared notes.'],'Repair plan and factual incident log'),
'w3l3':('Team permissions / escalation plan','Create safe team roles and reporting lines',[
'List an artist team of manager, publicist, producer, booking agent, stage manager and outside counsel.',
'Create a RACI-style table for tour decisions, press interviews, artist consent and safety concerns.',
'Add an immediate escalation path for safeguarding, harassment, threats or emergencies.',
'Draft a least-privilege platform-access policy without requiring anybody to share account passwords.',
'Rehearse how to escalate a fictional report confidentially and respectfully without a public accusation.'],'Team responsibility map and escalation procedure'),
'w4l1':('Rights spreadsheet / split-sheet rehearsal','Separate masters from songs and record writer shares',[
'Create separate sheets for Sound Recordings and Musical Compositions.',
'Enter a fictional track with two songwriters, one featured performer and one producer; record each person’s actual or unknown roles.',
'Use a hypothetical 60/40 composition split and check it totals 100 percent; never assume the master split matches.',
'Mark missing beat licences, samples, recording ownership and written contributor approvals.',
'Prepare a blank split-sheet checklist for the contributors and refer disputed ownership to qualified counsel.'],'Master/composition rights map and draft split register'),
'w4l2':('Metadata and royalty tracker','Reconcile rights data without inventing royalty amounts',[
'Create columns Track, ISRC, ISWC, Writers, Master Owner, Composition Owner, Territory, Source and Verified On.',
'Enter two fictional works and leave unknown identifiers explicitly unknown.',
'Separate earnings statements from actual received cash; note the relevant reporting periods.',
'Check that the US Mechanical Licensing Collective is not assumed to collect every royalty in Nigeria.',
'Make a gap report listing each unknown identifier, likely data owner and evidence required.'],'Royalty and metadata exceptions report'),
'w4l3':('Contract red-flag worksheet','Identify deal issues before seeking legal review',[
'Draft a fictional one-page deal with fee, term, territory, exclusivity, reporting, termination and approval clauses.',
'Underline the clauses that could restrict the artist’s future choices or access to financial records.',
'Add questions about commission base, deductions, recoupment and who owns content created under the deal.',
'Assign each issue a severity and who must answer: artist, manager, accountant or lawyer.',
'Write a neutral legal-brief summary; do not describe your exercise as legal advice.'],'Contract issues brief for qualified review'),
}


LABS.update({
'w5l1':('Spotify for Artists / brand evidence','Review how the artist appears to listeners',[
'Create an artist identity brief with five words that the artist approves, not just what is trending.',
'Open Spotify for Artists or the official walkthrough; locate profile image, biography and artist pick controls as available to your account.',
'List the rights holders or photographers behind the visual assets and ask for documented permission.',
'Compare profile information against YouTube, press kit and approved social handles; note differences and version date.',
'Draft two alternative biographies of 80 and 150 words, and let the artist approve the final voice.'],'Identity and image consistency audit'),
'w5l2':('Spotify for Artists / calendar spreadsheet','Prepare a rights-cleared single release',[
'Make a fictional calendar with columns Date, Task, Owner, Dependency, Approval, Status and Evidence.',
'Enter distributor delivery, artwork review, contributor credits, final master, press pitch and editorial pitch windows.',
'Open Spotify for Artists official editorial pitch guidance; record eligibility and lead-time restrictions, without promising placement.',
'Create three content ideas for pre-release, release day and post-release, each with permission and audience purpose.',
'Put a stop/go checkpoint before publishing: approvals, territories, finances, accessibility and unresolved rights.'],'Multi-platform release readiness calendar'),
'w5l3':('YouTube Studio / analytics comparison','Use real audience evidence, not vanity counts',[
'Locate Content, Reach, Engagement and Audience in YouTube Studio or read the official creator walkthrough.',
'Choose two fictional content posts or real posts you have authority to access; write a source and observation date.',
'Build a sheet listing impressions, click-through rate, viewers, retention and engaged response where available.',
'Write two evidence-based insights and two uncertainties; do not infer individual viewer identity.',
'Schedule one ethical A/B creative test and record what result would cause a change of plan.'],'Audience insights report with experiment'),
'w6l1':('Google Sheets / project budget','Build and reconcile an artist release budget',[
'Create columns Line Item, Approved Budget, Committed Cost, Actual Paid, Receipt, Owner and Variance.',
'Enter eight fictional items, including artwork, studio, publicity, distribution, transport and contingency.',
'Use a spreadsheet formula for variance and total each amount; flag overspends before a new commitment.',
'Separate business costs from personal withdrawals, taxes, commissions and pending receipts.',
'Prepare a one-paragraph variance explanation and approval request for the artist.'],'Release budget and variance report'),
'w6l2':('Event booking / show advance','Advance an artist performance responsibly',[
'Draft a fictional performance enquiry with date, venue, proposed fee, expected travel and audience.',
'Build a technical and hospitality requirements checklist suitable for an artist’s actual production.',
'List stage access, travel, soundcheck, accommodation, emergency contact and show settlement owners.',
'Compare gross guarantee, agent commission and out-of-pocket costs without promising net income.',
'Send a sample written confirmation only after artist approval; add a contingency plan for cancellation.'],'Show advance sheet and performance budget'),
'w6l3':('Vendor bids / comparison table','Choose a vendor using evidence and negotiation',[
'Draft a brief for three fictional photographers with permitted usage, deliverables, dates and budget ceiling.',
'Make a quote table with Price, Portfolio Fit, Rights, Revision Terms, Turnaround and Risks.',
'Ask neutral questions about asset licences, cancellation, deposits and file delivery.',
'Prepare a counteroffer that trades scope or timing instead of making vague payment promises.',
'Document the artist’s selection, agreement and due dates for each milestone.'],'Vendor scorecard and negotiation memo'),
'w7l1':('Partner evaluation / rights map','Assess a label or sponsor offer without rushing',[
'Create a table for two fictional offers with cash, obligations, exclusivity, rights, duration and termination.',
'Identify what each party expects from the artist and what the artist is unwilling to compromise.',
'Mark ambiguous data as unknown and list the evidence required before a decision.',
'Build a red-flag list for ownership, privacy, content approval, spend commitments and reporting.',
'Write an artist-first recommendation and a set of questions for a qualified lawyer or accountant.'],'Partnership comparison and approval memo'),
'w7l2':('Incident response / moderation tools','Respond to a reputational issue without panic',[
'Draft a fictional scenario where an unverified clip about the artist starts spreading.',
'Create columns Claim, Verified Evidence, Risk, Response Owner, Deadline and Publication Approval.',
'Use the official YouTube moderation guide to note available controls, limits and appeal considerations.',
'Draft separate private artist guidance and a short public holding statement that avoids repeating an unverified allegation.',
'Include a wellbeing and safety check, a factual evidence log and a review after 24 hours.'],'Crisis escalation sheet and holding statement'),
'w7l3':('Workload planning / boundaries','Build a sustainable 8-week artist schedule',[
'List a fictional artist’s rehearsal, family, performances, studio and media responsibilities.',
'Ask what recovery, privacy and capacity needs the artist chooses to share voluntarily.',
'Place workload limits and decision checkpoints in an eight-week calendar; avoid guessing any medical needs.',
'Name the trained professional or manager responsible for escalating a genuine welfare concern.',
'Write a plan for reducing or postponing commitments if pressure exceeds the artist’s agreed capacity.'],'Artist-first workload and boundaries plan'),
'w8l1':('Google Sheets / audit tracker','Audit the artist’s business and document exceptions',[
'Make tabs for Agreements, Rights, Catalogue, Audience, Finance, Contacts and Security.',
'Populate a hypothetical example with known items, missing approvals and expired permissions.',
'For each issue specify severity, source evidence, owner, deadline and escalation route.',
'Distinguish urgent safety or rights risks from routine administrative improvements.',
'Prepare a one-page executive summary that avoids unsupported assumptions.'],'Evidence-based artist business audit'),
'w8l2':('Calendar / milestone tracker','Design a realistic 90-day artist development roadmap',[
'Use a template with Goals, Measures, Actions, Owners, Cost, Dependencies, Dates and Review.',
'Choose three measurable outcomes, such as verified catalogue metadata, press readiness and audience retention.',
'Map weekly tasks and set approval gates for budget, rights and creative direction.',
'Add a low-budget alternative and contingency for missed deadlines or changed artist priorities.',
'Rehearse a fortnightly review where the artist can revise priorities without losing the audit trail.'],'90-day implementation roadmap and review schedule'),
'w8l3':('Slides / professional case presentation','Present a recommendation backed by evidence',[
'Create eight concise slides: Artist Goal, Evidence, Audience, Risks, Options, Budget, 90-Day Plan and Decision.',
'For every statistic place a verifiable source and collection date in presenter notes.',
'Add a fictional artist-approved visual identity and ensure photo and music use has permission.',
'Practice a five-minute presentation and ask a peer to challenge assumptions and missing safeguards.',
'Export an accessible PDF, with a one-page decision memo and next follow-up date.'],'Artist-management decision presentation and PDF'),
})
ADVANCED_LABS={
9:('Press interview preparation', 'Create a media briefing with audience, journalist background, artist-approved messages, sensitive topics, schedule and post-interview verification.'),
10:('Artist-led fan engagement', 'Build a four-week content calendar with an approved backstage story, fan question, rehearsal clip, access permissions and moderation plan.'),
11:('Event and tour production', 'Create a show-advance checklist with rider confirmations, staffing, travel approvals, settlement terms and incident contacts.'),
12:('Music administration & rights', 'Build a registration and clearance checklist with master/composition roles, metadata gaps, split approvals, territory and external advice needed.'),
13:('Career and portfolio launch', 'Present an artist-first cross-border growth proposal with verified sources, responsible partners, budget and measurable review points.'),
}

def lesson_lab(lesson_id):
    name,title,steps,deliverable=LABS[lesson_id]
    return {'tool':name,'title':title,'steps':steps,'deliverable':deliverable}

def advanced_lab(week):
    name,task=ADVANCED_LABS[week]
    return {'title':name,'steps':[
        'Define the artist’s specific goal and record all assumptions.',
        'Create an original working document with responsibilities and approval rights.',
        task,
        'Mark unverified information and items requiring legal, financial or technical advice.',
        'Ask the artist to review the deliverable and record the next decision.'],
        'deliverable':'Dated '+name.lower()+' worksheet'}
