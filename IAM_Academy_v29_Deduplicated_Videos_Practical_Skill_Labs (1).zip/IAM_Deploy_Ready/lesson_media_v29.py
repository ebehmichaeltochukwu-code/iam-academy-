"""IAM v29: vetted, nonrepeating lesson-specific YouTube teaching.
IDs come from existing IAM media or public YouTube publisher pages checked 2026-10-21.
"""
from content import VIDEOS
from curated_media_v25 import ARTIST_PERSPECTIVES

CATALOG={**VIDEOS,
 'song':('SDJwg1JoPtY','Every Type of Song Structure Explained','David Bennett Music Theory'),
 'burna':('r01o45-CoWY','Burna Boy: The I Told Them Interview','Apple Music'),
 'asa_business':('V1A8l-OQqSo','Asa Asika: The Art and Business of the African Music Scene','Learnstar'),
 'asa_career':('7dcJrWv_PBs','Asa Asika: Building a Long-Term Music Business','Afropolitan Podcast'),
 'davido':('coWfP4ck4lA','Davido and Tycoone: Their Creative Partnership','Recording Academy / GRAMMYS'),
 'image':('4L9JcHBv-zc','How to Change Your Artist Image','Spotify for Artists'),
 'pitch':('Dwo42-7Xjis','How to Pitch to Playlists','Spotify for Artists'),
 'analytics':('J1t34uTT0iA','Analytics in YouTube Studio','YouTube Creators'),
 'budget':('wGBK7DIORcQ','Step-by-Step Tutorial: Create Your First Budget','Devamsha'),
 'moderation':('OU66myD2XPM','Community Moderation Settings in YouTube Studio','YouTube Creators'),
 'copyright':('VRTfQKWtT4M','Copyright and Content ID Best Practices','YouTube Creators'),
 'upload':('y9Dk6wMc8UM','Upload Videos in YouTube Studio','YouTube Creators'),
 'thumbnail':('YMSx_TuCuKk','Add Custom Thumbnails to YouTube Videos','YouTube Creators'),
 'canvas':('iD0mLVdCmJM','How to Upload Your Spotify Canvas','Spotify for Artists'),
 'comments':('6AcAk5Hnau4','YouTube Comments: Replying, Filtering and Moderating','YouTube Creators'),
 'chapters':('b1Fo_M_tj6w','Add Chapters Using Timestamps','YouTube Creators'),
}
# One primary teaching video per topic. For artist wellbeing, prefer a
# directly relevant artist interview article rather than a mismatched embed.
PRIMARY={
 'w1l1':'manager','w1l2':'manager2','w1l3':'terms',
 'w2l1':'great','w2l2':'song','w2l3':'burna',
 'w3l1':'asa_business','w3l2':'asa_career','w3l3':'davido',
 'w4l1':'rights','w4l2':'royalty','w4l3':'royalty2',
 'w5l1':'image','w5l2':'pitch','w5l3':'analytics',
 'w6l1':'budget','w6l2':'finance','w6l3':'business',
 'w7l1':'career','w7l2':'moderation','w7l3':None,
 'w8l1':'copyright','w8l2':'upload','w8l3':'thumbnail',
}
EXTRAS={
 'w2l2':('chapters','Mark sections by their exact timecodes.','Make a song structure timeline using a song with permission.'),
 'w5l1':('canvas','Connect artwork to the artist’s real identity.','Sketch a visual loop and record the footage permissions.'),
}
ARTICLES={'w5l1':'tems_process','w5l3':'chainsmokers_fans'}
WELLBEING={'title':'Tom Misch on taking a break from touring and returning to music',
 'publisher':'The Guardian (2026)','format':'Artist interview (external reading)',
 'url':'https://www.theguardian.com/music/2026/feb/13/tom-misch-music-interview-new-album-full-circle-sisters-with-me',
 'insight':'Study the artist’s choice to pause. Consider how a manager can adapt commitments and respect privacy.'}

def primary(lesson_id):
    key=PRIMARY[lesson_id]
    return CATALOG[key] if key else None

def extras(lesson_id,primary_id=None):
    row=EXTRAS.get(lesson_id)
    if not row:return []
    key,focus,task=row;vid,title,publisher=CATALOG[key]
    if primary_id==vid:return []
    return [{'id':vid,'title':title,'source':publisher,'focus':focus,'task':task,'url':'https://www.youtube.com/watch?v='+vid}]

def artist_readings(lesson_id):
    if lesson_id=='w7l3':return [WELLBEING]
    key=ARTICLES.get(lesson_id)
    return [ARTIST_PERSPECTIVES[key]] if key else []

def check_duplicates():
    used=[primary(i)[0] for i in PRIMARY if primary(i)]
    used.extend(v['id'] for i in PRIMARY for v in extras(i))
    assert len(used)==len(set(used)),'Duplicate core course video found'
    return len(used)

RESOURCE_BY_LESSON={
 'w1l1':('YouTube channel permissions','https://support.google.com/youtube/answer/9481328'),
 'w1l2':('Manage YouTube channel permissions','https://support.google.com/youtube/answer/9481328'),
 'w1l3':('Get started with Spotify for Artists','https://artists.spotify.com/en/get-started'),
 'w2l1':('Create video chapters','https://support.google.com/youtube/answer/9884579'),
 'w2l2':('YouTube chapters guide','https://support.google.com/youtube/answer/9884579'),
 'w2l3':('Upload and manage YouTube videos','https://support.google.com/youtube/answer/57407'),
 'w3l1':('YouTube channel roles','https://support.google.com/youtube/answer/9481328'),
 'w3l2':('Comment moderation guidance','https://support.google.com/youtube/answer/9482367'),
 'w3l3':('Channel team roles','https://support.google.com/youtube/answer/9481328'),
 'w4l1':('Copyright and Content ID','https://support.google.com/youtube/answer/2797370'),
 'w4l2':('Mechanical Licensing Collective','https://www.themlc.com/'),
 'w4l3':('YouTube copyright claims','https://support.google.com/youtube/answer/2797370'),
 'w5l1':('Spotify for Artists profile','https://artists.spotify.com/en/get-started'),
 'w5l2':('Spotify editorial pitch guidelines','https://support.spotify.com/st-en/artists/article/pitching-music-and-videos-to-playlist-editors/'),
 'w5l3':('YouTube Analytics for Artists','https://artists.youtube.com/resources/analytics-for-artists/'),
 'w6l1':('Google Sheets basics','https://support.google.com/docs/answer/9331169'),
 'w6l2':('YouTube for Artists: going live','https://artists.youtube.com/intl/en_us/resources/going-live/'),
 'w6l3':('Google Sheets basics','https://support.google.com/docs/answer/9331169'),
 'w7l1':('Spotify team member permissions','https://support.spotify.com/us/artists/article/manage-team-members/'),
 'w7l2':('YouTube moderation and comments','https://support.google.com/youtube/answer/9482367'),
 'w7l3':('YouTube artist analytics','https://artists.youtube.com/resources/analytics-for-artists/'),
 'w8l1':('YouTube copyright information','https://support.google.com/youtube/answer/2797370'),
 'w8l2':('Spotify for Artists start guide','https://artists.spotify.com/en/get-started'),
 'w8l3':('YouTube creator thumbnails','https://support.google.com/youtube/answer/72431'),
}
def lesson_resource(lesson_id):
  title,url=RESOURCE_BY_LESSON[lesson_id]
  return {'title':title,'url':url}
