# IAM Academy V28 · In-Lesson Music Industry Terminology

**Goal:** Make every online reading understandable to artists who are new to the business while remaining a serious learning resource for working managers and experienced artists.

## New capability

- **187 curated music and artist-management vocabulary entries**, across 9 industry domains, including common abbreviations and alternate names. Every entry has a plain-English meaning and a practical example.
- **Contextual term markers** appear automatically when a relevant term occurs in the article text of the 24 foundation lessons, professional readers, extended articles, the five advanced module masterclasses, and the Module 3 EPK and Timestamps workshops.
- Hover a dotted term on desktop or **tap it on a phone** to reveal the contextual definition. Keyboard focus and Escape are supported, and markers don't replace normal article content.
- **Searchable A–Z-style full glossary** embedded at the top of each course lesson, searchable by term, alias, category, meaning or example.
- Data stays on IAM's own server and runs in the browser, without paid AI requests, recordings, tracking or external inference.
- In future, new terms may be added by editing `static/iam-glossary-v28.json` and shipping a new package.

## Scope and safeguards

- Only the website reading experience changes. This update does **not** rewrite the downloadable PDFs.
- Existing full-length reading, supplementary videos, artist interviews, course journal, EPK workshop, timestamp workshop, quizzes, admissions, payments, certificate requirements, and database are unchanged.
- Glossary definitions are introductory learning material; for contracts, rights and payments, students must check the rules applicable to their country.
- No new database table, migration, external API or environment variable.

## Verification

- Python test suite: **60 passed**.
- JavaScript syntax: Node `--check` passed.
- Chromium browser smoke: desktop hover, mobile tap, popover content, glossary opening and search passed.
- Deployment: **not automatic**. Upload ZIP to the same GitHub `main` branch and then update the existing Railway service startup command to use V28 with the archive SHA256. Keep `/data` and `IAM_DATABASE` intact.
