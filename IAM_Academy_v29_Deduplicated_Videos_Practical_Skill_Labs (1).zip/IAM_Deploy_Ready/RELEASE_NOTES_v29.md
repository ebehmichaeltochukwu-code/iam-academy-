# IAM Academy V29 — Distinct Videos and Hands-On Tool Labs

## Production intent
Replace repeated, off-topic core teaching videos; keep independent original learning content, student accounts, notes, quiz/certificate access and all previously added workshops.

## What changed
- All 24 core lessons have mapped primary media; 23 have a single distinct YouTube companion, and the wellbeing lesson deliberately uses a pertinent artist interview in reading form rather than a repeated generic video.
- Two supplementary embedded clips add genuinely different technique instruction, rather than reproducing a core video.
- All 24 core lessons include a 5-step detailed practical workflow and portfolio deliverable.
- Advanced Weeks 9–13 include targeted workshops, connected to the original professional course notes.
- Each core lesson has a link to original publisher documentation for the specific tool discussed.
- Existing student notes, payment state, quizzes, role restrictions and database access remain unchanged.
- EPK and timestamp workshops and interactive glossary are carried forward from Version 28.
- Every embedded core video ID is unique across the 24 lessons and their new supplements.
- The existing advanced Spotify duplicate was removed; original IAM-owned captioned scenario videos are preserved.

## Constraints
Public YouTube publishers retain playback control. In-page playback may be restricted by original video owners; original watch links remain available. Interface steps on platforms change; refer students to source documentation. This release does not promise that all externally hosted videos will remain playable.

## Verifiable selected YouTube sources
- Official Spotify for Artists: How to Pitch to Playlists https://www.youtube.com/watch?v=Dwo42-7Xjis
- Official Spotify for Artists: How to Change Your Artist Image https://www.youtube.com/watch?v=4L9JcHBv-zc
- YouTube Creators: Analytics in YouTube Studio https://www.youtube.com/watch?v=J1t34uTT0iA
- YouTube Creators: Community Moderation Settings https://www.youtube.com/watch?v=OU66myD2XPM
- YouTube Creators: Content ID and Copyright https://www.youtube.com/watch?v=VRTfQKWtT4M
- YouTube Creators: Custom Thumbnails https://www.youtube.com/watch?v=YMSx_TuCuKk
- YouTube Creators: How to Add Chapters https://www.youtube.com/watch?v=b1Fo_M_tj6w
- Artist perspective: Davido and Tycoone / GRAMMYS https://www.youtube.com/watch?v=coWfP4ck4lA
- Artist perspective: Asa Asika / Afropolitan https://www.youtube.com/watch?v=7dcJrWv_PBs
- Artist perspective: Burna Boy / Apple Music https://www.youtube.com/watch?v=r01o45-CoWY
- Song structure tutorial / David Bennett Music Theory https://www.youtube.com/watch?v=SDJwg1JoPtY
- Google Sheets budgeting tutorial / Devamsha https://www.youtube.com/watch?v=wGBK7DIORcQ

## Validation
63 application tests passed; compileall passed. No browser-vendor embed test was possible for every YouTube source. Direct student-device playback should be checked after release.

## Deployment and safety
Deploy only to the existing Railway iam-web service and production environment after manual GitHub upload of the ZIP. Keep IAM_DATABASE=/data/iam.db and the existing /data volume unchanged. Do not extract or commit student databases, and do not create another Railway service.
