/* IAM v27: local-only YouTube chapter and timestamp link tools. No network/API calls. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const rows=$('v27-chapter-rows');if(!rows)return;
const msg=$('v27-chapter-status'), output=$('v27-chapter-output'),copy=$('v27-copy-chapters');
const parseTime=value=>{
 const bits=String(value).trim().split(':');
 if(bits.length<2||bits.length>3||bits.some(v=>!/^\d+$/.test(v)))return null;
 const nums=bits.map(Number);if(nums.some(v=>!Number.isSafeInteger(v)))return null;
 if(bits.length===2&&nums[1]>59)return null;
 if(bits.length===3&&(nums[1]>59||nums[2]>59))return null;
 return bits.length===2?nums[0]*60+nums[1]:nums[0]*3600+nums[1]*60+nums[2];
};
const formatTime=seconds=>{const h=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`};
const status=(el,message,state='')=>{el.textContent=message;el.dataset.state=state};
const escapeAttr=s=>String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
const button=$('v27-add-chapter');
function bindRemove(){for(const el of rows.querySelectorAll('.v27-chapter-row')){const remove=el.querySelector('.v27-remove');remove.onclick=()=>{el.remove();copy.disabled=true;output.value='';status(msg,'Row removed. Generate your chapter list again.')}}}
bindRemove();
button.addEventListener('click',()=>{
 if(rows.children.length>=35){status(msg,'For this practice, use 35 chapters or fewer.','error');return}
 const el=document.createElement('div');el.className='v27-chapter-row';
 el.innerHTML='<label>Start time<input type="text" inputmode="text" placeholder="04:30" maxlength="12" aria-label="Chapter start time"></label><label>Chapter title<input type="text" placeholder="Meaningful topic" maxlength="120" aria-label="Chapter title"></label><button type="button" class="v27-remove" aria-label="Remove this chapter">×</button>';
 rows.appendChild(el);bindRemove();el.querySelector('input').focus();copy.disabled=true;
});
$('v27-build-chapters').addEventListener('click',()=>{
 const vals=[...rows.querySelectorAll('.v27-chapter-row')].map(x=>({time:x.querySelectorAll('input')[0].value.trim(),title:x.querySelectorAll('input')[1].value.trim()}));
 output.value='';copy.disabled=true;
 if(vals.length<3){status(msg,'Please add at least three chapters.','error');return}
 const times=vals.map(x=>parseTime(x.time));
 if(times.some(x=>x===null)){status(msg,'Use a valid time such as 00:00, 02:15 or 01:02:15. Seconds must be 00–59.','error');return}
 if(times[0]!==0){status(msg,'The first chapter must begin at 00:00.','error');return}
 for(let i=1;i<times.length;i++){if(times[i]-times[i-1]<10){status(msg,'Each chapter must start at least 10 seconds after the previous chapter. Check chapter '+(i+1)+'.','error');return}}
 if(vals.some(x=>!x.title)){status(msg,'Enter a meaningful title for every chapter.','error');return}
 output.value=vals.map((v,i)=>`${formatTime(times[i])} ${v.title}`).join('\n');copy.disabled=false;status(msg,'Your chapter list meets the basic time-format checks. Make sure the recording is long enough and all titles are accurate.','ok');
});
async function copyText(value,statusEl){try{await navigator.clipboard.writeText(value);status(statusEl,'Copied to clipboard.','ok')}catch(err){status(statusEl,'Select the generated text and copy it manually.','error')}}
copy.addEventListener('click',()=>copyText(output.value,msg));
const vid=$('v27-video-url'),offset=$('v27-offset'),linked=$('v27-share-output'),linkCopy=$('v27-copy-link'),linkMsg=$('v27-link-status');
$('v27-make-link').addEventListener('click',()=>{
 linkCopy.disabled=true;linked.value='';const seconds=parseTime(offset.value);
 if(seconds===null){status(linkMsg,'Enter a valid timestamp, for example 02:15 or 01:20:00.','error');return}
 let url;try{url=new URL(vid.value.trim())}catch(_){status(linkMsg,'Enter a complete YouTube video link beginning with https://.','error');return}
 if(url.protocol!=='https:'){status(linkMsg,'Use a secure HTTPS YouTube URL.','error');return}
 const host=url.hostname.toLowerCase();let id='';
 if(host==='youtu.be')id=url.pathname.split('/')[1]||'';
 else if(host==='youtube.com'||host==='www.youtube.com'||host==='m.youtube.com'||host==='youtube-nocookie.com'||host==='www.youtube-nocookie.com'){
  if(url.pathname==='/watch')id=url.searchParams.get('v')||'';
  else if(/^\/(shorts|live|embed)\//.test(url.pathname))id=url.pathname.split('/')[2]||'';
 }
 if(!/^[A-Za-z0-9_-]{11}$/.test(id)){status(linkMsg,'This link must contain a standard 11-character YouTube video ID.','error');return}
 linked.value=`https://www.youtube.com/watch?v=${id}&t=${seconds}s`;linkCopy.disabled=false;status(linkMsg,'Timestamped YouTube link ready. Open it to confirm the moment is accurate.','ok');
});
linkCopy.addEventListener('click',()=>copyText(linked.value,linkMsg));
const dialog=$('v27-video-dialog'),expand=$('v27-expand-video'),close=$('v27-close-video');
if(dialog&&expand&&close){const frame=dialog.querySelector('iframe');expand.addEventListener('click',()=>{frame.src='https://www.youtube-nocookie.com/embed/WJ4Vqw9eWFY?playsinline=1&rel=0';if(dialog.showModal)dialog.showModal();else dialog.setAttribute('open','')});close.addEventListener('click',()=>dialog.close());dialog.addEventListener('close',()=>{frame.src='about:blank'});dialog.addEventListener('cancel',()=>{frame.src='about:blank'})}
})();
