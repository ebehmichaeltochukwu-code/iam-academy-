/* IAM Academy v28: free, in-browser, contextual music-industry terminology support. */
(()=>{'use strict';
const root=document.querySelector('.lesson-main, .v26-grid > article, .v10-classroom, .reflection-content');
if(!root)return;
const excluded='a,button,input,textarea,select,script,style,code,pre,summary,label,.v28-glossary-ui,.v27-timestamp-tool,[contenteditable],[hidden]';
const popup=document.createElement('div');popup.className='v28-glossary-popup';popup.id='v28-glossary-tooltip';popup.setAttribute('role','tooltip');popup.hidden=true;
popup.innerHTML='<span class="v28-category"></span><strong class="v28-title"></strong><p class="v28-meaning"></p><p class="v28-example"></p><small>Tap elsewhere or press Escape to close</small>';
document.body.append(popup);
let active=null,pinned=false;
function closeTip(){if(active)active.setAttribute('aria-expanded','false');active=null;pinned=false;popup.hidden=true;}
function reposition(btn){const rect=btn.getBoundingClientRect(),width=Math.min(innerWidth-24,380);popup.style.width=width+'px';popup.style.left=Math.max(12,Math.min(innerWidth-width-12,rect.left))+'px';popup.style.top='12px';const height=popup.getBoundingClientRect().height,above=rect.top-height-10,below=rect.bottom+10;popup.style.top=(below+height<innerHeight-10?below:above>=10?above:Math.max(10,innerHeight-height-10))+'px';}
function showTip(btn,item,lock){if(active&&active!==btn)active.setAttribute('aria-expanded','false');active=btn;pinned=lock;popup.querySelector('.v28-category').textContent=item.category;popup.querySelector('.v28-title').textContent=item.term;popup.querySelector('.v28-meaning').textContent=item.meaning;popup.querySelector('.v28-example').textContent='Example: '+item.example;popup.hidden=false;btn.setAttribute('aria-expanded','true');reposition(btn);}
function termButton(text,item){const btn=document.createElement('button');btn.type='button';btn.className='v28-term';btn.textContent=text;btn.setAttribute('aria-label',text+': show music-industry definition');btn.setAttribute('aria-describedby','v28-glossary-tooltip');btn.setAttribute('aria-expanded','false');
btn.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse'&&!pinned)showTip(btn,item,false)});
btn.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'&&!pinned&&active===btn)closeTip()});
btn.addEventListener('focus',()=>{if(!pinned)showTip(btn,item,false)});
btn.addEventListener('blur',()=>{if(!pinned&&active===btn)closeTip()});
btn.addEventListener('click',()=>{if(active===btn&&pinned)closeTip();else showTip(btn,item,true)});
return btn;}
document.addEventListener('pointerdown',e=>{if(!popup.hidden&&!e.target.closest('.v28-term')&&!popup.contains(e.target))closeTip()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeTip()});
window.addEventListener('scroll',()=>{if(!popup.hidden)closeTip()},{passive:true,capture:true});
window.addEventListener('resize',()=>{if(active&&!popup.hidden)reposition(active)},{passive:true});
function annotate(entries){let total=0;const termLookup=new Map(),unique=[];for(const entry of entries)for(const word of [entry.term,...entry.aliases]){if(!termLookup.has(word.toLowerCase())){termLookup.set(word.toLowerCase(),entry);unique.push(word)}}
unique.sort((a,b)=>b.length-a.length);const escapeRE=x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const re=new RegExp('(?<![A-Za-z0-9])(?:'+unique.map(escapeRE).join('|')+')(?![A-Za-z0-9])','gi');
const seen=new Map();for(const paragraph of root.querySelectorAll('p,li')){if(paragraph.closest(excluded)||paragraph.closest('.v13-video-grid,.v25-supplementary,.v26-video-wrap,.v27-definition-grid'))continue;
let count=0;const walker=document.createTreeWalker(paragraph,NodeFilter.SHOW_TEXT);const textNodes=[];while(walker.nextNode())textNodes.push(walker.currentNode);
for(const node of textNodes){if(count>=4)break;if(!node.parentElement||node.parentElement.closest(excluded)||!node.nodeValue||node.nodeValue.trim().length<14)continue;
const original=node.nodeValue;re.lastIndex=0;let match,offset=0,modified=false;const fragment=document.createDocumentFragment();
while((match=re.exec(original))&&count<4){const item=termLookup.get(match[0].toLowerCase());if(!item)continue;
const zone=paragraph.closest('.v24-article')?'article':paragraph.closest('.v23-deep-study')?'professional-reader':'lesson';const key=zone+'|'+item.term;
if((seen.get(key)||0)>=2)continue;
fragment.append(document.createTextNode(original.slice(offset,match.index)),termButton(match[0],item));offset=match.index+match[0].length;modified=true;count++;total++;seen.set(key,(seen.get(key)||0)+1);
}
if(modified){fragment.append(document.createTextNode(original.slice(offset)));node.replaceWith(fragment)}
}
}
return total;}
function addGlossary(entries,count){const bar=document.createElement('div');bar.className='v28-glossary-toolbar v28-glossary-ui';
const heading=document.createElement('div');heading.innerHTML='<span class="v28-kicker">IAM · MUSIC BUSINESS WORD GUIDE</span><p><strong>New to artist management?</strong> Hover over <span class="v28-sample">dotted words</span>, tap them on your phone, or use the keyboard to see a definition and practical example.</p>';
const open=document.createElement('button');open.type='button';open.className='v28-glossary-open';open.textContent='Browse '+entries.length+' definitions ↗';bar.append(heading,open);bar.dataset.inlineTerms=count;root.insertBefore(bar,root.firstChild);
const dialog=document.createElement('dialog');dialog.className='v28-glossary-dialog v28-glossary-ui';dialog.setAttribute('aria-labelledby','v28-glossary-title');
dialog.innerHTML='<div class="v28-dialog-header"><div><span class="v28-kicker">IAM · LEARN AT YOUR OWN PACE</span><h2 id="v28-glossary-title">Music industry glossary</h2><p>Beginner-friendly meanings and real artist-management examples.</p></div><button type="button" class="v28-close">Close ×</button></div><label for="v28-glossary-search">Search any term or phrase</label><input id="v28-glossary-search" type="search" placeholder="Try EPK, royalties, timestamps, contracts..." autocomplete="off"><p class="v28-results" aria-live="polite"></p><div class="v28-list"></div><small>Industry and rights rules vary by country; this is educational guidance, not legal advice.</small>';
document.body.append(dialog);const search=dialog.querySelector('input'),list=dialog.querySelector('.v28-list'),results=dialog.querySelector('.v28-results');
function render(query){let n=0;const fragment=document.createDocumentFragment();for(const item of entries){if(query&&![item.term,item.category,item.meaning,item.example,...item.aliases].join(' ').toLowerCase().includes(query))continue;n++;const card=document.createElement('article');card.className='v28-entry';const small=document.createElement('span');small.textContent=item.category;const h=document.createElement('h3');h.textContent=item.term;const definition=document.createElement('p');definition.textContent=item.meaning;const eg=document.createElement('p');eg.className='v28-example';eg.textContent='In practice: '+item.example;card.append(small,h,definition,eg);fragment.append(card)}list.replaceChildren(fragment);results.textContent=n+' of '+entries.length+' definitions';}
open.addEventListener('click',()=>{closeTip();search.value='';render('');dialog.showModal();search.focus()});
dialog.querySelector('.v28-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('close',()=>open.focus());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});search.addEventListener('input',()=>render(search.value.toLowerCase().trim()));
}
fetch('/static/iam-glossary-v28.json',{credentials:'same-origin'}).then(response=>{if(!response.ok)throw Error('Glossary unavailable');return response.json()}).then(entries=>{const count=annotate(entries);addGlossary(entries,count)}).catch(err=>console.warn('IAM glossary:',err.message));
})();
