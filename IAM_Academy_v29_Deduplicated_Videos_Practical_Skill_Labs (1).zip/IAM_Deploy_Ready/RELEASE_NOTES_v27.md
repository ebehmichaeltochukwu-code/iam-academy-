# IAM Academy Version 27 — Module 3 Timestamp Workshop

Built on the complete V26 release, including V25 supplementary interviews, V24 extended readers and the V26 EPK workshop.

## New paid bonus lesson
- `GET /module/3/timestamps`: How to Create and Use Timestamps as an Artist Manager.
- Full original teaching article (ten sections) covering video time offsets versus actual date/time records; valid YouTube manual chapters; sharing interview highlights; backstage/performances; rehearsal and edit logs; source file versioning; permissions; media/EPK pitch workflows; and responsible evidentiary practice.
- Official YouTube chapters guidance, including 00:00 first chapter, three timestamps, minimum ten seconds per chapter and possible advanced-feature eligibility requirements.
- Inline third-party tutorial (SvenDesigns, How to Add Chapters On YouTube 2025, https://www.youtube.com/watch?v=WJ4Vqw9eWFY). Dedicated in-IAM enlarged viewing, publisher source fallback; external embedding is subject to YouTube policies.
- Offline/browser-only working chapter generator: input start times and titles, validate and copy description. Accepts MM:SS and HH:MM:SS.
- Offline/browser-only YouTube time-link generator: paste a valid YouTube URL, add time and copy link with `&t=<seconds>s`; validates HTTPS domains and video ID format.
- Example timestamped editorial approval log, fictional Lagos artist case, eight knowledge-check prompts and portfolio assignment.
- Module 3 navigation cards on the student dashboard, Week 3 lessons and public course outline. A link to this workshop appears inside the EPK workshop.
- Mobile-first styling and accessibility-friendly status messages.

## Non-regression and security
- The original 24 required lessons, eight assessed modules, five applied modules, certificates, payment settings and student database schema are unchanged.
- The EPK workshop is retained, as are existing videos, artist interviews and reading articles.
- Authentication is required. Student access requires the same approval/payment gate as the course; admins/reviewers may preview.
- The tools run locally in the student's browser, without external AI API requests, and do not save entries to the IAM server. Third-party YouTube video player may contact YouTube as usual.
- No database files, credentials or runtime environment variables are inside this archive.
- Automated regression suite: 57 passed. Browser/device playback must be checked after deployment.

## Release protocol
1. Upload V27 ZIP (unextracted) to the existing GitHub repository main branch.
2. Update only the existing Railway `iam-web` production start command with the new archive URL and checksum.
3. Keep the existing `IAM_DATABASE=/data/iam.db`, Railway volume `/data`, domains, payment settings and secrets unchanged.
4. Confirm `IAM_VERSION_27_MODULE3_TIMESTAMPS_READY` in deployment logs, a passing HTTP `/health` check, and an actual paid learner's view of the Module 3 timestamps workshop.
