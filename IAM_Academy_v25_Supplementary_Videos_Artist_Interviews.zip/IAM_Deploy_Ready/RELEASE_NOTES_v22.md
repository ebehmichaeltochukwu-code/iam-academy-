# IAM Academy Version 22: Navigation + Expandable AI Companion

Changes from v21:
- The desktop navigation no longer squeezes nine links into narrow columns.
- On narrower desktop screens, tablets and phones, a hamburger menu replaces crowded links.
- Original IAM branding, gold Apply Now button, and application routes are retained.
- Floating IAM AI has a **Full view** button, then **Compact view** to restore the small window.
- Switching size does not reload the iframe or clear the active conversation.
- Expanded student AI conversation and public guide message panels get more room.
- Escape closes the floating assistant. The student tutor and public guide keep their existing permissions.
- No changes to tuition, accounts, assessments, database schema or AI billing.

Deployment:
- This ZIP has the same IAM_Deploy_Ready/ directory structure as v21.
- The existing Railway service loads its ZIP from GitHub using a SHA256-verified start command.
- Upload this new ZIP to the same GitHub repository, then use the separate
  IAM_v22_Railway_Start_Command.txt supplied with this package.
- Keep IAM_DATABASE=/data/iam.db and the existing Railway volume attached.
- Do not overwrite the production database or change secrets.
- Check /health and test the navigation and IAM AI after redeploy.

NOTE: The ZIP intentionally omits iam.db to avoid publishing a local SQLite database.
Your Railway persistent /data database is unaffected.
