from fastapi.testclient import TestClient
from app import app

def test_public_guide_is_limited():
 c=TestClient(app);r=c.get('/study-companion');assert r.status_code==200;assert 'IAM AI · Admissions Guide' in r.text;assert 'iam-public-guide-v19.js' in r.text;assert 'id="v17-voice-start"' not in r.text

def test_student_study_ai_requires_login():
 c=TestClient(app,follow_redirects=False);r=c.get('/student/iam-ai');assert r.status_code==303;assert r.headers['location']=='/login'

def test_public_launcher_is_marketing():
 c=TestClient(app);r=c.get('/');assert r.status_code==200;assert 'data-url="/study-companion?embed=1"' in r.text

def test_processing_indicators_exist():
 c=TestClient(app);js=c.get('/static/iam-ai-v17.js').text;assert 'v18-thinking' in js;assert 'Preparing your reply' in js;assert 'v23silenceTime>' in js
