import re
from fastapi.testclient import TestClient
import app as iam

def csrf(client,path):
 text=client.get(path).text
 hit=re.search(r'name="csrf"[^>]*value="([^"]+)"',text)
 assert hit, path
 return hit.group(1)

def test_public_pages():
 c=TestClient(iam.app)
 for path in ['/','/curriculum','/apply','/login','/health']:
  response=c.get(path)
  assert response.status_code==200
  assert '<html' in response.text or path=='/health'
 assert len(iam.LESSONS)==24
 assert len(iam.WEEKS)==8
 assert all(len(w['quiz'])==8 for w in iam.WEEKS)
 c.close()

def test_end_to_end(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'training.sqlite3')
 iam.init_db()
 student=TestClient(iam.app)
 admin=TestClient(iam.app)
 student_csrf=csrf(student,'/apply')
 resp=student.post('/apply',data={'csrf':student_csrf,'full_name':'Adaobi Emeka','email':'adaobi@example.com','password':'StrongPassword123!','experience':'Working with an emerging artist','motivation':'I want to guide Nigerian artists with integrity, clear agreements and lasting impact.'},follow_redirects=True)
 assert resp.status_code==200 and 'Under review' in resp.text
 assert student.get('/lesson/w1l1',follow_redirects=False).status_code==303
 with iam.db() as c:
  c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?, ?, ?, 'admin','approved','paid')",('IAM Owner','owner@example.com',iam.password_hash('OwnerPassword123!')))
 adm_csrf=csrf(admin,'/login')
 resp=admin.post('/login',data={'csrf':adm_csrf,'email':'owner@example.com','password':'OwnerPassword123!'},follow_redirects=True)
 assert resp.status_code==200 and 'Management console' in resp.text
 adm_csrf=csrf(admin,'/admin?tab=applications')
 admin.post('/admin/applicant/1',data={'csrf':adm_csrf,'decision':'approved'})
 student.get('/dashboard')
 assert 'Application approved' in student.get('/dashboard').text
 adm_csrf=csrf(admin,'/admin?tab=payments')
 admin.post('/admin/payment/1',data={'csrf':adm_csrf,'reference':'BANK-REFERENCE-0001'})
 assert 'Your thirteen-week journey' in student.get('/dashboard').text
 for week in iam.WEEKS:
  for lesson in week['lessons']:
   assert student.get('/lesson/'+lesson['id']).status_code==200
   s=csrf(student,'/lesson/'+lesson['id'])
   assert student.post('/lesson/'+lesson['id']+'/complete',data={'csrf':s},follow_redirects=False).status_code==303
  week_n=week['number']
  s=csrf(student,f'/quiz/{week_n}')
  correct_answers={f'q{i}':str(q[2]) for i,q in enumerate(week['quiz'])}
  qr=student.post(f'/quiz/{week_n}',data={'csrf':s,**correct_answers})
  assert qr.status_code==200 and 'Knowledge check passed' in qr.text
  s=csrf(student,'/dashboard')
  payload=('A responsible manager should ask clarifying questions and confirm decision rights. '
           'The artist deserves timely information, clear budgets, documented agreements and an honest risk assessment. '*3)
  if week_n==8:payload=payload*18
  assert student.post(f'/submission/{week_n}',data={'csrf':s,'body':payload},follow_redirects=False).status_code==303
  with iam.db() as c:
   sid=c.execute('SELECT id FROM submissions WHERE user_id=1 AND week=? ORDER BY id DESC LIMIT 1',(week_n,)).fetchone()['id']
  s=csrf(admin,'/admin?tab=submissions')
  assert admin.post(f'/admin/submission/{sid}',data={'csrf':s,'decision':'approved','feedback':'Approved: the response provides clear reasoning and appropriate risk controls.'},follow_redirects=False).status_code==303
 st=iam.course_state(1)
 assert len(st['done'])==24 and len(st['passes'])==8 and len(st['approved'])==8 and st['certificate']
 assert student.get('/certificate').content[:4]==b'%PDF'
 assert 'Adaobi Emeka' in student.get('/verify/'+st['certificate']['code']).text
 assert 'Certificate not found' in student.get('/verify/IAM-invalid').text
 assert student.get('/admin',follow_redirects=False).status_code==303
 assert admin.get('/admin/videos').status_code==200
 s=csrf(admin,'/admin/videos')
 assert admin.post('/admin/videos/w1l1',data={'csrf':s,'youtube_id':'qQx1j7YNiqM'},follow_redirects=False).status_code==303
 assert 'qQx1j7YNiqM' in student.get('/lesson/w1l1').text
 student.close(); admin.close()
