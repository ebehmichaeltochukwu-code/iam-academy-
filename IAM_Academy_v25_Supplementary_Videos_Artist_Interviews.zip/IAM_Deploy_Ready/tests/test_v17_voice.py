from fastapi.testclient import TestClient
from bs4 import BeautifulSoup
from app import app

def test_launcher_on_homepage_and_original_logo():
    r=TestClient(app).get('/')
    assert r.status_code==200
    soup=BeautifulSoup(r.text,'html.parser')
    assert soup.select_one('#v17-float-trigger img')['src'].startswith('/static/iam-user-logo.svg')
    assert soup.select_one('#v17-float-frame')['allow']=='microphone'
    assert 'v17-float-window' in r.text

def test_voice_toggle_in_existing_companion():
    from pathlib import Path
    soup=BeautifulSoup((Path(__file__).resolve().parents[1]/'templates/study_companion_v16.html').read_text(), 'html.parser')
    assert soup.select_one('#v17-voice-stage').has_attr('hidden')
    assert soup.select_one('#v17-voice-start')
    assert soup.select_one('#v17-mute')
    assert soup.select_one('#v17-end')
    assert soup.select_one('#v17-text-tab')
    assert soup.select_one('#v17-voice-tab')
    assert soup.select_one('#v17-transcript-edit')
    assert 'iam-ai-v17.js' in str(soup)

def test_browser_code_and_privacy_guards():
    c=TestClient(app)
    js=c.get('/static/iam-ai-v17.js')
    assert js.status_code==200
    for expected in ('navigator.mediaDevices.getUserMedia','echoCancellation:true','noiseSuppression:true','v23FinishLocal','v23active','v23End','visibilitychange','iamIdentity'):
        assert expected in js.text
    assert 'openai.com' not in js.text.lower()
    assert c.get('/static/iam-ai-launcher-v17.js').status_code==200
