"""V24 extended paid lesson readers and reading-navigation regression tests."""
from fastapi.testclient import TestClient
from longform_readers_v24 import LESSON_TEXT, ADVANCED_TEXT, article_for_lesson, article_for_advanced
from enhanced_curriculum_v23 import LESSON_STUDY
import app as iam
import re


def test_all_twenty_four_graded_lessons_have_substantial_unique_readers():
    assert len(LESSON_TEXT)==len(LESSON_STUDY)==24
    for lesson_id,study in LESSON_STUDY.items():
        article=article_for_lesson(lesson_id,study)
        assert article and len(article['sections'])==5
        assert article['word_count']>=430,(lesson_id,article['word_count'])
        assert article['read_minutes']>=2
        assert len({s['paragraphs'][0] for s in article['sections']})==5


def test_five_applied_modules_have_extra_reading():
    for week in range(9,14):
        article=article_for_advanced(week,iam.BONUS_MASTERCLASSES[week])
        assert article and article['word_count']>160


def test_paid_visitor_gate_and_reading_shortcuts(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-v24-gate.db')
    iam.init_db()
    with TestClient(iam.app) as client:
        assert client.get('/lesson/w1l1',follow_redirects=False).status_code==303
        assert client.get('/career/masterclass/9',follow_redirects=False).status_code==303
        with iam.db() as conn:
            conn.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('IAM Test Admin','admin-v24@example.com',iam.password_hash('StrongPass12345!')))
        login=client.get('/login').text
        csrf=re.search(r'name="csrf"[^>]*value="([^"]+)"',login).group(1)
        assert client.post('/login',data={'csrf':csrf,'email':'admin-v24@example.com','password':'StrongPass12345!'},follow_redirects=False).status_code==303
        resp=client.get('/lesson/w1l1')
        assert resp.status_code==200
        for phrase in ('Read the complete lesson article','id="full-lesson-article"','Understanding the professional decision','Field notes: test the quality of your evidence','The complete study article'):
            assert phrase in resp.text, phrase
        assert 'v24-readers.css' in resp.text
        resp=client.get('/career/masterclass/10')
        assert resp.status_code==200
        assert 'Read the in-depth module article' in resp.text
        assert 'id="extended-masterclass-article"' in resp.text
