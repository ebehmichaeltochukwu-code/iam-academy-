# IAM Academy v25 · Restored and curated supplementary videos

## Restores videos in the paid classroom

**Root cause of the missing section:** Version 23/24 mapped one supplementary video key to every lesson, then filtered out any video that matched the lesson's main player. As a result, 17 of 24 core lessons rendered no supplementary video. Version 25 corrects the mapping for every lesson, without reverting the expanded reading articles introduced in v24.

- All 24 core lessons render between one and three relevant supplementary YouTube embeds, in a named and accessible **Supplementary videos and artist experiences** section.
- Five applied modules (Weeks 9–13) also include an expanded supplementary-video selection.
- Retains the video popup/fullscreen controls from v23, and preserves the original videos and IAM-owned scenario films.
- Adds verified publisher-hosted YouTube interviews in selected lessons, especially Davido & Tycoone (GRAMMYS), Asa Asika (Afropolitan Podcast, Azuwa Studios) and Burna Boy (Apple Music). Original-publisher artist reading/interview sources are clearly labeled as reading or external hosted video where appropriate.
- Spotify playlist/video tutorials appear only where relevant to music release and artist marketing. The repeatedly applied "Your Guide to Spotify for Artists" clip remains excluded from unrelated lessons.
- All supplemental cards state publisher attribution, a lesson-specific reason to watch, and a practical question.
- Links fall back to the original YouTube watch page if publisher restrictions prevent embeds.
- A visible **View supplementary videos and artist interviews** jump link at the top of each paid lesson helps students find the media without scrolling through long articles.
- A new CSS asset improves spacing and mobile video viewing without changing IAM branding.

## Verified interview source register

- GRAMMYS: Davido and Tycoone, `https://www.youtube.com/watch?v=coWfP4ck4lA`
- Azuwa Studios: Asa Asika, `https://www.youtube.com/watch?v=CSO4JtLdhgE`
- Afropolitan Podcast: Asa Asika, `https://www.youtube.com/watch?v=7dcJrWv_PBs`
- Apple Music: Burna Boy, `https://www.youtube.com/watch?v=r01o45-CoWY`
- GRAMMY.com: Tems, `https://www.grammy.com/news/tems-born-in-the-wild-debut-album-interview/` (written interview, not claimed to be video)
- YouTube for Artists: Burna Boy and The Chainsmokers, publisher-hosted written stories.

## Safe data and curriculum scope

Preserves v24 full lesson readers; existing 13-week curriculum, graded questions, assignments and admin functionality; `/data` database path and all user accounts/progress. No database is shipped. No private credentials are included. This release is not itself a site deployment.

## Editorial and QA caveat

YouTube embed permissions, regional access and third-party availability are controlled by each publisher and can change. Media IDs were curated from named YouTube publisher pages (new interview selections) or retained from existing IAM course source. Classroom rendering and automated tests can be verified locally. Live mobile playback and individual third-party embedability require follow-up checks after deployment.
