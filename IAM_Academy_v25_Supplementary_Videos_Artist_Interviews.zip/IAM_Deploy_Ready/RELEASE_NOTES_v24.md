# IAM Academy Version 24 | Full Paid Lesson Readers

## Why this release exists
V23 offered only a short Professional Reader note and off-site source links. This is not a satisfactory substitute for substantial in-class reading. Version 24 retains all of V23 and adds original extended articles directly to the premium lessons.

## Core changes
- All 24 paid core lessons in Weeks 1-8 have five structured long-form article sections (440-560 new words per article), including contextual decisions, practical methods, a tailored field case, evidence-checking notes and a professional recap.
- Each article has its own clear heading, estimated reading time, and short applied exercise. The pre-existing lesson overview, original Professional Reader, workbook, video guidance, journals and quizzes remain intact, so overall classroom reading depth is greater than the new article word count alone.
- A **Read the complete lesson article** button appears at the top of each lesson so learners can reach the teaching text without scrolling past embedded videos.
- Weeks 9-13 each get a distinct original advanced article in the existing module view. The existing advanced teaching chapters and self-checks are preserved.
- Mobile-readable typography, 16px+ text, accessible anchors, and readable paragraph widths. No paid API services.
- Fictional instructional examples are labelled and rights/legal guidance is educational rather than personalised advice.

## Safety and compatibility
- Payments, certificates, admin permissions, progress tables and student journals are unchanged.
- Protected `/lesson/...` and `/career/masterclass/...` routes retain the existing paid-student access check and admin read-only preview.
- No database, `.env`, secrets or private user records included in release ZIP.
- Railway must retain `IAM_DATABASE=/data/iam.db` and the existing volume mounted at `/data`.

## Tests
- 50 Python test cases passed; including new long-form content coverage, gated course access and in-page navigation tests.
- Browser/device visual assessment required after rollout. Existing third-party video and browser speech features remain subject to their platform constraints.

## Release steps
1. Upload the ZIP to the **main** branch of `ebehmichaeltochukwu-code/iam-academy-` without extracting it.
2. Update the existing Railway `iam-web` Custom Start Command using `IAM_v24_Railway_Start_Command.txt`.
3. Redeploy, verify Railway status SUCCESS, log marker `IAM_VERSION_24_LONGFORM_READERS_READY` and `/health` HTTP 200.
4. Test an enrolled account's Week 1 Lesson 1 and Week 5 Lesson 2; click **Read the complete lesson article** near the top and check the full text appears. Also check Advanced Module 10.
