# IAM Academy v23 | Video selection and source policy

## Why the repeated video was removed

The older fixed `MODULE_VIDEO_IDS` list assigned the same Spotify for Artists orientation video to Weeks 1, 3, 6 and 8 even where the subjects were management ethics, leadership or financial planning. V23 no longer reads that fixed list when rendering the paid core lessons. It selects topical videos at lesson level using `lesson_video_cards` and omits an extra if none is appropriate. The original, lesson-specific *first* videos are preserved, including any authorised admin overrides.

## Relevant media in core lessons

- Week 1: artist-manager responsibilities, decision rights, onboarding and ethics.
- Week 2: song structure, listening and creative feedback; never insert Spotify promotion as filler.
- Week 3: communication and safeguarding; never insert Spotify promotion as filler.
- Week 4: masters, composition, metadata and royalty literacy from the existing rights collection.
- Week 5: Spotify playlist pitching and YouTube analytics are suitable for release strategy and audience growth, not for unrelated modules. IAM's own Spotify release scenario remains in the release lesson.
- Week 6: budgeting, business managers, live-show operational discipline and vendor contracts.
- Week 7: contracts, risk, professional development and sustainability.
- Week 8: evidence-led artist audit, 90-day planning and presenting a management strategy.

## Applied modules

- Week 9: IAM interview simulation and existing third-party spokesperson training clip.
- Week 10: IAM's original release simulation plus directly relevant playlist-pitching and analytics clips. New engagement calendar teaching covers behind-the-scenes stories, artist Q&A, community management, permissions and metrics.
- Week 11: WIPO music/copyright sources rather than any Spotify orientation clip.
- Week 12: official YouTube for Artists learning hubs and analytics article. Where specific verified, embeddable video IDs are not available, keep text learning and official source links.
- Week 13: official WIPO and YouTube international strategy resources, plus YouTube for Artists' published Burna Boy artist story as further reading (not falsely labelled as a video).

## Editorial controls

Use admin `video_overrides` only for the core lesson's primary player, not as a blanket cross-course fallback. For any future artist interview embed, independently verify the watch URL, publisher, educational topic and embedding policy before adding an ID. Do not imply an artist endorses IAM without consent.
