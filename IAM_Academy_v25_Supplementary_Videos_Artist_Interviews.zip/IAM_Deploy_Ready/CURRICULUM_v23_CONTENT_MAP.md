# IAM Academy v23 | Private Paid Curriculum Inventory

This file inventories existing courses and V23 enhancements; it is not a replacement syllabus.

## Week 1: The Artist Manager’s Foundation
- w1l1: What an artist manager actually does | expanded reading + Nigerian/African case + evidence task | extra videos: How to Be a Good Artist Manager
- w1l2: Trust, ethics and professional boundaries | expanded reading + Nigerian/African case + evidence task | extra videos: What Makes a Great Music Manager?
- w1l3: The first 30 days with an artist | expanded reading + Nigerian/African case + evidence task | extra videos: How To Become An Artist Manager
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 2: Understanding the Music
- w2l1: Listen like a manager | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w2l2: Song structure, hooks and audience fit | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w2l3: Giving creative feedback without controlling the artist | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 3: Communication, Conflict & Leadership
- w3l1: How to agree and disagree professionally | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w3l2: Difficult conversations and repair | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w3l3: Team leadership and safeguarding | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 4: Music Rights, Agreements & Royalties
- w4l1: Masters, compositions and split sheets | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w4l2: Royalties, metadata and territory | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w4l3: Agreements and red flags | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 5: Brand, Audience & Digital Growth
- w5l1: Artist positioning and story | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w5l2: Release strategy from pre-save to post-release | expanded reading + Nigerian/African case + evidence task | extra videos: How to Pitch to Playlists
- w5l3: Analytics, community and ethical promotion | expanded reading + Nigerian/African case + evidence task | extra videos: How to Use Analytics for Artists
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 6: Money, Touring & Operations
- w6l1: Budgets, commissions and accounting | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w6l2: Show booking, riders and travel | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w6l3: Negotiation and vendor management | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 7: Deals, Risk & Career Development
- w7l1: Evaluating labels, brands and partnerships | expanded reading + Nigerian/African case + evidence task | extra videos: What Does a Music Business Manager Do?
- w7l2: Crisis, reputation and digital safety | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w7l3: Long-term development and wellbeing | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 8: The Professional Management Capstone
- w8l1: Auditing an emerging artist’s business | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- w8l2: Constructing the 90-day roadmap | expanded reading + Nigerian/African case + evidence task | extra videos: How to Become a Music Artist Manager Today
- w8l3: Professional judgement and final presentation | expanded reading + Nigerian/African case + evidence task | extra videos: none where not relevant
- Graded quiz: 8 items, 75% threshold; existing attempts retained.

## Week 9: Media interviews and artist representation
- Chapters: 8; self-review questions: 5; portfolio project and reflection still in place.

## Week 10: Create genuine buzz and build an artist people talk about
- Chapters: 9; self-review questions: 5; portfolio project and reflection still in place.

## Week 11: Music Copyright, Rights and Sustainable Artist Income
- Chapters: 9; self-review questions: 5; portfolio project and reflection still in place.

## Week 12: YouTube for Artists: Channels, Analytics and Release Campaigns
- Chapters: 9; self-review questions: 5; portfolio project and reflection still in place.

## Week 13: Global Digital Music Strategy, Rights and Artist Career Capstone
- Chapters: 9; self-review questions: 5; portfolio project and reflection still in place.
