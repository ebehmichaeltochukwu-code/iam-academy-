"""IAM Academy V25 educational media: restore topic-specific supplementary clips.

These are curated, third-party companion embeds, never IAM-hosted or represented
as endorsements. Video IDs are taken from existing IAM course assets; artist
interview source URLs are from verified original-publisher pages. Every card
includes a lesson-specific task to discourage passive/repetitive viewing.
"""
from content import VIDEOS

# Platform tutorials were already shipped in IAM v23. Keep them only where
# release pitching / YouTube analytics genuinely belong.
FOCUSED_VIDEOS = {
 'playlist': ('Dwo42-7Xjis','How to Pitch to Playlists','Spotify for Artists · playlist pitching'),
 'ytanalytics': ('FmqifH4Ai9M','How to Use Analytics for Artists','YouTube Creators · artist analytics'),
}

# Each tuple: additional video key, why it relates, a concrete learner task.
# Never insert the same video as the lesson's existing primary video.
CURATED_BY_LESSON = {
 'w1l1': [('manager2','Compare the professional duties of a manager with the artist’s reserved decisions.','Write a short responsibility-and-approval matrix.'),('terms','Review the terms that prevent confusion when defining the manager’s mandate.','Name three responsibilities a manager must not silently assume.')],
 'w1l2': [('great','Listen for qualities of a trustworthy management relationship.','Write two confidentiality or conflict-of-interest rules.'),('terms','Clarify the vocabulary used in professional arrangements.','Identify one term you must verify before agreeing to work.')],
 'w1l3': [('manager','Study the practical priorities of onboarding a new artist.','Plan the first three discovery meetings.'),('business','Consider when an artist may need a financial specialist.','Add financial and contractual questions to your intake checklist.')],
 'w2l1': [('terms','Learn vocabulary used when reviewing a track and its professional context.','Record an observable listening note rather than a personal judgement.')],
 'w2l2': [('great','Explore how strong teams assess artistic decisions against the intended audience.','Propose one hook or arrangement test that preserves artistic choice.')],
 'w2l3': [('manager','Compare the roles of manager and producer when an artist receives critical feedback.','Practise a respectful feedback conversation.')],
 'w3l1': [('manager2','Observe the manager’s responsibilities in a difficult artist relationship.','Write a disagreement script with agreed decision rights.')],
 'w3l2': [('great','Connect professional trust with how a manager repairs setbacks.','Draft a private repair conversation and follow-up plan.')],
 'w3l3': [('manager2','Compare good management practice with team leadership and care.','Create an escalation rule for an unsafe incident.')],
 'w4l1': [('royalty2','Explore what a licensing organisation can and cannot administer.','Make a two-column register for compositions and master recordings.'),('terms','Review rights language before preparing split sheets.','List three questions requiring specialist advice.')],
 'w4l2': [('rights','Clarify the distinction between the work and its recording before reading royalty data.','Map a payment type to the appropriate rights holder.'),('royalty2','Understand the US mechanical-royalty context without assuming it applies identically in Nigeria.','Identify the relevant territory and collection body.')],
 'w4l3': [('rights','Identify the rights whose ownership a manager must clarify in agreements.','Underline deal terms that need legal review.'),('terms','Review negotiation language and documentation.','Make a contract red-flag checklist.')],
 'w5l1': [('great','Study the relationship between a credible artist identity and good management.','Draft an artist-positioning statement with evidence.')],
 'w5l2': [('playlist','Study eligible-release playlist pitching and platform rules.','Prepare a truthful release pitch, without guaranteeing placement.'),('ytanalytics','Connect post-release decisions to verifiable audience signals.','Select three metrics to review after the release.')],
 'w5l3': [('ytanalytics','Compare reach and genuine listener engagement.','Choose two measures of repeat audience behaviour.')],
 'w6l1': [('finance','Consider controls needed for artist budgets, commissions and reporting.','Create a spending-approval and receipts process.')],
 'w6l2': [('business','Explore the business-management role around live engagements.','Identify travel, insurance, contract and settlement risks.')],
 'w6l3': [('terms','Review commercial terms before meeting a supplier.','Write two fallback clauses and a negotiation limit.'),('business','Compare the roles of manager and financial professionals.','Build a vendor comparison matrix.')],
 'w7l1': [('terms','Connect terminology with label and sponsorship deal risks.','Flag exclusivity, term and recoupment in a hypothetical offer.'),('manager2','Consider who should be consulted before recommending a partnership.','Write a transparent artist-approval checklist.')],
 'w7l2': [('great','Study the connection between trusted leadership and reputational decisions.','Draft one verified holding statement and an escalation path.')],
 'w7l3': [('manager','Consider career sustainability, delegation and artist choice.','Build a realistic monthly review agenda.')],
 'w8l1': [('business','Use professional management controls to strengthen an artist audit.','Mark facts, risks and missing records in an audit.'),('rights','Confirm catalogue ownership and documentation gaps.','Prepare a rights-risk register.')],
 'w8l2': [('career','Review how a manager turns goals into actionable plans.','Write milestones, owners and decision checkpoints.'),('finance','Check whether the proposed 90-day plan has financial controls.','Add a budget and cash-flow review.')],
 'w8l3': [('terms','Use accurate music-business language in the final presentation.','Explain one contract risk clearly to a non-expert.'),('great','Reflect on ethics and professional judgement.','Defend a recommendation using evidence and alternatives.')],
}

# Evidence-based artist viewpoints. These are original-publisher pages, not fake
# YouTube IDs, and are marked as publisher-hosted interview/video/article.
ARTIST_PERSPECTIVES = {
 'davido_team': {
  'title':'Davido and creative director Tycoone: building a trusted team',
  'publisher':'Recording Academy / GRAMMY.com', 'format':'Publisher-hosted video interview',
  'url':'https://www.grammy.com/video/davido-interview-timeless-creative-director-interview-family-matters/',
  'insight':'Davido and Tycoone describe a working creative relationship. Identify how the team developed trust and expanded its responsibilities.',
 },
 'tems_process': {
  'title':'Tems: the creative process behind Born in the Wild',
  'publisher':'Recording Academy / GRAMMY.com','format':'Artist interview (read at original publisher)',
  'url':'https://www.grammy.com/news/tems-born-in-the-wild-debut-album-interview/',
  'insight':'Consider Tems’ comments on artistic direction, creative patience and working on her own terms.',
 },
 'burna_crossborder': {
  'title':'Burna Boy: music, identity and audiences beyond borders',
  'publisher':'YouTube for Artists','format':'First-person artist story (read at publisher)',
  'url':'https://artists.youtube.com/intl/en-GB/news/burna-boy-beyond-borders/',
  'insight':'Examine how artist identity and cultural influences affect global strategy, without assuming one route will fit all artists.',
 },
 'chainsmokers_fans': {
  'title':'The Chainsmokers: building a fanbase through video and behind-the-scenes stories',
  'publisher':'YouTube for Artists','format':'Artist interview and story (read at publisher)',
  'url':'https://artists.youtube.com/blog?id=4374ee42dc644628b80c4b64a80e9602',
  'insight':'Notice their discussion of tour diaries, personal videos and other fan touchpoints beyond official music videos.',
 },
}

ARTIST_BY_LESSON = {
 'w1l1':['davido_team'], 'w1l2':['davido_team'], 'w1l3':['davido_team'],
 'w2l1':['tems_process'], 'w2l2':['tems_process'], 'w2l3':['tems_process'],
 'w3l1':['davido_team'], 'w3l2':['davido_team'], 'w3l3':['davido_team'],
 'w4l1':[], 'w4l2':[], 'w4l3':[],
 'w5l1':['tems_process','burna_crossborder'], 'w5l2':['chainsmokers_fans'], 'w5l3':['chainsmokers_fans'],
 'w6l1':[], 'w6l2':['chainsmokers_fans'], 'w6l3':['davido_team'],
 'w7l1':['davido_team'], 'w7l2':[], 'w7l3':['tems_process'],
 'w8l1':[], 'w8l2':['burna_crossborder'], 'w8l3':['burna_crossborder'],
}

ARTIST_BY_ADVANCED = {9:['davido_team'],10:['chainsmokers_fans','burna_crossborder'],11:[],12:['chainsmokers_fans'],13:['burna_crossborder','tems_process']}


# Source check: these four artist interviews have real, publicly indexed YouTube
# watch pages with named publishers. They are distinct from IAM's own narration.
# The pages may later disable embeds; offer the official watch link as fallback.
VERIFIED_ARTIST_VIDEOS = {
 'davido_team': ('coWfP4ck4lA','Davido and Tycoone: How Their Creative Partnership Began','Recording Academy / GRAMMYS'),
 'asa_studio': ('CSO4JtLdhgE','The Business of Music with Asa Asika, Manager of Davido','Azuwa Studios'),
 'asa_legacy': ('7dcJrWv_PBs','Asa Asika: Building a Long-Term Music Business','Afropolitan Podcast'),
 'burna_identity': ('r01o45-CoWY','Burna Boy: The I Told Them Interview','Apple Music'),
}
ARTIST_VIDEO_BY_LESSON = {
 'w1l1':('asa_studio','Hear how a working African talent manager approaches roles and professional development.','Compare the manager’s responsibilities with the artist’s own decisions.'),
 'w1l2':('davido_team','See how the artist and creative director built a working relationship.','Identify two examples of trust and evolving responsibilities.'),
 'w1l3':('asa_legacy','Observe how a manager describes choosing artists and building teams over time.','Write two questions for your first artist discovery meeting.'),
 'w2l3':('burna_identity','Hear how a major artist talks about collaborating and retaining his musical identity.','Explain how feedback can respect artistic autonomy.'),
 'w3l3':('davido_team','Observe the division of responsibilities in a creative team.','Outline one fair team escalation and approval rule.'),
 'w5l1':('burna_identity','Listen to an artist describe influences, story and identity in a real interview.','Compare authentic identity with an invented marketing persona.'),
 'w6l2':('asa_legacy','A working manager discusses touring demands and professional wellbeing.','List travel, staffing and artist-wellbeing risks.'),
 'w7l1':('asa_studio','Hear a manager describe business relationships, collaborations and industry growth.','Evaluate one partnership using an artist-first risk checklist.'),
 'w7l3':('asa_legacy','Consider a manager’s experience of long-term careers and changing priorities.','Write a sustainable schedule that keeps artists involved.'),
 'w8l3':('burna_identity','Observe an artist reflecting on his wider career and his creative choices.','Defend one career recommendation using evidence and artist choice.'),
}
ARTIST_VIDEO_BY_ADVANCED = {
 9:[('davido_team','Examine how an artist and creative director communicate publicly and represent their partnership.','Draft respectful talking points for a team interview.')],
 10:[('asa_studio','Consider how management and business partners contribute to sustained fan engagement.','Propose an artist engagement calendar grounded in real relationships.')],
 13:[('burna_identity','Hear a Nigerian artist discuss artistic roots, influences and global ambition.','Compare this example with an evidence-based cross-border plan.')],
}

def _artist_card(key, focus, task):
    vid,title,source=VERIFIED_ARTIST_VIDEOS[key]
    return {'id':vid,'title':title,'source':source,'focus':focus,'task':task,
            'url':'https://www.youtube.com/watch?v='+vid}


def select_lesson_video_cards(lesson):
    lesson_id=lesson['id']; original=lesson.get('video_key'); seen={original}; cards=[]
    for key, focus, question in CURATED_BY_LESSON.get(lesson_id,[]):
        if key in seen: continue
        seen.add(key)
        item=VIDEOS.get(key) or FOCUSED_VIDEOS.get(key)
        if not item: continue
        cards.append({'id':item[0],'title':item[1],'source':item[2],'focus':focus,
                      'task':question,'url':'https://www.youtube.com/watch?v='+item[0]})
    interview=ARTIST_VIDEO_BY_LESSON.get(lesson_id)
    if interview:
        key,focus,task=interview
        candidate=_artist_card(key,focus,task)
        if candidate['id'] not in {card['id'] for card in cards}:
            cards.insert(0,candidate)
    return cards


def artist_interviews_for_lesson(lesson):
    active=ARTIST_VIDEO_BY_LESSON.get(lesson['id'], ('',))[0]
    return [ARTIST_PERSPECTIVES[k] for k in ARTIST_BY_LESSON.get(lesson['id'],[])
            if k in ARTIST_PERSPECTIVES and k!=active]


def artist_interviews_for_advanced(week):
    active={row[0] for row in ARTIST_VIDEO_BY_ADVANCED.get(week,[])}
    return [ARTIST_PERSPECTIVES[k] for k in ARTIST_BY_ADVANCED.get(week,[])
            if k in ARTIST_PERSPECTIVES and k not in active]

ADVANCED_VIDEO_KEYS = {
 9:[('manager2','Compare difficult conversations in artist management to the media-rehearsal steps in this module.','Prepare a safe, accurate message before an interview.')],
 10:[('ytanalytics','Review official audience analytics when planning artist interviews, social content and post-release engagement.','Choose returning-listener and fan-engagement indicators.')],
 11:[('rights','Explain the difference between copyright in the song and in the recording.','Produce a permissions map for a sync request.'),('royalty','Review mechanical licensing in its US context only.','Compare with rights mechanisms in the artist’s actual territory.')],
 12:[('ytanalytics','Translate content analytics into an artist-led YouTube release strategy.','Create a monthly reporting template.')],
 13:[('career','Study how management supports a sustainable professional music career.','Evaluate one cross-border opportunity against realistic costs.'),('rights','Before taking an artist across borders, check ownership and licensed rights.','Write a country-by-country rights due-diligence list.')],
}

def supplementary_for_advanced(week):
    cards=[]
    for key,focus,task in ADVANCED_VIDEO_KEYS.get(week,[]):
        v=VIDEOS.get(key) or FOCUSED_VIDEOS.get(key)
        if not v: continue
        cards.append({'id':v[0],'title':v[1],'source':v[2],'focus':focus,'task':task,
                      'url':'https://www.youtube.com/watch?v='+v[0]})
    for key,focus,task in ARTIST_VIDEO_BY_ADVANCED.get(week,[]):
        artist=_artist_card(key,focus,task)
        if artist['id'] not in {card['id'] for card in cards}:
            cards.insert(0,artist)
    return cards
