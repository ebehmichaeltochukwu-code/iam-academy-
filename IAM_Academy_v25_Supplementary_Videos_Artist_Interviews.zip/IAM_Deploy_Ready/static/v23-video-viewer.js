/** IAM v23: immersive, in-page viewing for approved third-party and IAM-owned lesson video. */
(()=>{'use strict';
const shells=[...document.querySelectorAll('.lesson-main .video-shell,.v10-classroom .video-shell')];
if(!shells.length)return;
const dialog=document.createElement('dialog');dialog.className='v23-video-dialog';dialog.setAttribute('aria-label','Expanded IAM lesson video');
const box=document.createElement('div');box.className='v23-dialog-box';
const head=document.createElement('div');head.className='v23-dialog-head';
const name=document.createElement('strong');name.className='v23-dialog-title';name.textContent='Lesson video';
const close=document.createElement('button');close.type='button';close.className='v23-dialog-close';close.textContent='✕ Close video';
const host=document.createElement('div');host.className='v23-dialog-player';
head.append(name,close);box.append(head,host);dialog.append(box);document.body.append(dialog);
let active=null,origin=null,marker=null,previousFocus=null;
function restore(){if(!active)return;const media=active;try{if(media.tagName==='VIDEO')media.pause();else if(media.tagName==='IFRAME'){const src=media.src;media.src='about:blank';media.src=src}}catch(_){}if(marker?.parentNode)marker.replaceWith(media);else origin?.append(media);active=origin=marker=null;document.body.classList.remove('v23-video-open');if(previousFocus?.isConnected)previousFocus.focus();}
function launch(shell){if(active)return;const media=shell.querySelector('iframe,video');if(!media)return;active=media;origin=shell;previousFocus=document.activeElement;marker=document.createComment('Video temporarily expanded');media.replaceWith(marker);host.append(media);name.textContent=media.title||media.getAttribute('aria-label')||'Lesson video';document.body.classList.add('v23-video-open');if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');close.focus();}
for(const shell of shells){const media=shell.querySelector('iframe,video');if(!media)continue;const expand=document.createElement('button');expand.type='button';expand.className='v23-expand-player';expand.textContent='⛶ Expand video in IAM';expand.setAttribute('aria-label','Expand '+(media.title||media.getAttribute('aria-label')||'video')+' inside IAM');shell.insertAdjacentElement('afterend',expand);expand.addEventListener('click',()=>launch(shell));const article=shell.closest('.v13-video-card');const title=article?.querySelector('h3');if(title){title.tabIndex=0;title.setAttribute('role','button');title.setAttribute('aria-label','Expand '+title.textContent.trim()+' video');title.title='Expand this video inside IAM';title.addEventListener('click',()=>launch(shell));title.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();launch(shell)}})}}
close.addEventListener('click',()=>dialog.close());dialog.addEventListener('close',restore);dialog.addEventListener('cancel',event=>{event.preventDefault();dialog.close()});dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close()});
})();
