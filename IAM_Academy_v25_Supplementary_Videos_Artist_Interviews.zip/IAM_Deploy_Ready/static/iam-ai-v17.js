/** IAM AI v16. Browser-local opt-in LLM and speech, with source-grounded, zero-inference-cost fallback. */
const el=(id)=>document.getElementById(id);
const ui={question:el('v16-question'),ask:el('v16-ask'),messages:el('v16-messages'),status:el('v16-status'),topics:el('v16-topics'),count:el('v16-count'),mode:el('v16-mode'),model:el('v16-load-model'),modelState:el('v16-model-state'),device:el('v16-device'),voice:el('v16-voice'),stop:el('v16-stop'),voiceState:el('v16-voice-status'),speak:el('v16-speak'),videos:el('v16-videos'),notes:el('v16-notes'),noteState:el('v16-notes-status')};
const KEY='iam-ai-v16-local';
let kb=null, model=null, mode='ask', speaking=false, recorder=null, recorded=[], micStream=null, asr=null, loading=false;
let history=[];
try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');history=Array.isArray(saved.history)?saved.history.slice(-18):[];ui.notes.value=String(saved.notes||'').slice(0,20000)}catch{}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify({history:history.slice(-18),notes:ui.notes.value.slice(0,20000)}))}catch{ui.noteState.textContent='Local storage is unavailable. Export your notes to keep them.'}};
const words=(s)=>String(s||'').toLowerCase().normalize('NFKD').replace(/[^a-z0-9\s]/g,' ').split(/\s+/).filter(w=>w.length>2);
const stopwords=new Set('the and for how why what when where who with does can you your that this from like more want need should could would explain please about into best have help learn more which i am tell me first second third them there also'.split(' '));
function rank(q,t){const terms=[...new Set(words(q).filter(x=>!stopwords.has(x)))];const name=words(t.title), tags=words(Array.isArray(t.keywords)?t.keywords.join(' '):t.keywords),body=words(t.guidance);let total=0;for(const term of terms){if(name.includes(term))total+=10;else if(name.some(w=>w.startsWith(term)||term.startsWith(w)))total+=4;if(tags.includes(term))total+=6;else if(tags.some(w=>w.startsWith(term)||term.startsWith(w)))total+=2;if(body.includes(term))total+=1}return total}
function resolveQuestion(q){if(/^(and |what about |that |this |it |can you |explain the (first|second|third)|give me an example|show me a video)/i.test(q.trim())&&history.length){const prev=[...history].reverse().find(x=>x.role==='user'&&x.text);if(prev)return prev.text+' '+q}return q}
function lookup(q){if(!kb)return[];return kb.topics.map(t=>({t,score:rank(q,t)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,4).map(x=>x.t)}
function element(tag,className,text){const x=document.createElement(tag);if(className)x.className=className;if(text!==undefined)x.textContent=text;return x}
function addText(container,tag,text,cls=''){container.append(element(tag,cls,text));}
function msg(role,text,topics=[],extra=''){const root=element('article','v16-msg '+(role==='user'?'user':'iam'));addText(root,'b',role==='user'?'You':'IAM AI');addText(root,'p',text);if(extra){addText(root,'p',extra,'v16-practice')}if(topics.length){const refs=element('div','v16-resources');addText(refs,'strong','References and further reading');const ids=[...new Set(topics.flatMap(t=>t.source_ids||[]))];ids.slice(0,6).forEach(id=>{const s=kb.sources.find(x=>x.id===id);if(!s||!/^https:\/\//.test(s.url))return;const a=element('a','','↗ '+s.publisher+': '+s.title);a.href=s.url;a.target='_blank';a.rel='noopener noreferrer';refs.append(a)});root.append(refs)}ui.messages.append(root);ui.messages.scrollTop=ui.messages.scrollHeight;return root}
for(const h of history)msg(h.role,h.text);
function remember(role,text){history.push({role,text:String(text).slice(0,4000)});if(history.length>18)history=history.slice(-18);save()}
function videos(topics,q){ui.videos.replaceChildren();const available=kb.sources.filter(s=>s.kind==='video');let matches=available.map(s=>({s,pts:Math.max(...topics.map(t=>rank(t.title,s)),rank(q,{title:s.title,keywords:s.topics||[],guidance:s.description||''}))})).sort((a,b)=>b.pts-a.pts).filter(x=>x.pts>0).slice(0,2).map(x=>x.s);if(!matches.length&&topics.length)matches=available.filter(s=>(topics[0].module===s.module)).slice(0,1);
 if(!matches.length){addText(ui.videos,'p','No verified video matches this question yet. IAM will not invent a link.','v16-small');return}
 for(const s of matches){const wrap=element('div','v16-video-info');addText(wrap,'strong',s.title);addText(wrap,'p',s.description||'A related educational resource.');if(s.youtube_id&&/^[a-zA-Z0-9_-]{11}$/.test(s.youtube_id)){const play=element('button','v16-btn','▶ Watch inside IAM');play.type='button';play.addEventListener('click',()=>{stopSpeaking();const frame=document.createElement('iframe');frame.className='v16-video-player';frame.title=s.title;frame.loading='lazy';frame.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';frame.referrerPolicy='strict-origin-when-cross-origin';frame.allowFullscreen=true;frame.src='https://www.youtube-nocookie.com/embed/'+s.youtube_id;play.replaceWith(frame)});wrap.append(play)}const a=element('a','','View original source ↗');a.href=s.url;a.target='_blank';a.rel='noopener noreferrer';wrap.append(a);ui.videos.append(wrap)} }
function iamIdentity(question){const q=String(question).toLowerCase();
 if(/\b(who are you|introduce yourself|your name|what is your name|tell me about yourself)\b/.test(q))return 'Hello! I am IAM AI, the free digital study companion of the Institute of Artist Management. I help learners explore artist development, contracts, marketing, career strategy and the music business using IAM’s approved educational knowledge and references. I am software, not a human instructor, and I can show you learning videos and practical exercises. What would you like to study today?';
 if(/\b(tell me about (the )?(school|institute|iam)|introduce (the )?(school|institute)|what is (the )?institute of artist management|what does (the )?school do|who founded (the )?institute)\b/.test(q))return 'The Institute of Artist Management (IAM) is an independent professional training platform founded by Ebeh Michael Tochukwu to develop artist managers and music-business professionals, particularly in Nigeria and Africa. IAM offers a thirteen-module self-paced artist-management learning programme, practical exercises and IAM-issued certificates. Its certificates are not government-accredited qualifications. I can explain the programme, help you study or direct you to admissions. Which would you prefer?';
 return null;}
function fallback(q,topics){const identity=iamIdentity(q);if(identity)return {answer:identity,task:''};const t=topics[0];if(!t)return{answer:'I could not verify a sufficiently relevant answer in the current IAM library. Please ask about a specific artist-management issue, or explore the study topics below. The library is continually reviewed and does not know everything.',task:''};let answer=t.guidance;const sub=topics.slice(1,3);if(mode==='simple')answer='In simple terms: '+t.guidance;if(mode==='deep')answer=t.title+'\n\n'+t.guidance+(sub.length?'\n\nRelated areas to study:\n'+sub.map(x=>'• '+x.title+': '+x.guidance).join('\n'):'');if(mode==='case'||mode==='contract'||mode==='interview')answer='Practice scenario: Imagine you manage a new independent artist who faces this challenge: '+t.title+'.\n\nBefore deciding, consider: '+t.guidance+'\n\nExplain your decision and what evidence you would collect.';if(mode==='quiz')answer='Revision question: '+t.exercise+'\n\nFirst write your own response. Then compare it with this source-grounded guidance: '+t.guidance;if(mode==='video')answer='Here is the relevant background before you watch: '+t.guidance+'\n\nUse the video panel below to explore any matching approved resources.';return {answer,task:'Your practice task: '+t.exercise}}
async function respond(){if(loading||!kb)return;const q=ui.question.value.trim();if(!q)return;loading=true;ui.ask.disabled=true;ui.question.value='';const expanded=resolveQuestion(q);msg('user',q);remember('user',q);const topics=lookup(expanded);const f=fallback(q,topics);ui.status.textContent=model?'IAM AI is reasoning with the local model and checking IAM sources…':'IAM AI is consulting approved IAM knowledge…';ui.messages.setAttribute('aria-busy','true');const think=element('div','v18-thinking');think.setAttribute('role','status');think.innerHTML='<span class="v18-think-dots"><i></i><i></i><i></i></span> <span>IAM AI is preparing your answer</span>';ui.messages.append(think);ui.messages.scrollTop=ui.messages.scrollHeight;await new Promise(r=>requestAnimationFrame(()=>r()));let answer=f.answer;
 if(model&&topics.length&&!iamIdentity(q)){try{const context=topics.map((t,i)=>{const refs=(t.source_ids||[]).map(id=>kb.sources.find(x=>x.id===id)).filter(Boolean).map(s=>s.publisher+' '+s.url).join(' | ');return '[SOURCE '+(i+1)+'] '+t.title+' (module '+t.module+')\n'+t.guidance+'\nReferences: '+refs}).join('\n\n');const recent=history.slice(-7).map(h=>({role:h.role==='iam'?'assistant':h.role,content:h.text}));const out=await model.chat.completions.create({messages:[{role:'system',content:'You are IAM AI, an educational artist-management tutor. Ground factual statements ONLY in supplied library context, do not invent citations, statutes, royalty rates, video links or current policies. If evidence is weak, say so. Never present legal advice. Focus on mode: '+mode+'. Give specific helpful next steps. SOURCES:\n'+context},...recent],temperature:0.3,max_tokens:440});const generated=out.choices?.[0]?.message?.content?.trim();if(generated)answer=generated;else throw Error('No text generated')}catch(error){ui.modelState.textContent='Local model could not answer. Knowledge Study Mode remains available. '+String(error.message||error).slice(0,150);answer=f.answer}}
 think.remove();ui.messages.removeAttribute('aria-busy');msg('iam',answer,topics,f.task);remember('iam',answer);videos(topics,q);ui.status.textContent=(model?'Local AI answer · ':'Curated knowledge answer · ')+(topics.length?topics.length+' matched topic(s); verify references below.':'no strong source match.');if(ui.speak.checked)await speak(answer);ui.ask.disabled=false;loading=false;window.dispatchEvent(new CustomEvent('iam:answer-finished',{detail:{question:q,answer:answer}}));}
ui.ask.addEventListener('click',respond);ui.question.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();respond()}});
document.querySelectorAll('[data-mode]').forEach(btn=>btn.addEventListener('click',()=>{mode=btn.dataset.mode;document.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('active',x===btn));ui.status.textContent=({ask:'Ask anything about artist management',simple:'Beginner-friendly explanation mode',deep:'Deeper study from multiple source notes',case:'Practical case study mode',quiz:'Question and revision mode',interview:'Interview practice mode',contract:'Contract simulation mode',video:'Relevant videos and source material'})[mode];ui.question.focus()}));
ui.model.addEventListener('click',async()=>{if(model||loading)return;if(!navigator.gpu){ui.modelState.textContent='WebGPU is unavailable. Source-grounded Knowledge Study Mode is ready to use.';return}ui.model.disabled=true;ui.modelState.textContent='Downloading the optional open-weight model on your device. This could use hundreds of MB or more. Please wait; no inference API is called.';try{const llm=await import('https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm@0.2.80/+esm');const listing=llm.prebuiltAppConfig.model_list.filter(x=>/(0\.5B|360M|1B)/i.test(x.model_id));const chosen=listing.sort((a,b)=>Number(a.vram_required_MB||1e8)-Number(b.vram_required_MB||1e8))[0];if(!chosen)throw Error('No tested low-memory model entry is advertised by this WebLLM version');ui.modelState.textContent='Preparing '+chosen.model_id+' (model files downloaded once, then cached where possible)…';model=await llm.CreateMLCEngine(chosen.model_id,{initProgressCallback:p=>{ui.modelState.textContent='Local model: '+String(p.text||Math.round((p.progress||0)*100)+'%')}});ui.modelState.textContent='Local model ready: '+chosen.model_id+'. Answers are generated on this device using the IAM library.';ui.model.textContent='Local AI enabled';}catch(error){ui.modelState.textContent='Local language model unavailable: '+String(error.message||error).slice(0,220)+'. You can still use source-grounded study mode.';ui.model.disabled=false}});
async function speak(text){stopSpeaking();if(!('speechSynthesis' in window)){ui.voiceState.textContent='Spoken replies are not supported by this browser.';return}return new Promise(resolve=>{const u=new SpeechSynthesisUtterance(String(text).slice(0,2600));u.lang='en-NG';u.rate=0.96;u.pitch=1;let done=false;const finish=()=>{if(done)return;done=true;speaking=false;resolve()};u.onend=finish;u.onerror=finish;speaking=true;ui.voiceState.textContent='Speaking aloud';speechSynthesis.speak(u);window.setTimeout(()=>{if(speaking){speechSynthesis.cancel();finish()}},50000)})}
function stopSpeaking(){if('speechSynthesis' in window)window.speechSynthesis.cancel();speaking=false}
ui.stop.addEventListener('click',()=>{stopSpeaking();if(recorder&&recorder.state!=='inactive'){recorder.stop();micStream?.getTracks().forEach(t=>t.stop());recorder=null;ui.voiceState.textContent='Recording stopped.'}else ui.voiceState.textContent='Voice playback stopped.'});
async function transcribe(blob){ui.voiceState.textContent='Processing audio locally. Please wait…';if(!asr){const {pipeline}=await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/+esm');ui.voiceState.textContent='Downloading a local English speech model. This may consume significant data.';asr=await pipeline('automatic-speech-recognition','onnx-community/whisper-tiny.en',{device:navigator.gpu?'webgpu':'wasm',dtype:'q8'})}
 const bytes=await blob.arrayBuffer();const audioContext=new (window.AudioContext||window.webkitAudioContext)();try{const decoded=await audioContext.decodeAudioData(bytes);const target=16000;const duration=Math.min(decoded.duration,25);const output=new Float32Array(Math.ceil(duration*target));const channel=decoded.getChannelData(0);for(let i=0;i<output.length;i++){const pos=Math.floor(i*decoded.sampleRate/target);output[i]=channel[Math.min(pos,channel.length-1)]}const result=await asr(output);return String(result.text||'').trim()}finally{await audioContext.close()}}
ui.voice.addEventListener('click',async()=>{if(recorder&&recorder.state==='recording'){recorder.stop();ui.voice.disabled=true;return}if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){ui.voiceState.textContent='Microphone recording is unsupported in this browser. Switch to text.';return}try{stopSpeaking();micStream=await navigator.mediaDevices.getUserMedia({audio:true});recorded=[];recorder=new MediaRecorder(micStream);recorder.ondataavailable=e=>{if(e.data.size)recorded.push(e.data)};recorder.onstop=async()=>{micStream?.getTracks().forEach(t=>t.stop());ui.voice.disabled=false;ui.voice.textContent='🎙 Talk to IAM';try{const text=await transcribe(new Blob(recorded,{type:recorder.mimeType||'audio/webm'}));if(text){ui.question.value=text;ui.voiceState.textContent='Transcription ready. Review or correct it, then press Ask IAM AI.';ui.question.focus()}else ui.voiceState.textContent='No words recognized. Try recording again.'}catch(e){ui.voiceState.textContent='Local transcription failed or is unsupported: '+String(e.message||e).slice(0,180)+'. Type your question instead.'}};recorder.start();ui.voice.textContent='■ Finish recording';ui.voiceState.textContent='Listening on your device. Speak for up to 25 seconds, then finish recording.';setTimeout(()=>{if(recorder?.state==='recording')recorder.stop()},25000)}catch(e){ui.voiceState.textContent='Microphone not available or permission declined. Switch to text.'}});
ui.notes.addEventListener('change',save);el('v16-save-notes').addEventListener('click',()=>{save();ui.noteState.textContent='Notes saved on this device.'});el('v16-download-notes').addEventListener('click',()=>{const blob=new Blob([ui.notes.value],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='IAM-AI-study-notes.txt';a.click();URL.revokeObjectURL(url)});el('v16-clear').addEventListener('click',()=>{if(!confirm('Delete the conversation and notes saved on this device?'))return;history=[];ui.notes.value='';try{localStorage.removeItem(KEY)}catch{};ui.messages.replaceChildren();msg('iam','Your local conversation and notes have been cleared.');ui.noteState.textContent='Saved data cleared.'});
ui.device.textContent=navigator.gpu?'WebGPU detected · advanced local AI available to try':'Knowledge Study Mode · no WebGPU detected';
fetch('/api/iam-ai/library',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()}).then(data=>{if(!Array.isArray(data.topics)||!Array.isArray(data.sources))throw Error('Unexpected library format');kb=data;ui.count.textContent=data.topics.length+' approved topics · '+data.sources.length+' attributed resources. Search and practise free of AI credits.';for(const t of kb.topics){const btn=element('button','v16-topic',t.title);btn.type='button';addText(btn,'small','IAM Module '+t.module);btn.addEventListener('click',()=>{ui.question.value='Explain '+t.title;document.getElementById('v16-workspace').scrollIntoView({behavior:'smooth'});respond()});ui.topics.append(btn)}ui.status.textContent='Ready: '+kb.topics.length+' approved study topics. Ask your first question.'}).catch(e=>{ui.status.textContent='Knowledge library did not load. Please reload IAM AI or try again later: '+String(e.message||e)});


/* IAM AI v23: consent-based voice turns, genuine microphone activity and mobile recognition fallback.
 * Browser speech recognition may use services provided by the browser vendor.
 * Offline local Whisper is used when browser recognition is not available.
 */
const v17={text:el('v17-text-tab'),voice:el('v17-voice-tab'),stage:el('v17-voice-stage'),orb:el('v17-voice-orb'),live:el('v17-voice-live'),start:el('v17-voice-start'),mute:el('v17-mute'),end:el('v17-end'),transcript:el('v17-transcript-edit'),send:el('v17-use-transcript')};
const v23={logo:el('v23-logo-mic'),meter:el('v23-voice-meter'),skip:el('v23-skip-intro')};
let v23active=false,v23muted=false,v23busy=false,v23stream=null,v23context=null,v23analyser=null,v23frame=0,v23recognition=null,v23recorder=null,v23chunks=[],v23speech=false,v23noise=.008,v23speakTime=0,v23silenceTime=0,v23recordTime=0,v23watch=0,v23session=0,v23welcomeFinish=null,v23state='off';
const V23Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
function v23Status(message,state='idle'){
 v23state=state;v17.live.textContent=message;v17.orb.dataset.state=state;
 v23.logo?.setAttribute('data-state',state);v23.logo?.setAttribute('aria-label',state==='hearing'?'IAM is hearing your voice':state==='listening'?'IAM microphone listening':'IAM microphone inactive');
 if(v23.meter){v23.meter.dataset.state=state;v23.meter.setAttribute('aria-label',state==='hearing'?'Microphone detects your voice':state==='listening'?'Microphone open, waiting for speech':'Microphone not listening');}
}
function v23Meter(){
 if(!v23active||!v23analyser)return;
 const samples=new Float32Array(v23analyser.fftSize);v23analyser.getFloatTimeDomainData(samples);
 let total=0;for(const sample of samples)total+=sample*sample;const rms=Math.sqrt(total/samples.length);
 if(v23state==='listening'||v23state==='hearing'){
  const threshold=Math.max(.012,v23noise*2.7);
  const hearing=rms>threshold;
  v23noise=Math.min(.03,v23noise*.985+Math.min(rms,.04)*.015);
  if(hearing&&v23state!=='hearing')v23Status('Hearing your voice…','hearing');
  if(!hearing&&v23state==='hearing')v23Status('Listening… please speak naturally.','listening');
  if(v23.meter)v23.meter.style.setProperty('--mic-level',String(Math.max(0,Math.min(1,(rms-threshold)*21))));v23.meter.style.setProperty('--mic-low-height',(6+Math.round(Math.max(0,Math.min(1,(rms-threshold)*21))*10))+'px');v23.meter.style.setProperty('--mic-high-height',(9+Math.round(Math.max(0,Math.min(1,(rms-threshold)*21))*20))+'px');
  if(v23recorder&&v23recorder.state==='recording'){
   const now=performance.now();if(hearing){v23speech=true;v23silenceTime=0;}
   else if(v23speech){if(!v23silenceTime)v23silenceTime=now;
    if(now-v23silenceTime>1250&&now-v23recordTime>1500){v23FinishLocal();}}
   if(now-v23recordTime>22000){v23FinishLocal();}
  }
 }
 v23frame=requestAnimationFrame(v23Meter);
}
function v23StopRecognition(){if(v23recognition){const rec=v23recognition;v23recognition=null;rec.onend=rec.onerror=rec.onresult=null;try{rec.abort()}catch{}}if(v23recorder&&v23recorder.state==='recording'){try{v23recorder.stop()}catch{}}v23recorder=null;v23chunks=[];}
function v23Release(){v23StopRecognition();if(v23frame)cancelAnimationFrame(v23frame);v23frame=0;if(v23watch)clearTimeout(v23watch);v23watch=0;
 if(v23stream){v23stream.getTracks().forEach(track=>track.stop());v23stream=null;}
 if(v23context){v23context.close().catch(()=>{});v23context=null;}v23analyser=null;v23.meter?.style.setProperty('--mic-level','0');}
function v23End(message='Microphone off. Session ended.'){
 v23active=false;v23muted=false;v23busy=false;v23session++;
 if(v23welcomeFinish)v23welcomeFinish();v23Release();stopSpeaking();
 v23.skip.hidden=true;v17.start.disabled=false;v17.mute.disabled=true;v17.end.disabled=true;v17.mute.textContent='Mute microphone';
 v23Status(message,'off');
}
function v23Tabs(mode){const selected=mode==='voice';v17.stage.hidden=!selected;v17.text.setAttribute('aria-pressed',String(!selected));v17.voice.setAttribute('aria-pressed',String(selected));if(!selected)v23End();else document.querySelector('#v16-workspace')?.scrollIntoView({behavior:'smooth',block:'start'});}
v17.text.addEventListener('click',()=>v23Tabs('text'));v17.voice.addEventListener('click',()=>v23Tabs('voice'));v17.end.addEventListener('click',()=>v23End());
function v23Welcome(){
 const prompt='Hello, I am IAM AI. After this introduction, you can speak your question. I am ready to listen.';
 v23Status('IAM AI is introducing itself. Listening will begin next.','speaking');v23.skip.hidden=false;
 return new Promise(resolve=>{
  let done=false,timeout;const finish=()=>{if(done)return;done=true;clearTimeout(timeout);v23welcomeFinish=null;v23.skip.hidden=true;resolve()};v23welcomeFinish=()=>{stopSpeaking();finish()};
  if(!('speechSynthesis' in window)){finish();return;}
  try{const line=new SpeechSynthesisUtterance(prompt);line.lang='en-NG';line.rate=1.05;line.onend=finish;line.onerror=finish;window.speechSynthesis.cancel();window.speechSynthesis.speak(line);timeout=setTimeout(()=>{window.speechSynthesis.cancel();finish()},14000);}catch{finish()}
 });
}
v23.skip.addEventListener('click',()=>v23welcomeFinish?.());
async function v23Process(text){if(!v23active||v23muted||v23busy)return;
 const heard=String(text||'').trim();if(!heard){v23Status('No clear words detected. Listening again.','listening');return v23Listen();}
 v23busy=true;v23StopRecognition();v23Status('Heard: '+heard+' · Preparing your reply…','thinking');v17.transcript.value=heard;ui.question.value=heard;
 try{await respond();}catch(error){v23Status('I could not complete that reply: '+String(error.message||error).slice(0,90),'muted')}
 finally{v23busy=false;if(v23active&&!v23muted){v23Status('Ready for another question.','listening');v23watch=setTimeout(()=>v23Listen(),350)}}
}
function v23BrowserListen(){
 const rec=new V23Recognition();v23recognition=rec;rec.lang='en-NG';rec.continuous=false;rec.interimResults=true;rec.maxAlternatives=1;
 let captured='';const session=v23session;
 rec.onresult=event=>{if(!v23active||v23muted||session!==v23session)return;
  let partial='',final='';for(let i=event.resultIndex;i<event.results.length;i++){const item=event.results[i];const txt=item[0]?.transcript||'';if(item.isFinal)final+=txt;else partial+=txt;}
  if(partial){v17.transcript.value=partial;v23Status('Hearing: '+partial.slice(0,90),'hearing');}
  if(final){captured=final;v23Process(final)}
 };
 rec.onerror=event=>{if(!v23active||v23muted||v23busy||session!==v23session)return;
  if(['not-allowed','service-not-allowed','audio-capture'].includes(event.error)){v23StopRecognition();v23Status('Browser recognition is unavailable. Switching to local audio processing.','thinking');v23watch=setTimeout(()=>v23LocalListen(),350)}
  else if(event.error==='no-speech'){v23Status('No words heard yet. Listening again.','listening');}
  else v23Status('Speech detection interrupted. Trying again.','listening');
 };
 rec.onend=()=>{if(v23recognition!==rec||session!==v23session)return;v23recognition=null;
  if(v23active&&!v23muted&&!v23busy){v23watch=setTimeout(()=>v23Listen(),450);}
 };
 try{rec.start();v23Status('Listening… ask a question. The meter reacts to your voice.','listening')}
 catch(error){v23recognition=null;v23LocalListen();}
}
function v23FinishLocal(){const rec=v23recorder;if(rec?.state==='recording'){v23Status('Recognising your question on this device…','thinking');try{rec.stop()}catch{}}}
function v23LocalListen(){if(!v23active||v23muted||v23busy)return;
 if(!window.MediaRecorder||!v23stream){v23Status('Voice capture is unsupported here. Use Chat or send a corrected transcript.','muted');return}
 try{const rec=new MediaRecorder(v23stream);v23recorder=rec;v23chunks=[];v23speech=false;v23silenceTime=0;v23recordTime=performance.now();const session=v23session;
  rec.ondataavailable=e=>{if(session===v23session&&e.data.size)v23chunks.push(e.data)};
  rec.onstop=async()=>{if(session!==v23session||!v23active||v23muted||v23busy)return;
    v23busy=true;v23Status('Transcribing locally; first use may download a speech model…','thinking');
    const blob=new Blob(v23chunks,{type:rec.mimeType||'audio/webm'});v23recorder=null;
    try{const result=await transcribe(blob);v23busy=false;return v23Process(result)}
    catch(error){v23busy=false;v23Status('Local transcription unavailable: '+String(error.message||error).slice(0,80)+'. Use Chat or corrected transcript.','muted')}
  };
  rec.start();v23Status('Listening locally… ask a question and pause when finished.','listening');
 }catch(error){v23Status('Audio recording failed: '+String(error.message||error).slice(0,90)+'. Use Chat.','muted')}
}
function v23Listen(){if(!v23active||v23muted||v23busy||!v23stream)return;v23StopRecognition();v23noise=.008;
 if(V23Recognition)v23BrowserListen();else v23LocalListen();}
v17.start.addEventListener('click',async()=>{
 if(v23active)return;
 if(!navigator.mediaDevices?.getUserMedia||!(window.AudioContext||window.webkitAudioContext)){v23Status('No microphone access in this browser. Use text chat.','muted');return;}
 v23active=true;v23muted=false;v23busy=true;v23session++;v17.start.disabled=true;v17.mute.disabled=false;v17.end.disabled=false;ui.speak.checked=true;
 v23Status('Requesting microphone permission…','thinking');const session=v23session;
 try{v23stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
  if(!v23active||session!==v23session)return;
  v23context=new (window.AudioContext||window.webkitAudioContext)();if(v23context.state==='suspended')await v23context.resume();
  const source=v23context.createMediaStreamSource(v23stream);v23analyser=v23context.createAnalyser();v23analyser.fftSize=1024;source.connect(v23analyser);v23Meter();
  await v23Welcome();if(!v23active||session!==v23session)return;
  v23busy=false;v23Listen();
 }catch(error){v23End('Microphone unavailable or permission declined. You can still use text chat.');}
});
v17.mute.addEventListener('click',()=>{if(!v23active)return;v23muted=!v23muted;v17.mute.textContent=v23muted?'Unmute microphone':'Mute microphone';
 if(v23muted){v23StopRecognition();v23Status('Microphone muted. Tap Unmute when ready.','muted')}
 else if(!v23busy)v23Listen();});
v17.send.addEventListener('click',async()=>{const txt=v17.transcript.value.trim();if(!txt)return;v23busy=false;v23StopRecognition();await v23Process(txt);});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&v23active){v23muted=true;v23StopRecognition();v17.mute.textContent='Unmute microphone';v23Status('Microphone paused while the page is hidden. Tap Unmute to resume.','muted')}});
window.addEventListener('pagehide',()=>v23End());
if(new URLSearchParams(location.search).get('mode')==='voice')v23Tabs('voice');
