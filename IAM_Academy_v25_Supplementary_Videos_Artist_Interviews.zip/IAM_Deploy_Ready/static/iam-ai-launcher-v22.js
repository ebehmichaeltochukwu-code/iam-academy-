(()=>{
'use strict';
const trigger=document.getElementById('v17-float-trigger'),panel=document.getElementById('v17-float-window'),frame=document.getElementById('v17-float-frame'),close=document.getElementById('v17-float-close'),expand=document.getElementById('v22-ai-expand');
if(!trigger||!panel||!frame||!close||!expand)return;
let previousFocus=null;
const notifyFrame=()=>{
 if(!frame.contentWindow||frame.src==='about:blank')return;
 frame.contentWindow.postMessage({type:'iam:companion-layout',expanded:panel.classList.contains('v22-expanded')},location.origin);
};
const setExpanded=value=>{
 panel.classList.toggle('v22-expanded',value);
 document.body.classList.toggle('v22-ai-expanded',value);
 expand.setAttribute('aria-pressed',String(value));
 expand.setAttribute('aria-label',value?'Return IAM AI to compact view':'Expand IAM AI to full screen');
 expand.title=value?'Return to compact view':'Expand to full screen';
 expand.innerHTML=value?'⊟ <span>Compact view</span>':'⛶ <span>Full view</span>';
 notifyFrame();
};
const hide=()=>{
 setExpanded(false);panel.hidden=true;trigger.setAttribute('aria-expanded','false');
 frame.src='about:blank';
 (previousFocus&&previousFocus.isConnected?previousFocus:trigger).focus();
};
trigger.addEventListener('click',()=>{
 if(!panel.hidden)return hide();
 previousFocus=document.activeElement;panel.hidden=false;trigger.setAttribute('aria-expanded','true');
 if(!frame.src||frame.src==='about:blank')frame.src=frame.dataset.url;
 close.focus();
});
close.addEventListener('click',hide);
expand.addEventListener('click',()=>setExpanded(!panel.classList.contains('v22-expanded')));
frame.addEventListener('load',notifyFrame);
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){e.preventDefault();hide()}});
})();
