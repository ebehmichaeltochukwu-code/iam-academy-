(()=>{
if(!new URLSearchParams(location.search).has('embed'))return;
window.addEventListener('message',event=>{
 if(event.origin!==location.origin||event.source!==window.parent)return;
 if(!event.data||event.data.type!=='iam:companion-layout')return;
 document.body.classList.toggle('v22-embed-expanded',event.data.expanded===true);
});
})();
