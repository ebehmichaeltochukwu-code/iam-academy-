# IAM Academy v23 | 13-Week Enriched Classroom, Videos & Voice

**Status:** Release package for GitHub upload and Railway deployment. Not live until the Railway service loads this ZIP and `/health` returns 200.

## Included

1. Original 13-week programme preserved: 24 graded-core lessons across Weeks 1–8 and five applied modules in Weeks 9–13.
2. Twenty-four lesson-specific professional reading extensions, Nigerian and international scenarios, decision labs, evidence tasks, and further-reading links. Accessible only inside the existing approved, paid student area; admin preview retains read-only access.
3. Eight core quizzes expanded from 4 to 8 unique MCQs per week, with 75% pass threshold, unlimited attempts and the existing grading/recording logic preserved. Previously recorded student attempts stay intact.
4. Weeks 9–13 include additional professional chapters and self-review questions, including artist interviews, genuine behind-the-scenes engagement and post-release editorial scheduling. Existing capstone and portfolio projects retained.
5. Removes repetition of the same "Your Guide to Spotify for Artists" video from unrelated lessons. Lesson-specific supplementary video choices now come from the existing identified IAM video library. Where no relevant verified supplementary clip exists, the lesson displays its original main video and topic-specific source reading, rather than an irrelevant extra.
6. In-classroom expanded video theatre for original and embedded content. Clicking a supplementary video title or **Expand video in IAM** enlarges playback without requiring an external tab, subject to original publisher embedding policies.
7. IAM AI student voice updates: explicit mic permission, intro skip button, microphone amplitude-driven icon and level bars, continuous question-turn restart, and browser speech recognition with an optional device-local model fallback. Browser speech recognition may use browser-vendor services; this does not add a paid AI inference API or usage credits. Microphone is muted when the page loses visibility.
8. Original IAM branding, payment configuration, admin login, /data mounted persistent database, certificate eligibility rules and existing class routes unchanged.

## Testing

- Python module compilation: passed.
- Node JavaScript syntax: passed for the new video player and updated IAM AI voice script.
- Automated regression suite: 47 passed.
- Real-device microphone behaviour, third-party video availability/embedding and browser visual layout require post-deploy checks. An independent browser rendering attempt in the sandbox was blocked by browser network policy.

## Sources & permissions

- Third-party embedded video content remains on its publisher's YouTube servers; IAM does not rehost it.
- Official publisher pages are linked where a suitable, individually verified direct video ID is not available.
- Artist stories cited are linked to their official publisher articles, not presented as made-up video interviews.
- Music contracts, royalties and jurisdictions are presented as educational concepts, not legal advice.

## Production safety

Keep the existing `IAM_DATABASE=/data/iam.db`, attached Railway `/data` volume, administrator settings and environment secrets. No database or private credential files are included in this ZIP.
