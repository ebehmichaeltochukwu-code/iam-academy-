import re
from fastapi.testclient import TestClient
import app as iam

def token(c,route):
 html=c.get(route).text
 m=re.search(r'name="csrf"[^>]*value="([^"]+)"',html)
 assert m, route
 return m.group(1)

def add(c,email,role='student',paid='paid'):
 with iam.db() as db:
  db.execute('INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,?,?,?)',('Example Test Student',email,iam.password_hash('VeryGoodPassword123!'),role,'approved',paid))
 s=token(c,'/login')
 res=c.post('/login',data=dict(email=email,password='VeryGoodPassword123!',csrf=s),follow_redirects=False)
 assert res.status_code==303

def test_home_seo_and_career_public(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'one.db');iam.init_db()
 with TestClient(iam.app) as c:
  html=c.get('/').text
  assert 'YOUR ₦100,000 LEARNING PACKAGE' in html
  assert 'Ten practical portfolio projects' in html
  assert 'iam-favicon-v9.png' in html
  assert 'career-v9.css' in html
  assert c.get('/career-information').status_code==200
  assert 'Portfolio' in c.get('/career-information').text or 'portfolio' in c.get('/career-information').text
  assert b'career-information' in c.get('/sitemap.xml').content
  assert '/admin' in c.get('/robots.txt').text
  with iam.db() as d:assert d.execute('SELECT SUM(hits) FROM public_pageviews').fetchone()[0]>=2
  assert c.get('/admin/analytics',follow_redirects=False).status_code==303


def test_personal_portfolio_privacy_and_export(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'two.db');iam.init_db()
 a,b=TestClient(iam.app),TestClient(iam.app)
 add(a,'first@iam.example')
 add(b,'second@iam.example')
 assert a.get('/career').status_code==200
 assert b'WORKING TEMPLATE' in a.get('/career/toolkit/1.txt').content
 assert a.post('/career/project/1',data={'body':'not allowed','csrf':'wrong'}).status_code==400
 auth=token(a,'/career/project/1')
 sent=a.post('/career/project/1',data={'csrf':auth,'body':'Artist confidential notes should stay private <script>bad()</script>'},follow_redirects=False)
 assert sent.status_code==303
 assert 'Artist confidential notes' in a.get('/career/project/1').text
 assert '&lt;script&gt;' in a.get('/career/project/1').text
 assert 'Artist confidential notes' not in b.get('/career/project/1').text
 pdf=a.get('/career/portfolio.pdf')
 assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
 assert 'private' in pdf.headers['cache-control']
 assert b.get('/career/portfolio.pdf').status_code==200
 assert a.get('/graduate-opportunities').status_code==200
 assert 'Your private opportunities board unlocks after graduation' in a.get('/graduate-opportunities').text
 a.close();b.close()


def test_admin_opportunities_validation_and_grad_gate(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'three.db');iam.init_db()
 admin,student=TestClient(iam.app),TestClient(iam.app)
 add(admin,'admin@iam.example',role='admin')
 add(student,'student@iam.example')
 assert student.get('/admin/opportunities',follow_redirects=False).status_code==303
 assert admin.get('/admin/opportunities').status_code==200
 csrf=token(admin,'/admin/opportunities')
 payload={'csrf':csrf,'title':'Junior Artist Relations Specialist','organization':'Example Label','location':'Remote','work_type':'Contract','url':'javascript:alert(1)','note':'Check source independently','deadline':'2026-11-29'}
 assert admin.post('/admin/opportunities',data=payload).status_code==400
 payload['url']='https://example.org/careers/123'
 assert admin.post('/admin/opportunities',data=payload,follow_redirects=False).status_code==303
 assert 'Junior Artist Relations' in admin.get('/admin/opportunities').text
 assert 'Junior Artist Relations' not in student.get('/graduate-opportunities').text
 with iam.db() as db:
  uid=db.execute("SELECT id FROM users WHERE email='student@iam.example'").fetchone()['id']
  db.execute("INSERT INTO certificates (user_id,code) VALUES (?,'IAM-TEST-GRAD-1')",(uid,))
 assert 'Junior Artist Relations' in student.get('/graduate-opportunities').text
 with iam.db() as db:jobid=db.execute('SELECT id FROM career_opportunities').fetchone()['id']
 assert admin.post(f'/admin/opportunities/{jobid}/disable',data={'csrf':csrf},follow_redirects=False).status_code==303
 assert 'Junior Artist Relations' not in student.get('/graduate-opportunities').text
 assert admin.get('/admin/analytics').status_code==200
 admin.close();student.close()

def test_paid_access_gate(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'four.db');iam.init_db()
 a=TestClient(iam.app)
 add(a,'unpaid@iam.example',paid='unpaid')
 for path in ['/career','/career/project/2','/career/toolkit/2.txt','/career/portfolio.pdf','/graduate-opportunities']:
  assert a.get(path,follow_redirects=False).status_code==303,path
 a.close()
