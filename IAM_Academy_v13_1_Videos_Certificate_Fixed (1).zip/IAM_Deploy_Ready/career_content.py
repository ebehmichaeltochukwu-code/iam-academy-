"""IAM-owned practice briefs and curated third-party discovery resources.
External resource URLs checked 2026-10-17. Videos remain owned by the uploaders.
"""
PORTFOLIO = [
    dict(week=1, title='Artist discovery and ethical representation brief', file='01_artist_audit.txt',
         purpose='Evaluate a prospective artist without making promises or claiming rights you do not hold.',
         deliverable='Two-page artist audit, 10-question discovery interview, decision-rights matrix and 30-day onboarding checklist.',
         sections=[('The artist and goals','Describe a fictional artist or a consenting real artist: genre, hometown, catalogue, three clear career goals and the evidence available.'),('Evidence audit','List songs, ownership documentation, collaborators, live history, audience metrics and current contracts. Mark unknown facts as UNVERIFIED.'),('Responsibilities','Identify what the artist decides, what the manager coordinates, and when a lawyer or accountant must advise.'),('30-day action plan','Write five priority actions with owners, dates, risks and success indicators.')],
         checklist=['Ground claims in verifiable evidence','Respect artist consent and confidential information','Do not provide legal advice','List accountable owners and dates']),
    dict(week=2,title='Music listening and creative feedback report',file='02_song_review.txt',
         purpose='Make a constructive, artist-centred assessment of one song, not a personal taste review.',
         deliverable='Song structure map, three strengths, two measurable tests and a supportive feedback script.',
         sections=[('Song observations','List timings for intro, verse, hook, bridge and outro of an artist-approved or fictional song.'),('Audience and identity','Who is the intended listener? Explain why the track fits or challenges the artist identity.'),('Feedback script','Use observation, likely impact, proposed test and artist choice. Avoid ultimatums.'),('Evidence of improvement','Suggest an A/B listener test and define how you will judge the result.')],
         checklist=['Respect creative ownership','Use evidence rather than insults','Propose practical A/B testing','Get artist approval']),
    dict(week=3,title='Manager communication and crisis-response kit',file='03_communication_kit.txt',
         purpose='Handle professional conflict without harming relationships or public trust.',
         deliverable='Decision log, disagreement script, team responsibility map and one-page incident response plan.',
         sections=[('Shared objective','Describe the dispute, the artist priorities and why it needs a decision.'),('Private conversation','Write a respectful 200-word manager–artist discussion using listening and options.'),('Escalation table','State when a lawyer, production manager, safeguarding lead or publicist must be contacted.'),('Incident response','Draft a first-hour checklist prioritizing safety and verified facts.')],
         checklist=['Listen before deciding','Do not disclose private information','Escalate safety risks promptly','Document decisions with consent']),
    dict(week=4,title='Music rights and royalty readiness checklist',file='04_rights_checklist.txt',
         purpose='Map common rights questions and recognize when legal expertise is needed.',
         deliverable='Rights inventory and checklist for master recordings, compositions, splits and distribution.',
         sections=[('Work and collaborators','List a hypothetical single: songwriters, producers, performers, release name and identifiers.'),('Rights mapping','Separate composition, sound recording, publishing, master ownership and distribution permissions.'),('Royalty pathways','Describe potential collection channels, territories and what remains to verify.'),('Questions for counsel','Write five questions to send to a qualified Nigerian entertainment lawyer.')],
         checklist=['Do not assume ownership','Capture written split confirmations','Distinguish master from composition','Refer binding legal advice to counsel']),
    dict(week=5,title='Audience and six-week release marketing plan',file='05_release_campaign.txt',
         purpose='Design an ethical, measurable campaign for an emerging artist.',
         deliverable='Audience persona, channel calendar, modest budget, asset list and reporting dashboard.',
         sections=[('Audience research','Define one listener segment and identify qualitative and quantitative evidence.'),('Six-week calendar','List pre-release, launch and follow-up actions by week and owner.'),('Budget','Include creative, distribution, promotion, contingency and measurement costs with totals.'),('Metrics and review','Specify saves, engaged fans, video retention, email signups and qualitative feedback.')],
         checklist=['Use clear consent for fan outreach','Do not buy fake streams','Specify budget ceilings','Review outcomes weekly']),
    dict(week=6,title='Live show and business budget workbook',file='06_budget_and_live.txt',
         purpose='Build basic financial discipline for one event or release.',
         deliverable='Itemized income/expense forecast, cash-flow dates, contracts checklist and post-show reconciliation.',
         sections=[('Show assumptions','Venue, audience size, ticket assumptions, travel and artist constraints.'),('Financial forecast','Show tickets, fees, sponsorships, promoter splits, transport, lodging, production and contingency.'),('Cash controls','Explain who can approve, spend, reconcile and access funds.'),('Risks and reporting','Model a low-attendance scenario and agree a break-even decision.')],
         checklist=['Keep receipts','Do not mix personal funds','Use clear approval thresholds','Test worst-case cash flow']),
    dict(week=7,title='Partnership evaluation and 12-month career roadmap',file='07_partnership_roadmap.txt',
         purpose='Compare offers and prioritize sustainable career development over hype.',
         deliverable='Partnership scorecard, risk register, professional team map and four-quarter career roadmap.',
         sections=[('Offer comparison','Compare two fictional partnerships on cash timing, rights, duration, exclusivity and termination.'),('Decision framework','Set six weighted criteria and explain why you chose them.'),('Career goals','Draft realistic quarterly targets for catalogue, audience, live, income and wellbeing.'),('Review ritual','Describe a monthly check-in and exit/renegotiation triggers.')],
         checklist=['Consider rights and future cost','Avoid guaranteed outcomes','Include wellbeing and rest','Document decisions']),
    dict(week=8,title='Professional artist-management capstone dossier',file='08_90_day_capstone.txt',
         purpose='Demonstrate career-ready judgement with an integrated 90-day management plan.',
         deliverable='Artist audit, 90-day roadmap, campaign, rights checklist, budget, risk register and decision record.',
         sections=[('Executive brief','Write the artist profile, why this strategy fits and three measurable goals.'),('90-day plan','Provide a timeline with owners, milestones, dependencies and revision points.'),('Working documents','Attach or paste the audit, budget, risk register, marketing plan and roles matrix.'),('Ethical decision memo','Present one difficult decision, alternatives considered and rationale.'),('Personal career pitch','Write a 100-word pitch for an entry-level artist-management or artist-services role.')],
         checklist=['Integrates at least four earlier portfolio artifacts','Measurable 90-day milestones','Accounts for finances, rights and risk','Clear writing and informed consent'])
]


# V10: Two *additional*, self-paced career masterclasses. These are optional
# enrichment and portfolio work, not newly imposed certificate requirements.
PORTFOLIO.extend([
    dict(week=9,title='Media interviews and artist representation',file='09_media_interview_kit.txt',
         purpose='Prepare an artist for credible radio, TV, podcast and online interviews while safeguarding their voice, privacy and public trust.',
         deliverable='One-page press kit, two ethical media pitches, interview briefing card, mock interview script and post-interview follow-up plan.',
         sections=[('The media opportunity','Choose a fictional or consenting artist. State the single newsworthy reason for an interview, relevant audience, the artist’s consent and what evidence backs the story.'),('The press kit','Draft a 90-word and 180-word biography, three key facts you can verify, an approved image list, listening links, social handles and one media contact.'),('Pitching and booking','Identify a suitable radio show, podcast and publication. Draft subject lines and three personalized outreach emails. No mass spam or fabricated press claims.'),('Interview briefing','Prepare three memorable messages, five anticipated questions, two respectful bridges back to the main story, and boundaries for private or legal questions.'),('Mock interview','Write a 10-minute interviewer/artist rehearsal covering an easy opener, an unexpected question, a sensitive question and the closing call-to-action.'),('After the appearance','Create an approval and follow-up workflow for fact checks, audio/video reuse rights, clips, thank-you note and measurement.')],
         checklist=['Artist approved the facts, story and media approach','Press kit and messages are specific and verifiable','Sensitive questions are handled without deception or privacy violations','Follow-up includes ethical reuse permissions and measurable results']),
    dict(week=10,title='Create genuine buzz and build an artist people talk about',file='10_artist_buzz_campaign.txt',
         purpose='Develop a culturally relevant, story-led campaign that earns public attention and turns curiosity into long-term fandom, without fake popularity or manufactured controversy.',
         deliverable='Four-week buzz campaign: distinctive artist story, community activation, creator brief, publicity calendar, budget, fan-conversion funnel and weekly scorecard.',
         sections=[('What is worth talking about?','Choose one true story, compelling musical moment or real community connection. Define what makes it useful or interesting beyond empty hype.'),('Audience and local relevance','Describe two listener groups and the communities, student spaces, gigs, creators and local media where they already gather; include a Nigerian-city-specific idea where relevant.'),('Four-week calendar','Plan a teaser, an authentic content moment, a small live/community activation, a press opportunity and fan follow-up. Name owners and check consent.'),('Creators and press','Write a fair, transparent creator collaboration brief and three targeted journalist/radio approaches. Label any paid placement accurately.'),('Conversion and measurement','Build a path from discovery to listening, saving, following, mailing-list signup or show attendance. Track meaningful engagement and costs, not vanity followers alone.'),('Risk and lasting value','Write a risk checklist: artist wellbeing, budgets, consent, copyright, platform rules, reputation, accessibility and what continues after campaign week four.')],
         checklist=['All attention-building ideas are truthful and artist-approved','No bought streams, fake followers, spam or staged scandals','Budget, owners and milestones are specific','Results measure genuine fans, not only impressions'])
])

# Original IAM practical teaching; the links are optional third-party resources.
BONUS_MASTERCLASSES = {
 9: dict(
     title='Media interviews and artist representation', subtitle='Help your artist speak confidently and make every media appearance useful.',
     outcomes=['Identify interviews that serve the artist, rather than chasing exposure at any cost',
               'Build a concise press kit and approach journalists respectfully',
               'Coach truthful, memorable answers and manage difficult questions without deception',
               'Turn a completed interview into approved, reusable material and long-term relationships'],
     chapters=[
       ('1. Select the right interview, not just the biggest platform',
        'Start with the artist’s current objective: a new release, a forthcoming concert, a creative milestone or a story that genuinely matters to listeners. Compare the platform’s audience, style, reputation, location and past interviews. A well-matched local radio programme in Port Harcourt can be more useful than a huge but unrelated audience. Ask whether the artist is comfortable with the format, whether the outlet will require payment, and what the appearance is intended to achieve. Record the artist’s approval before committing.'),
       ('2. Build the press kit and find the news angle',
        'Prepare a simple electronic press kit: a short and a long artist biography, release facts, approved professional images with permissions, working listening links, verified contact details and two or three possible interview topics. A news angle must be true. For example, explain what inspired a song or how a community project connects to the artist’s work. Avoid calling an emerging artist the number-one musician or claiming partnerships, awards or streams that cannot be verified. Tailor the pitch to each outlet instead of copying one message to every journalist.'),
       ('3. Pitch professionally and confirm expectations',
        'Research the journalist, show or programme before contacting them. Write a short subject line, one sentence that explains the relevant story, why their audience would care, and one clear invitation. If the interview is accepted, confirm date, time zone, location or link, duration, interviewer name, recording/republishing terms, transport and any sensitive areas requiring prior agreement. Do not assume a journalist will agree to approve all questions. Respect editorial independence while making the artist aware of the likely format.'),
       ('4. Coach the artist, without scripting away their personality',
        'Agree three central messages: who the artist is, what is new or meaningful, and where people can hear or support the work. Prepare five likely questions, then practise answers in the artist’s natural voice. A good answer is direct, specific and brief. For unexpected questions, pause, ask for clarification, or say honestly that a detail has not been confirmed. A bridge such as “What I can share is…” can return to an agreed subject without avoiding a legitimate question. Never coach an artist to invent a fact or attack a competitor.'),
       ('5. Respond to sensitive topics and protect trust',
        'Create a privacy and risk briefing: personal relationships, health, finances, allegations, contracts, security and unreleased material. The artist can decline to discuss private matters or refer legal matters to qualified counsel. If a statement would be inaccurate, correct it rather than improvising. If the discussion becomes hostile, remain calm, avoid escalating publicly and document any legitimate request for correction. A manager protects the artist’s wellbeing and reputation, not simply the day’s publicity.'),
       ('6. Capture value after the interview',
        'Thank the producer and interviewer. Confirm the rights and permissions before editing or redistributing clips. Share accurate quotes and approved segments with context, link viewers to an actual song, show or profile, and track meaningful outcomes. Record audience engagement, verified listening or mailing-list activity and new professional relationships. Reflect with the artist on what they handled well and what to improve for the next interview.')
     ],
     rehearsal='Simulation: An emerging Afrobeats artist has just released a track about returning home after several difficult years. A local radio host invites a 10-minute interview, then unexpectedly asks about a rumoured dispute with a former collaborator. Draft a one-page interview briefing, write five truthful model responses, practise a respectful privacy boundary, and create three post-interview actions.',
     reflections=['What is a newsworthy story that is actually true about this artist?',
                  'How do you protect the artist’s privacy without misleading the interviewer?',
                  'How will you know that the interview helped the artist’s long-term goals?'],
     self_checks=[('Should you promise a journalist exclusive access without the artist approving it?',
                   'No. Confirm the terms and obtain the artist’s consent first.'),
                  ('A host asks an unverified allegation. What is the professional response?',
                   'Avoid speculation, state what is verified or decline to address private/legal details, and seek qualified advice where needed.'),
                  ('What matters more than the interview view count?',
                   'Audience fit, truthful coverage, real listening or community response, and durable professional relationships.')],
     sources=[('Getting publicity as a musician — Musicians’ Union','https://musiciansunion.org.uk/career-development/career-guides/marketing-and-promotion/getting-press'),
              ('Preparing to speak and interview — Musicians’ Union','https://musiciansunion.org.uk/news/mu-orchestras-department-run-back-to-work-events-series')],
     video_search='https://www.youtube.com/results?search_query=artist+media+training+musician+radio+interview+preparation'
 ),
 10: dict(
     title='Create genuine buzz and build an artist people talk about', subtitle='Build a real story that travels, then turn attention into loyal fans.',
     outcomes=['Position an artist around a distinctive, true identity and audience',
               'Design media, fan, community and creator moments that people want to share',
               'Plan ethical promotion with a clear budget and documented rights',
               'Measure fan conversion, not only impressions or trending hashtags'],
     chapters=[
       ('1. Define what makes the artist memorable',
        '“Talk of the town” should mean that people genuinely discuss and recommend the artist, not that the team manufactured a scandal. Start by listening to the music and talking with the artist about identity, voice, influences, community and the specific fans the music serves. Find one strong story that is true: a distinctive performance, a meaningful collaboration, a local scene, a useful social cause or an unusual creative process. Write the story in one sentence, then ask a listener whether it interests them.'),
       ('2. Map the audience and the places conversations happen',
        'Name two audiences, the neighbourhoods or online communities they belong to, and where they actually discover music. This could include student events, nightlife venues, local radio, creator groups, TikTok, YouTube, Instagram, community events and streaming playlists. For a Port Harcourt-based artist, a well-planned live moment with relevant creators and local media may create stronger word of mouth than untargeted national advertising. Do not contact communities that have not consented to receive messages.'),
       ('3. Create repeatable moments rather than one empty viral stunt',
        'Plan three or four shareable moments: an honest behind-the-song clip, a short live performance, a collaborator duet, a fan question session or a documented community appearance. Ensure the music and artist’s personality remain central. Provide strong photos, short clips, accurate captions, clear listening links and accessible subtitles where possible. A teaser should lead somewhere meaningful, not create false urgency or promises.'),
       ('4. Work with journalists, DJs and creators fairly',
        'Prepare a compact electronic press kit. Approach a small list of relevant radio producers, podcasters, editors, playlist curators and content creators with personalized context. Explain why their audience may genuinely enjoy the music. Agree in writing on creator fees, deliverables, rights, disclosures and approval boundaries. Never buy fake streams, paid comments, undisclosed reviews or manufactured press. Transparency creates lasting credibility.'),
       ('5. Build a four-week release and conversation calendar',
        'Week one: research audience, prepare assets and gather baseline numbers. Week two: invite fans into the artist’s authentic story. Week three: schedule the best-fitting performance, interview or collaboration, with an opt-in call to action. Week four: share follow-up content, answer genuine audience questions and thank participants. Assign an owner, deadline, cost, consent checkpoint and useful outcome to every activity. Keep the workload sustainable for the artist.'),
       ('6. Measure attention that becomes genuine fandom',
        'Track relevant metrics: saves, returning listeners, meaningful comments, show inquiries, newsletter sign-ups with consent, ticket sales and creator referrals. Use platform analytics cautiously: views and likes are signals, not proof of paid customers or loyal fans. Compare against a baseline and estimate cost per useful outcome. Invite the artist into a review meeting to decide which activities should continue and which should stop.'),
       ('7. Protect the artist’s name and the long game',
        'Before a campaign goes live, consider safety, unwanted attention, cultural sensitivity, privacy, copyright, sponsorship disclosure, community relationships, accessible communications and budget limits. Prepare a proportionate plan for mistakes and corrections. The goal is not to make the artist famous overnight; it is to create meaningful reasons for the right people to discover, trust and return to the music.')
     ],
     rehearsal='Simulation: A new highlife/Afrobeats artist has ₦120,000 to promote a debut single in one Nigerian city. Design a four-week campaign using a truthful artist story, a local performance or community moment, one creator collaboration, one targeted interview, a budget, consent/rights checks and three fan-conversion metrics. Compare a realistic plan with a tempting offer to purchase 10,000 fake streams, and explain why you reject the latter.',
     reflections=['Why would real listeners want to tell a friend about this artist?',
                  'Which of your planned activities produces an actual relationship, not just a view?',
                  'How do you protect the artist when public attention grows quickly?'],
     self_checks=[('Is buying followers a reliable way to make an artist the talk of the town?',
                   'No. It inflates numbers without building real engagement and can violate platform rules.'),
                  ('What is one useful outcome after someone sees a campaign video?',
                   'They intentionally listen, save a track, follow with genuine interest, join an opt-in list or attend a show.'),
                  ('Should a paid creator endorsement be presented as an unsolicited opinion?',
                   'No. Make the paid relationship transparent and respect disclosure requirements.')],
     sources=[('Getting music press — Musicians’ Union','https://musiciansunion.org.uk/career-development/career-guides/marketing-and-promotion/getting-press'),
              ('Cultivating fans on new platforms — Spotify for Artists','https://artists.spotify.com/en/blog/cultivating-your-fanbase-on-emerging-platforms'),
              ('Sharing music on social media — Spotify for Artists','https://artists.spotify.com/blog/all-the-ways-to-share-your-songs-on-socials-from-spotify')],
     video_search='https://www.youtube.com/results?search_query=spotify+for+artists+music+marketing+fan+engagement+release+promotion'
 )
}

# Distinct videos below were confirmed by public YouTube search, not fabricated.
SUPPLEMENTARY_VIDEOS = [
 dict(id='g4XcSnJQd78', title='Your Guide to Spotify for Artists', source='Spotify for Artists', focus='Audience development and reporting'),
 dict(id='Dwo42-7Xjis', title='How to Pitch to Playlists', source='Spotify for Artists', focus='Release pitching and promotion'),
 dict(id='FmqifH4Ai9M', title='How to Use Analytics for Artists', source='YouTube Creators', focus='Understanding audience and content performance'),
 dict(id='4Q3s4ZyIKpM', title='The ULTIMATE Guide to Spotify for Artists', source='Andrew Southworth', focus='Hands-on artist analytics workflow'),
]
# Each module gets context-specific supplementary material. These are not IAM-owned.
MODULE_VIDEO_IDS = {
 1:['g4XcSnJQd78'],2:['FmqifH4Ai9M'],3:['g4XcSnJQd78'],4:['FmqifH4Ai9M'],
 5:['Dwo42-7Xjis','FmqifH4Ai9M'],6:['g4XcSnJQd78','4Q3s4ZyIKpM'],
 7:['4Q3s4ZyIKpM','Dwo42-7Xjis'],8:['g4XcSnJQd78','Dwo42-7Xjis','FmqifH4Ai9M']}
VIDEOS_BY_ID={v['id']:v for v in SUPPLEMENTARY_VIDEOS}

# Verified job discovery destinations; pages list changing external vacancies, NOT current IAM-posted offers.
CAREER_SOURCES = [
 dict(name='Music Business Worldwide Jobs',url='https://www.musicbusinessworldwide.com/jobs/',summary='Music labels, management, artist services, marketing and publishing roles worldwide.'),
 dict(name='Sony Music Careers',url='https://careers.sonymusic.com/',summary='Search Sony Music roles and check location/visa requirements.'),
 dict(name='Warner Music Group Careers',url='https://www.wmg.com/careers',summary='Global music roles including early-career routes and related teams.'),
 dict(name='Spotify Careers',url='https://www.spotifyjobs.com/',summary='Audio industry careers including creator, marketing, data and business operations.'),
]
CAREER_STEPS=[
 ('Build a one-page career CV','Highlight your IAM portfolio, professional judgement, tools and measurable results; do not invent experience.'),
 ('Create a 90-second introduction','Say who you help, the evidence in your portfolio and what you would contribute to a manager or label.'),
 ('Prepare two role-specific applications','Tailor a cover email and selection criteria to artist services, junior management, label operations or marketing.'),
 ('Research prospective employers','Create an evidence-based list of ten Nigerian labels, talent agencies or independent managers, with contacts obtained ethically.'),
 ('Track outreach and responses','Record where you applied, follow-up dates and interview reflections; avoid mass-spam or misleading representation.'),
]

# Public learning map: 8 foundation modules with graded tasks + 2 advanced
# applied modules with guided self-assessment. New modules do not retroactively
# change core certificate eligibility or existing student progress.
ADVANCED_MODULES = [
    dict(number=n, title=BONUS_MASTERCLASSES[n]['title'],
         outcome=BONUS_MASTERCLASSES[n]['subtitle'],
         scenario=PORTFOLIO[n-1]['deliverable'],
         theme='Media readiness' if n==9 else 'Artist publicity',
         href=f'/career/masterclass/{n}') for n in (9,10)
]


# V12 supplementary videos: published course resources, not IAM-owned.
# The external organisation-hosted recordings have an accessible source page,
# while the YouTube music-education videos use IDs already verified by IAM.
# All applied-module videos render in IAM lesson pages. Local IAM scenario videos are captioned visual case studies.
APPLIED_MODULE_VIDEOS = {
 9: [
  dict(title='IAM Scenario: A Surprise Radio Interview',source='IAM original captioned simulation',format='local',src='/static/iam-scenarios/media-interview.mp4',
       description='A practical five-scene simulation: confirm the station brief, prepare messages, respond ethically, and rehearse a difficult interview.'),
  dict(title='Media Interview Best Practices Guide',source='ASTHO / Klick Health',format='youtube',id='nANkJlwZo0w',
       description='Prepare three clear messages, anticipate challenging questions, and practise a credible response. Originally produced for professional spokespeople; apply the methods to artist representation.'),
 ],
 10: [
  dict(title='IAM Scenario: Spotify Release Campaign',source='IAM original captioned simulation',format='local',src='/static/iam-scenarios/spotify-release.mp4',
       description='A five-scene Lagos artist case study. Plan a lawful, ethical music release, truthful Spotify pitch, and four weeks of authentic fan-building.'),
  dict(title='How to Pitch to Playlists',source='Spotify for Artists (official)',format='youtube',id='Dwo42-7Xjis',
       description='Learn the platform steps for submitting an eligible unreleased track; do not promise playlist placement. Then prepare a truthful sample pitch.'),
  dict(title='How to Use Analytics for Artists',source='YouTube Creators',format='youtube',id='FmqifH4Ai9M',
       description='Practise turning audience signals into measurable fan-development goals, not purchased or inflated engagement.'),
 ]
}
