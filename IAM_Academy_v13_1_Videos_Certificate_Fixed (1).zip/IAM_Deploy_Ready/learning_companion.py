"""IAM original, practical reflection activities. Educational prompts, not AI scoring."""

MODULE_ACTIVITIES = {
 1: {
  'pause': 'Think of an artist who trusts you with their career. What would you do in your first meeting to deserve that trust?',
  'reflect': 'Where might your enthusiasm cause you to promise more than you can control? What boundaries will you establish?',
  'practice': 'Write a first-meeting plan for a fictional rising Afrobeats artist. Include five discovery questions, three professional boundaries, two risks, and one follow-up action.',
  'rubric': [
   'I asked five relevant questions before suggesting solutions.',
   'I explained at least three boundaries or decision rights.',
   'I identified two risks without exaggerating or promising outcomes.',
   'I gave the artist a realistic next step with clear ownership.'
  ],
  'weekly_action': 'Interview a willing creative professional about what responsible artist management means to them.'
 },
 2: {
  'pause': 'Imagine your artist has ambition but no clear audience or direction. How would you learn who the artist really is?',
  'reflect': 'What assumptions could distort your assessment of an artist? How would you check them?',
  'practice': 'Build a fictional artist discovery profile: positioning, target listener, three strengths, two constraints, and a 30-day development experiment.',
  'rubric': [
   'I described a distinct artist identity and likely audience.',
   'I separated confirmed strengths from assumptions.',
   'I named at least two practical limitations.',
   'I set one realistic 30-day experiment and success measure.'
  ],
  'weekly_action': 'Study an independent artist and write three questions you would ask before pitching a strategy.'
 },
 3: {
  'pause': 'A label offers an exciting contract. What needs to be understood before anyone signs?',
  'reflect': 'When would you seek professional legal advice instead of relying on your own understanding?',
  'practice': 'Create a due-diligence sheet for a fictional contract, covering parties, services, territory, duration, fees, termination and rights.',
  'rubric': [
   'I listed the key rights and responsibilities in plain language.',
   'I identified unclear financial or royalty terms.',
   'I noted duration, termination and territory risks.',
   'I highlighted what needs qualified legal review.'
  ],
  'weekly_action': 'Read the terms of a public distribution service and list three points needing clarification.'
 },
 4: {
  'pause': 'A song is ready to release but the budget is limited. How would you decide what matters most?',
  'reflect': 'Which vanity metrics might distract you from actual audience and business progress?',
  'practice': 'Draft a 30-day release plan for a fictional artist with a small budget: audience, message, channels, calendar and measurable goals.',
  'rubric': [
   'I defined one specific audience and clear positioning.',
   'I planned actions before, during and after release.',
   'I matched tactics to realistic budget and team capacity.',
   'I identified measurable outcomes, not just likes.'
  ],
  'weekly_action': 'Review an independent artist release campaign and note two things you would retain and one you would change.'
 },
 5: {
  'pause': 'Your artist receives a promising offer. What commercial questions must be answered?',
  'reflect': 'How will you prevent money decisions from undermining trust with your artist?',
  'practice': 'Prepare a simple income-and-cost plan for a hypothetical performance or partnership, including assumptions, approvals and contingencies.',
  'rubric': [
   'I listed potential revenues, costs and net proceeds.',
   'I stated assumptions and what remains unknown.',
   'I documented approvals and financial responsibilities.',
   'I considered cash timing and at least one contingency.'
  ],
  'weekly_action': 'Create a basic budget spreadsheet for a fictional single release.'
 },
 6: {
  'pause': 'Several collaborators want different outcomes. How would you keep the work coordinated and fair?',
  'reflect': 'Where might poor communication become a financial, legal or relationship problem?',
  'practice': 'Design a two-week coordination plan with roles, deadlines, approval points, communication rhythm and an escalation procedure.',
  'rubric': [
   'I named the person responsible for each major task.',
   'I included clear deadlines and measurable deliverables.',
   'I showed where permissions and approvals are needed.',
   'I described how delays or disagreements will be handled.'
  ],
  'weekly_action': 'Draft an agenda for a 20-minute weekly artist-team meeting.'
 },
 7: {
  'pause': 'A viral moment creates pressure to accept an uncertain opportunity. What will guide your judgment?',
  'reflect': 'How can you protect relationships, privacy and wellbeing during difficult public moments?',
  'practice': 'Write a responsible response plan to a fictional artist crisis, including fact-checking, safety, spokespeople and post-event review.',
  'rubric': [
   'I distinguished verified information from rumors.',
   'I prioritized safety, consent and appropriate escalation.',
   'I identified who communicates and what they may say.',
   'I planned a review and safeguards for future incidents.'
  ],
  'weekly_action': 'Write down a decision you would delay until you have enough verified information.'
 },
 8: {
  'pause': 'Imagine presenting your first 90-day management plan directly to the artist. Can you explain every decision?',
  'reflect': 'Where have your views changed since week one? What professional habit will you keep practicing?',
  'practice': 'Create an executive summary of a 90-day artist management plan with goals, responsible owners, risks, budget, review schedule and consent checkpoints.',
  'rubric': [
   'I stated three realistic, measurable priorities.',
   'I assigned owners, timelines and resources.',
   'I addressed rights, risk, consent and budget.',
   'I included how results will be reviewed with the artist.'
  ],
  'weekly_action': 'Present your plan to a willing peer and revise it based on one useful criticism.'
 }
}


def lesson_key_points(lesson):
 """Ground the 'power points' directly in IAM's written lesson material."""
 return [
  ('The principle', lesson['principle']),
  ('Manager’s professional checkpoint', lesson['deep']['checklist']),
  ('Put it into action', lesson['practice']),
 ]

# Advanced module reflections; the existing eight module records are unchanged.
MODULE_ACTIVITIES.update({
 9: dict(
  pause='Picture your artist arriving at their first live radio interview. What must you prepare before putting them on air?',
  reflect='How will you secure useful media opportunities without exaggerating their achievements or compromising their privacy?',
  practice='Draft the artist media briefing, a radio pitch, five interview questions, a respectful boundary for a sensitive question, and a post-interview follow-up.',
  rubric=['I selected a relevant outlet and verified the news angle.', 'I prepared credible artist facts and clear talking points.', 'I protected consent, privacy and professional relationships.', 'I defined follow-up actions and measurable outcomes.'],
  weekly_action='Rehearse a five-minute interview with a consenting friend and refine your media brief.'),
10: dict(
  pause='Imagine your artist has a good song but no public recognition. How could you create a meaningful moment without manufactured controversy?',
  reflect='What would make an audience genuinely care enough to listen, follow, share or attend the next show?',
  practice='Design a four-week artist publicity plan with one authentic story, two community channels, a creator collaboration, a modest budget and measurable fan actions.',
  rubric=['I grounded the idea in the artist’s real identity and permission.', 'My outreach avoids fake plays, forced trends and undisclosed paid placement.', 'I mapped four weeks of actions, owners and budget.', 'I measure real listeners and relationships, not just impressions.'],
  weekly_action='Observe a real local artist campaign and record two ethical ways to improve its audience connection.')
})
