# Career & music management curriculum research sources (checked 17 October 2026)

## Professional training models
- [Berklee Online: Artist Management](https://online.berklee.edu/courses/artist-management)
- [Berklee Online: Artist Management in the Music Business](https://online.berklee.edu/courses/artist-management-in-the-music-business)
- [Berklee College: Artist Management MB-375](https://college.berklee.edu/courses/mb-375)

IAM's original portfolio prompts and templates are newly written. They do not copy Berklee's course materials, and IAM is not affiliated with Berklee.

## Verified YouTube companions
- [Your Guide to Spotify for Artists](https://www.youtube.com/watch?v=g4XcSnJQd78) — Spotify for Artists
- [How to Pitch to Playlists](https://www.youtube.com/watch?v=Dwo42-7Xjis) — Spotify for Artists
- [How to Use Analytics for Artists](https://www.youtube.com/watch?v=FmqifH4Ai9M) — YouTube Creators
- [The ULTIMATE Guide to Spotify for Artists](https://www.youtube.com/watch?v=4Q3s4ZyIKpM) — Andrew Southworth

## Career discovery sites
- [Music Business Worldwide Jobs](https://www.musicbusinessworldwide.com/jobs/)
- [Sony Music Careers](https://careers.sonymusic.com/)
- [Warner Music Group Careers](https://www.wmg.com/careers)
- [Spotify Careers](https://www.spotifyjobs.com/)

## Search engine technical guide
- [Google SEO Starter Guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide)
- [Google Course structured-data guidance](https://developers.google.com/search/docs/appearance/structured-data/course)

External sites, videos, vacancies and employers have no partnership with IAM unless separately documented. Confirm eligibility, copyright, video access and vacancy dates directly with providers.
