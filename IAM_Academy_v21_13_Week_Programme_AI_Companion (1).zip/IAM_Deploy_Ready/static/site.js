const menuToggle = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#primary-navigation');
if(menuToggle && navigation){
  menuToggle.addEventListener('click',()=>{
    const isOpen=menuToggle.getAttribute('aria-expanded')==='true';
    menuToggle.setAttribute('aria-expanded',String(!isOpen));
    menuToggle.setAttribute('aria-label',isOpen?'Open menu':'Close menu');
    navigation.classList.toggle('menu-open',!isOpen);
  });
  navigation.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{
    menuToggle.setAttribute('aria-expanded','false');
    menuToggle.setAttribute('aria-label','Open menu');
    navigation.classList.remove('menu-open');
  }));
}
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{
 const target=document.getElementById(a.hash.slice(1));
 if(target){e.preventDefault();target.scrollIntoView({behavior:'smooth',block:'start'});history.replaceState(null,'',a.hash);}
}));

// Academic Edition v3: user-controlled accessible hero slideshow.
const campusCarousel=document.querySelector('[data-carousel]');
if(campusCarousel){
  const slides=[...campusCarousel.querySelectorAll('[data-slide]')];
  const indicators=[...campusCarousel.querySelectorAll('[data-go]')];
  let current=0;
  function showSlide(index){
    current=(index+slides.length)%slides.length;
    slides.forEach((slide,i)=>{
      const active=i===current;
      slide.classList.toggle('is-active',active);
      if(active){slide.removeAttribute('aria-hidden');slide.querySelectorAll('a,button').forEach(x=>x.removeAttribute('tabindex'))}
      else{slide.setAttribute('aria-hidden','true');slide.querySelectorAll('a,button').forEach(x=>x.setAttribute('tabindex','-1'))}
    });
    indicators.forEach((button,i)=>{button.classList.toggle('active',i===current);if(i===current)button.setAttribute('aria-current','true');else button.removeAttribute('aria-current')});
  }
  indicators.forEach((button,i)=>button.addEventListener('click',()=>showSlide(i)));
  const previous=campusCarousel.querySelector('[data-previous]');
  const next=campusCarousel.querySelector('[data-next]');
  previous?.addEventListener('click',()=>showSlide(current-1));
  next?.addEventListener('click',()=>showSlide(current+1));
  campusCarousel.addEventListener('keydown',e=>{
    if(e.key==='ArrowRight' && e.target.closest('.campus-controls')){e.preventDefault();showSlide(current+1)}
    if(e.key==='ArrowLeft' && e.target.closest('.campus-controls')){e.preventDefault();showSlide(current-1)}
  });
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let isPlaying=!reducedMotion;
  let cycle;
  const toggleAutoplay=campusCarousel.querySelector('[data-toggle-autoplay]');
  function resetCycle(){
    window.clearInterval(cycle);
    if(isPlaying && !document.hidden)cycle=window.setInterval(()=>showSlide(current+1),7500);
    if(toggleAutoplay){toggleAutoplay.textContent=isPlaying?'Pause slides':'Play slides';toggleAutoplay.setAttribute('aria-pressed',String(isPlaying))}
  }
  indicators.forEach(b=>b.addEventListener('click',resetCycle));
  previous?.addEventListener('click',resetCycle);
  next?.addEventListener('click',resetCycle);
  toggleAutoplay?.addEventListener('click',()=>{isPlaying=!isPlaying;resetCycle()});
  campusCarousel.addEventListener('mouseenter',()=>window.clearInterval(cycle));
  campusCarousel.addEventListener('mouseleave',resetCycle);
  campusCarousel.addEventListener('focusin',()=>window.clearInterval(cycle));
  campusCarousel.addEventListener('focusout',e=>{if(!campusCarousel.contains(e.relatedTarget))resetCycle()});
  document.addEventListener('visibilitychange',resetCycle);
  showSlide(0);
  resetCycle();
}

document.querySelectorAll('[data-reveal]').forEach(button=>{
  const passwordInput=document.getElementById(button.dataset.reveal);
  if(!passwordInput)return;
  button.addEventListener('click',()=>{
    const show=passwordInput.type==='password';
    passwordInput.type=show?'text':'password';
    button.textContent=show?'Hide':'Show';
    button.setAttribute('aria-pressed',String(show));
    button.setAttribute('aria-label',show?'Hide password':'Show password');
  });
});

// IAM Learning Journal: debounced server-side autosave; a normal Save form remains as fallback.
(() => {
  const form = document.querySelector('form.lesson-journal-form[data-autosave]');
  if (!form || !window.fetch || !window.FormData) return;
  const status = form.querySelector('.journal-save-status');
  const fields = [...form.querySelectorAll('textarea')];
  let timeout, sequence = 0, lastSaved = '', busy = false;
  const values = () => fields.map(el => el.value).join('\u001f');
  lastSaved = values();
  const save = async () => {
    if (busy || values() === lastSaved) return;
    busy = true;
    const snapshot = values();
    status.textContent = 'Saving your journal…';
    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: {'X-Requested-With': 'XMLHttpRequest'},
        credentials: 'same-origin',
        redirect: 'manual'
      });
      if (!response.ok || response.type === 'opaqueredirect') throw new Error('Could not save');
      const data = await response.json();
      if (!data.saved) throw new Error('Could not save');
      lastSaved = snapshot;
      status.textContent = values() === snapshot ? '✓ Saved privately to IAM' : 'Changes pending…';
    } catch(err) { status.textContent = 'Save not completed. Select “Save my notes” to retry.'; }
    finally {
      busy = false;
      if (values() !== lastSaved) timeout = setTimeout(save, 1600);
    }
  };
  fields.forEach(field => field.addEventListener('input', () => {
    sequence++;
    status.textContent = 'Unsaved changes…';
    clearTimeout(timeout);
    timeout = setTimeout(save, 1800);
  }));
  form.addEventListener('submit', event => {
    if (!window.fetch) return;
    event.preventDefault();
    clearTimeout(timeout);
    // Explicit save retries failed requests, even when no new typing occurred.
    save();
  });
})();
