/** IAM v20 approved resource library. Data served only to approved students. */
const $=id=>document.getElementById(id);
const grid=$('v20-resource-grid'), search=$('v20-resource-search'), filter=$('v20-resource-type'), count=$('v20-resource-count');
if(grid&&search&&filter&&count){
 let records=[];
 const make=(tag,cls,content)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(content!==undefined)n.textContent=content;return n};
 function draw(){const q=search.value.toLowerCase().trim(),kind=filter.value;
 const shown=records.filter(s=>(kind==='all'||s.kind===kind)&&(!q||[s.title,s.publisher,s.description,s.category].join(' ').toLowerCase().includes(q)));
 grid.replaceChildren();count.textContent=`${shown.length} of ${records.length} approved learning resources`;
 if(!shown.length){grid.append(make('p','v16-small','No matching resources. Try another topic.'));return}
 for(const s of shown){const card=make('article','v20-resource-card');card.append(make('span','v20-resource-label',s.kind==='video'?'WATCH':'READ'));
 card.append(make('h3','',s.title));card.append(make('p','v20-resource-publisher',s.publisher));card.append(make('p','',s.description||'Publisher learning material.'));
 const actions=make('div','v20-resource-actions');
 if(s.kind==='video'&&s.youtube_id&&/^[a-zA-Z0-9_-]{11}$/.test(s.youtube_id)&&s.embed_status!=='unverified'){
 const watch=make('button','v16-btn','▶ Watch inside IAM');watch.type='button';watch.addEventListener('click',()=>{const iframe=make('iframe','v20-resource-player');iframe.src='https://www.youtube-nocookie.com/embed/'+s.youtube_id;iframe.title=s.title;iframe.loading='lazy';iframe.allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture';iframe.referrerPolicy='strict-origin-when-cross-origin';iframe.allowFullscreen=true;watch.replaceWith(iframe)});actions.append(watch);
 }
 const link=make('a','v20-resource-link',s.kind==='video'?'Watch on publisher ↗':'Read original resource ↗');link.href=s.url;link.target='_blank';link.rel='noopener noreferrer';actions.append(link);card.append(actions);grid.append(card)} }
 search.addEventListener('input',draw);filter.addEventListener('change',draw);
 fetch('/api/iam-ai/library',{credentials:'same-origin',cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Access denied or unavailable');return r.json()}).then(kb=>{records=(kb.sources||[]).filter(s=>['video','reference'].includes(s.kind)&&/^https:\/\//.test(s.url));draw()}).catch(()=>{count.textContent='Resource library is available to approved students. Please sign in or reload.'});
}
