# IAM hero slide photography and licensing notes

**No affiliation, participation or endorsement by photographed performers is claimed.** Images are illustrations of the Nigerian music industry, not portraits of IAM faculty or graduates. The webpage includes photographer and license attribution beside each image.

1. **Davido at Vodun Days (2026)**. Photographer: Antoine MIASSI. Commons file: https://commons.wikimedia.org/wiki/File:Davido_au_Vodun_Days.jpg. License CC BY-SA (verify version from file page, likely 4.0): https://creativecommons.org/licenses/by-sa/4.0/
2. **Wizkid performing in Algiers (2025)**. Photographer: Muhammed amine benloulou. Commons file: https://commons.wikimedia.org/wiki/File:Wizkid_in_Canex_-_Algiers_2025_(cropped).jpg. License CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
3. **Burna Boy at Untold (2024)**. Photographer: Nuță Lucian. Commons file: https://commons.wikimedia.org/wiki/File:Untold_2024_-Burna_Boy_(53926047707).jpg. License CC BY-SA 2.0: https://creativecommons.org/licenses/by-sa/2.0/

Cropping with background-size: cover may create adaptations subject to the original attribution and share-alike conditions. Credit must remain visible, and derivative images should be distributed consistently with the image license. If any file becomes unavailable or the license changes, remove or replace it. A legal review is advisable before high-budget advertising using celebrity photography.
