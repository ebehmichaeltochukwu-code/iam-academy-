# IAM Academy v14.1 — Original Brand Restoration

- Restores Version 13.1 navy header and original IAM white/gold logo contrast.
- Restores the previous white and blue editorial hero and slide controls; improves shadow and mobile contrast.
- Removes the burgundy university makeover and retains IAM navy, gold and white identity.
- Retains Version 14 Contact form, private admin inbox, and free rule-based Study Companion.
- No database schema migration, account deletion, billing change, or secret changes.
