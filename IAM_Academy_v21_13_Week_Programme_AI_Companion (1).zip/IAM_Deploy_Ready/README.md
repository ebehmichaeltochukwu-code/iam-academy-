# IAM — Institute of Artist Management

A standalone, Nigeria-first, self-paced online academy. **Not built with Lovable.** Original Python/FastAPI application using SQLite and server-rendered responsive templates.

## Included

- Mobile-ready public website: marketing, syllabus, FAQs, tuition and admissions.
- 10-week professional artist management course (24 original written lessons, 8 case studies, 32 quiz questions, final capstone).
- Third-party YouTube companion embeds for every lesson. **Ten distinct video links are used across 24 lessons**, selected by topic; repetition is intentional. Videos are not owned by IAM, not downloaded, and must be reviewed for embed availability before production launch.
- Student applications with password-protected accounts, pending/approved/rejected decisions, portal status.
- Tuition of ₦100,000 (environment configurable); Paystack initialization and **server-side** verification after keys are supplied. Without keys, online payments stay disabled. Manual bank-payment verification via management console requires staff to independently confirm funds in the real bank account.
- Student progress, 8 quizzes, automatic scoring (75% pass threshold), unlimited retakes, 8 written submissions and staff approval/revisions (final capstone enforces 800–1,500 words).
- Academy-issued PDF completion certificate only when **24 lessons complete + 8 quiz passes + 8 submissions approved**; public certificate verification link.
- Admin: applications, payment ledger, audit records, review of written projects, video companion override editor.
- Responsive light/dark IAM branding using the approved IAM logo with the graduation cap and music note.

## Run locally

```bash
cd iam_academy
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export IAM_APP_SECRET="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"
python manage.py                # you choose a real admin email and password
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000.

## Test

```bash
pip install httpx pytest
python -m pytest -q
```

## Production checklist (mandatory before taking real applicants or payments)

1. Register/clear the IAM name and confirm which educational and business registrations, tax obligations, and data-protection requirements apply in Nigeria. **No accreditation is claimed by this project.** Ask Nigerian counsel to review admissions, refunds, privacy, consumer protection and certificate wording.
2. Deploy behind HTTPS; set `IAM_APP_SECRET` to a random long secret, `IAM_HTTPS=1`, and `IAM_BASE_URL` to the actual HTTPS domain. Store `IAM_DATABASE` in persistent storage with secure backups. SQLite suits pilot use; move to managed PostgreSQL for multi-instance scale.
3. Run `python manage.py` one time in the deployed environment using your private email; **no default admin is shipped**.
4. Provision Paystack secret key securely with the correct business account; complete live-provider callback tests and webhook reconciliation before collecting production payments. Current verification is on authenticated return, **not** a webhook or an end-to-end reconciliation system. A student who closes the browser after paying may require rechecking the payment; build a signed webhook and reconciliation job before production.
5. Add verified admissions contact information, domain email, transactional email delivery (decisions, receipts, password reset), privacy policy, terms of sale, refund policy, cookie notice if needed, bot protection, IP login throttling, backup procedures and monitoring. These are not fully implemented yet.
6. Commission course review from artist managers, producers, entertainment lawyers, and Nigerian rights experts; confirm local copyright/CMO references. Third-party videos may be geo-restricted or have embedding disabled.
7. The 10-week structure is a **recommended learning path**, not a server-enforced minimum elapsed time. Student access begins upon verified tuition; no subscription expiration is applied.
8. Admins can change companion video IDs but not all lesson text through the dashboard; edit `content.py` and redeploy to revise curriculum text or questions.

## Important limits

This is a locally tested application package, **not a deployed public website**. No payment provider account is connected. No email delivery, production monitoring, refunds, fraud screening, invoices, or regulatory accreditation are included. Student completion confirmation is self-attested when marking lessons as complete; only quizzes and practical submissions have additional evaluation. IAM should pilot and strengthen review before offering a credential to paying learners.

## Tech and security summary

- FastAPI/Jinja2 + SQLite, server-side input checks, signed HTTP-only session cookies, per-session CSRF on state-changing forms, scrypt password hashes, role checking on protected routes, server-side payment verification of amount/reference/currency, audit ledger of critical actions, and randomized certificate IDs.
- Pending admin account creation is CLI only; password reset is manual until email integration is built.
- For production, add rate limits, headers/CSP, anti-fraud and full privacy compliance controls and perform independent security review.

## File layout

- `app.py`: web app, auth, workflows, payments, certificates
- `content.py`: original 8 assessed foundation modules within a 10-week curriculum and video/source metadata
- `templates/`: page HTML
- `static/`: styling, script, approved IAM image
- `manage.py`: create admin account interactively
- `create_course_reader.py`: regenerate the course review PDF
- `docs/IAM_8_Week_Course_Reader.pdf`: complete owner review copy of the course
- `tests/`: functional tests

## V2: Everything in one IAM website

**All experiences are combined in one application, one hostname and one database.** Public pages, applications, tuition tracking, self-paced learning, assignments, certification and management review do not require separate websites or separate deployments. A single, shared IAM header, approved logo and responsive menu provide consistent navigation throughout.

- **Public experience:** `/` for the homepage and programme journey, `/curriculum` for all modules, `/apply` for admissions.
- **One IAM login:** `/login` authenticates all users. `/portal` automatically opens the student or staff workspace based on permissions.
- **Student workspace:** `/dashboard`, `/lesson/<lesson-id>`, `/quiz/<week>`, assignments, certificate PDF, plus `/course-handbook` for eligible enrolled students.
- **Management workspace:** `/admin`, with applications, payment reviews, assessment grading, student records and video management. Every student row reports lesson, quiz, assignment and certificate progress.
- **Public verification:** `/verify` lets employers or third parties check an IAM-issued certificate ID.

**Only ONE server and ONE domain are required.** URLs above are pages within the same site, not independently deployed websites. The single course-reader PDF is bundled inside the website and delivered from the authenticated student portal. The included ZIP contains the entire deployable IAM application.

### What this does not mean

A single website still contains multiple secure pages. It should **not** expose the management dashboard to visitors or reveal paid course materials before approval and verified payment. IAM has not yet been hosted on a real domain or linked to a live Paystack account; production policy and security work remains as described above.

## IAM Academic Edition v3 (October 2026)

This version introduces a brighter academic design, a manual three-slide homepage carousel, contextual CC-licensed performance photography credited on-screen, revised admissions and management interfaces, an applicant-specific review and decision history, and an expanded worksheet for each of the 24 lessons. Each existing lesson still has a third-party YouTube companion iframe and fallback YouTube link, with replaceable IDs via the admin video editor. Video availability and editorial suitability must be reviewed before real enrolment.

### Student registration

Student passwords now allow 8–128 characters without mandatory symbol or uppercase requirements, but block a small list of common passwords. Passwords remain scrypt-hashed. Login protects against repeated failed attempts with a rolling 15-minute cooldown after 6 attempts per email. For production scale, add a breached-password service, IP-based anti-abuse, and password reset/email verification.

### Management workflow

`/admin` is reserved for administrators and reviewers. `Applications` lists applicant records; `View application` opens `/admin/applicant/<ID>`, providing experience, motivation, current status, reviewer notes, a decision audit, approve/reject controls. `Payments` can only be marked verified by an administrator after independent banking evidence, not screenshots. `/admin/videos` lets staff replace broken companion video IDs.

**Creating the first administrator**: Set `IAM_ADMIN_EMAIL` (your email) and `IAM_ADMIN_BOOTSTRAP_PASSWORD` (16+ characters, private) as Railway service variables. A fresh administrator account is created on boot when that email does not yet exist. Login at `/login`, then use `/admin`. Never place this password in GitHub, this ZIP, or a public message. After verified login, remove the bootstrap password environment variable; existing hashed account credentials persist on the attached volume. If a student account already exists with that email, this bootstrap will not promote it, by design; use a new admin address or an audited promotion procedure.

### Deploying v3 over an existing Railway ZIP-based instance

The existing Railway deployment uses a pinned SHA256 ZIP downloaded from the public GitHub repository on startup. Upload `IAM_Academy_v3.zip` as a new file at the root of the GitHub repository. Once uploaded, update the Railway start command with the new GitHub raw URL and this ZIP's calculated SHA256 value; do not repoint the service before the uploaded file is accessible. The archive extracts to `IAM_Deploy_Ready` and serves `app:app` on `0.0.0.0:$PORT`. Keep `IAM_DATABASE=/data/iam.db`, retain the `/data` persistent volume and `IAM_APP_SECRET`, and do not export the database to GitHub. Take a database backup and smoke-test before reopening admissions. Longer-term, use normal Git-based builds instead of startup ZIP downloads.

### Brand photography

Slides illustrate Nigerian music careers; they do not claim affiliation, endorsement or teaching roles from the depicted artists. They link and credit Wikimedia Commons CC BY-SA photo authors in each slide. The photography is remotely hosted; verify hotlink availability and attribution/legal suitability before launch, and replace with commissioned/licensed photos when available. See `PHOTO_CREDITS.md`.

## Version 8: Student learning journal & module reflections

See [RELEASE_NOTES_v8.md](RELEASE_NOTES_v8.md) for setup and production safety details.

Inside each lesson, students can type personal notes, inspiration, and a next step; autosave is provided with a regular Save button as fallback. They can revisit entries at `/journal`, download their saved personal writing as PDF or TXT, and complete unique end-of-module reflection and self-marked practice activities at `/module/<week>/reflect`. These records are private to the student's authenticated account. Self-assessments are for learning only and never substitute for the existing instructor-reviewed assignments or affect certificate eligibility.
