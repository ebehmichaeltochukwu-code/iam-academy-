# IAM Academy Version 19: Admissions Guide + International Student Knowledge Expansion

- Public assistant now understands common phrasings such as “Tell me about this school” and introduces IAM with factual, programme-specific information.
- Every public response has a contextual enrolment or course CTA, with no student-only lesson disclosure.
- New source-linked educational topics: 36; total bundled topics: 77; total bundled source records: 27 (plus approved admin contributions).
- Added official WIPO copyright and music reference pages and YouTube Help artist channel, analytics and release-strategy resources.
- **Security:** `/api/iam-ai/library` now requires an approved student or admin/reviewer session. Public visitors do not receive the full study knowledge JSON.
- No paid AI inference or API dependency added. Curated retrieval is not equivalent to a powerful hosted generative AI.
- Sources are reference links for broader study, not a claim that each authored practice exercise appears verbatim on those pages. Legal issues are jurisdiction-sensitive.
- Voice model quality and hands-free performance remain unverified on physical Android devices.
