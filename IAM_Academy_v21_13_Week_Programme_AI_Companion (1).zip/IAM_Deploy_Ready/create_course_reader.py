from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,KeepTogether,HRFlowable
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from xml.sax.saxutils import escape
from content import WEEKS, VIDEOS, READINGS
from career_content import BONUS_MASTERCLASSES, APPLIED_MODULE_VIDEOS
from pathlib import Path

OUT=str(Path(__file__).resolve().parent / 'docs' / 'IAM_10_Week_Course_Reader.pdf')
navy=HexColor('#0f2745');gold=HexColor('#b18b41');muted=HexColor('#445468')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='DocTitleIAM',fontName='Helvetica-Bold',fontSize=27,leading=33,textColor=navy,spaceAfter=14))
styles.add(ParagraphStyle(name='SubIAM',fontName='Helvetica',fontSize=11,leading=18,textColor=muted,spaceAfter=18))
styles.add(ParagraphStyle(name='WeekIAM',fontName='Helvetica-Bold',fontSize=22,leading=27,textColor=navy,spaceAfter=9))
styles.add(ParagraphStyle(name='LessonIAM',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=navy,spaceBefore=18,spaceAfter=8))
styles.add(ParagraphStyle(name='BodyIAM',fontName='Helvetica',fontSize=9.4,leading=15.5,textColor=navy,spaceAfter=10))
styles.add(ParagraphStyle(name='SmallIAM',fontName='Helvetica',fontSize=8,leading=12.5,textColor=muted,spaceAfter=6))
styles.add(ParagraphStyle(name='KickerIAM',fontName='Helvetica-Bold',fontSize=8,leading=12,textColor=gold,spaceBefore=9,spaceAfter=6))
styles.add(ParagraphStyle(name='QuestionIAM',fontName='Helvetica',fontSize=8.7,leading=14,textColor=navy,spaceAfter=4,leftIndent=10))

def para(x,sty='BodyIAM'):
 return Paragraph(escape(str(x)).replace('\n','<br/>'),styles[sty])

story=[Spacer(1,35*mm),para('IAM   |   INSTITUTE OF ARTIST MANAGEMENT','KickerIAM'),para('Professional Artist Management','DocTitleIAM'),para('Ten-week self-paced course reader','SubIAM'),HRFlowable(width='100%',thickness=2,color=gold,spaceAfter=20),para('10 training modules   /   24 assessed foundation lessons   /   8 graded quizzes   /   10 portfolio activities','BodyIAM'),para('This guide contains IAM original teaching notes and assessment prompts for management review. Students work through the same materials in the protected website, supplemented by third-party YouTube videos.','BodyIAM'),para('Certification standard','LessonIAM'),para('Complete 24 lessons, pass all eight quizzes with at least 75%, and secure reviewer approval on all eight assignments, including the final 800–1,500 word management plan. The resulting IAM certificate is academy-issued course completion evidence, not a government-accredited qualification.','BodyIAM'),para('Important learning note','LessonIAM'),para('Examples are educational and designed for Nigeria-first music business training. Contract, tax, rights and safeguarding decisions require current jurisdiction-specific professional advice. Third-party video content is not IAM-owned.','BodyIAM'),PageBreak()]
for w in WEEKS:
 story.extend([para(f"WEEK {w['number']:02d} / 10",'KickerIAM'),para(w['title'],'WeekIAM'),para(w['theme'],'SubIAM'),para('Learning outcome','KickerIAM'),para(w['outcome'],'BodyIAM')])
 for l in w['lessons']:
  v=VIDEOS[l['video_key']]
  story.append(para(f"{w['number']}.{l['number']}   {l['title']}",'LessonIAM'))
  story.append(para(l['principle']))
  story.append(para(l['reading']))
  story.append(para('THE WORKING FRAMEWORK','KickerIAM'))
  story.append(para(l['deep']['framework']))
  story.append(para('MANAGER IN PRACTICE','KickerIAM'))
  story.append(para(l['deep']['example']))
  story.append(para('Application: '+l['practice']))
  story.append(para('Professional checklist: '+l['deep']['checklist'],'SmallIAM'))
  story.append(para('Video companion: '+v[1]+' | https://www.youtube.com/watch?v='+v[0],'SmallIAM'))
 story.extend([para('MODULE CASE STUDY / SUBMIT TO REVIEWER','KickerIAM'),para(w['scenario']),para('KNOWLEDGE CHECK','KickerIAM')])
 for i,q in enumerate(w['quiz'],1):
  story.append(para(f'{i}. {q[0]}','QuestionIAM'))
  story.append(para('Options: '+' / '.join(q[1]),'SmallIAM'))
 story.append(para('Supplementary reading: '+READINGS[w['number']][0]+' | '+READINGS[w['number']][1],'SmallIAM'))
 if w['number']<8:story.append(PageBreak())

# Final two advanced modules: teaching notes, video sources, applied practice, self-checks.
for num in (9,10):
 item=BONUS_MASTERCLASSES[num]
 story.append(PageBreak())
 story.extend([para(f'WEEK {num:02d} / 10','KickerIAM'),para(item['title'],'WeekIAM'),para(item['subtitle'],'SubIAM')])
 for heading,body in item['chapters']:
  story.append(para(heading,'LessonIAM'))
  story.append(para(body))
 story.append(para('WATCH AND REHEARSE','KickerIAM'))
 for vid in APPLIED_MODULE_VIDEOS[num]:
  story.append(para(vid['title']+' | '+vid['source'],'LessonIAM'))
  story.append(para(vid['description']))
  story.append(para('Resource: '+vid['url'],'SmallIAM'))
 story.append(para('PRACTICE BRIEF','KickerIAM'))
 story.append(para(item['rehearsal']))
 story.append(para('REFLECTION AND SELF-CHECK','KickerIAM'))
 for question in item['reflections']:story.append(para(question,'QuestionIAM'))
 story.append(para('Advanced modules use guided self-assessment and portfolio work. Core instructor-graded graduation requirements are unchanged.','SmallIAM'))

def page_footer(c,doc):
 c.saveState()
 width,height=A4
 c.setStrokeColor(gold);c.line(22*mm,19*mm,width-22*mm,19*mm)
 c.setFont('Helvetica',7.5);c.setFillColor(muted)
 c.drawString(22*mm,14*mm,'IAM  ·  Training the people behind the music')
 c.drawRightString(width-22*mm,14*mm,f'{doc.page}  |  Founder curriculum review')
 c.restoreState()

doc=SimpleDocTemplate(OUT,pagesize=A4,leftMargin=22*mm,rightMargin=22*mm,topMargin=22*mm,bottomMargin=25*mm,title='IAM Ten-week Artist Management Course Reader',author='Institute of Artist Management')
doc.build(story,onFirstPage=page_footer,onLaterPages=page_footer)
print(OUT,Path(OUT).stat().st_size)
