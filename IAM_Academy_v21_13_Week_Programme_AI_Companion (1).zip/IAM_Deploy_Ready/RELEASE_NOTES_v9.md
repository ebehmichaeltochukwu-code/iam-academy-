# IAM Academy — Version 9: Career & Portfolio Edition

## What is included
- Public **What You'll Gain** section clearly explaining the ₦100,000 foundation course without promising accreditation or employment.
- Original IAM practice toolkit across **8 career portfolio work products** aligned with all 8 existing modules and 24 lessons.
- Private student career centre with editable portfolio drafts saved by student ID, 8 downloadable text templates and private consolidated PDF portfolio export.
- Supplementary **verified YouTube video links** (Spotify for Artists, YouTube Creators, Andrew Southworth) related to each module. Original lesson videos and optional IAM administration overrides remain unchanged. Videos belong to third-party publishers and can be removed without warning.
- Career-readiness steps: CV, professional pitch, tailored applications, prospecting ethically, outreach tracking.
- **Graduate opportunities** portal restricted to students who have received their IAM-issued certificate after meeting 24 lessons + 8 quizzes + 8 staff-approved assignments. Verified external job-board sources are shown separately; administrator-posted vacancies appear only after they are added and remain active.
- **Administrator-controlled vacancy board** for manually checked HTTPS listings with closing dates and archiving. No fictional vacancies and no automatic job scraping.
- Privacy-conscious website analytics dashboard: anonymous **aggregate page views** by day and public path, not unique people or students; no IP/user tracking.
- SEO basics: course overview meta description, robots.txt, sitemap.xml, canonical URLs, and JSON-LD Course metadata. Search ranking/indexing not guaranteed.
- Clearer larger type, navy/gold-consistent accents, warm-ivory sections, improved mobile readability and a **visible navy-background/gold-symbol favicon cropped from the supplied IAM artwork**, without inventing a new logo.
- Existing university-looking 4 hero slides, admission, quizzes, notes, reflections, grading, certificates, admin privileges and payment workflow preserved. **No payment gateway keys are added or activated.**

## Where everything is
Public: `/`, `/career-information`, `/curriculum`, `/apply`. Learner (requires approved tuition): `/career`, `/career/project/1` to `/career/project/8`, `/career/toolkit/1.txt` to `/career/toolkit/8.txt`, `/career/portfolio.pdf`, `/graduate-opportunities`. Admin: `/admin/opportunities`, `/admin/analytics`.

## Data migration
Database migrations are `CREATE TABLE IF NOT EXISTS` statements executed at startup. Deployment must **retain the existing Railway `/data` volume and `IAM_DATABASE` variable**. No existing student rows are deleted. Do not place production database in public ZIP.

## Deployment
This ZIP is designed for the existing Railway service: update the start command to download `IAM_Academy_v9_Career_Ready.zip` from the connected GitHub repo and use a verified SHA-256 checksum before unpacking and executing `uvicorn app:app`. The file is not automatically published. Do not overwrite existing Railway variables or volumes. Activate only after test.

## Important notices
- IAM certificate is institute-issued, with its own verification code; it is **not** advertised as government-accredited.
- Job outcomes, job-board availability, geography, application eligibility and future positions are **not guaranteed**.
- The graduate job feed starts **empty**; IAM admins must publish genuine source-verified job listings. Third-party job boards remain external sources.
- 8 portfolio templates are for learner practice and do not replace official human review for certification.
- The 4 new supplementary YouTube URLs were checked against publicly available video metadata on 2026-10-17. Titles and availability can change.
- Aggregate analytics count page views, not unique visitors; it cannot reveal personal visitor identities.
