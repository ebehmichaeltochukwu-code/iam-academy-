"""Original IAM teaching notes: decision frameworks, Nigerian-market scenarios, and practice tools."""
DEEP={
'w1l1':{
'framework':'Map the five management responsibilities: strategy, coordination, advocacy, accountability, and risk. Strategy selects a direction. Coordination ensures the right specialist owns each task. Advocacy negotiates fair opportunities. Accountability tracks commitments and cash. Risk work asks what could harm the artist, team, or audience. None of these gives a manager automatic creative ownership.',
'example':'An Afrobeats newcomer asks a manager to edit all vocals, sign a distribution agreement, collect show fees, and approve a brand endorsement. Separate the tasks: a producer or engineer handles audio work, a qualified lawyer reviews legal language, the manager tracks fee collection under agreed accounting rules, and the artist approves image use according to the agreement.',
'checklist':'Can you name the decision owner? Is the proposed action within your authority? Is specialist advice needed? Can you explain the benefit and risk to the artist in plain language?'} ,
'w1l2':{
'framework':'Trust has procedures. Agree communication hours, budget thresholds, the definition of confidential information, access to accounts, conflict-of-interest disclosures, and how either person can raise concerns. Document approvals in a shared decision log rather than relying on memory. The artist should retain access to essential accounts and contracts.',
'example':'Suppose a promoter offers you a personal “thank-you payment” if you persuade the artist to accept a low fee. Disclosure is mandatory. Do not secretly accept the payment. Discuss the potential conflict, seek the artist’s informed approval of any legitimate arrangement, and walk away if transparency cannot be maintained.',
'checklist':'No secret commissions. No unauthorized account access. No humiliating public feedback. No invented figures. No retaliation when someone reports a concern.'},
'w1l3':{
'framework':'Your first month is an audit, not an advertising blitz. Week one: interviews and listening. Week two: catalogue, accounts, rights, agreements and baseline metrics. Week three: strategic options, constraints and a realistic budget. Week four: approve a 90-day plan. Record unknowns as unknowns instead of treating assumptions as facts.',
'example':'An artist says they have 50,000 fans. You inspect platforms and find 45,000 passive social followers but only 800 repeat listeners and 120 email subscribers. A practical first milestone might be strengthening repeat engagement rather than purchasing broader reach.',
'checklist':'Catalogue and splits, active agreements, artist objectives, responsible parties, cash position, audience baseline, upcoming commitments, risks, and first review date.'},
'w2l1':{
'framework':'Use a three-pass listening process. Pass one records the emotional promise: what does the song make you feel? Pass two maps structure and hook timing with timestamps. Pass three examines intelligibility, dynamics, sonic balance, pacing and the intended listening environment. Separate objective observations from taste-based preferences.',
'example':'In a 3:40 track, the strongest hook only arrives at 1:35. The manager does not claim this is wrong; they say that for short-form discovery audiences, delayed payoff might reduce early engagement. Ask the producer to audition a version with the hook introduced earlier, then compare listeners’ reactions.',
'checklist':'Capture timecodes, strengths, risks, intended audience, reference tracks, decisions needed, and the party qualified to make changes.'},
'w2l2':{
'framework':'Create a song map: intro → verse → pre-chorus → chorus → second verse → bridge → final chorus → outro, adjusting for the actual genre. Record where the listener can identify the central hook and whether momentum changes. Strong songs do not all need the same structure, so evaluate against artistic intent and real listener evidence.',
'example':'A gospel worship song may benefit from long builds and repeated refrains in a live congregation, while a dance-led Afrobeats single may favour a fast groove and early hook. The manager should not apply one format blindly. Invite the artist to define the desired experience, then review comparable works.',
'checklist':'Is the hook identifiable? Does the arrangement serve the audience? Is the vocal clear? Does the length serve the artistic goal? What one hypothesis can we test?'},
'w2l3':{
'framework':'Good critique uses Observation → Impact → Option → Artist choice. Start with something specific that works. Explain a concern without moral judgement. Suggest an experiment with the producer. Ask the artist what they hear and document the outcome. Avoid presenting a manager’s preferences as production facts.',
'example':'Instead of “The mix is poor,” try: “Your chorus melody stays in my head. On headphones, the backing instruments seem to cover the second line. Could we ask the engineer for a vocal-forward alternate mix and compare them tomorrow? It is your final creative call.”',
'checklist':'Does your feedback describe the audio? Does it respect the creator? Is the suggestion reversible? Have you invited response instead of demanding compliance?'},
'w3l1':{
'framework':'Use the alignment dialogue: goal, perspective, evidence, options, decision owner, next review. Repeat the artist’s position before challenging it. Ask whether the disagreement is about facts, values, budget or timing because those require different solutions. A decision without ownership becomes a future argument.',
'example':'The artist wants to release tonight; you recommend a two-week delay because credits are incomplete and artwork approval is missing. Show the checklist and the risks of rushing. Offer a short delay or a limited teaser instead of simply saying “no.” Record the chosen option and who approves it.',
'checklist':'Shared objective named; artist heard accurately; evidence supplied; choices compared; approval recorded; review date agreed.'},
'w3l2':{
'framework':'For difficult feedback use Situation → Behaviour → Impact → Request. Speak privately and promptly; do not attack identity or infer motive. Ask what you missed. If the manager also contributed to the problem, acknowledge it. Repair requires a concrete change and a follow-up, not a dramatic apology followed by identical behaviour.',
'example':'A creative director failed to deliver artwork after two promised deadlines. Say: “We agreed Tuesday and Friday; neither file arrived. The distributor upload is now at risk. What blocked you? Can we agree a draft by 5 p.m. tomorrow or assign a backup designer?” Keep the discussion specific and respectful.',
'checklist':'Avoid public shaming, sweeping words such as “always”, invented motives, and undocumented changes to the plan.'},
'w3l3':{
'framework':'Leadership requires role clarity and safe reporting. A simple responsibility matrix lists the artist, manager, producer, legal adviser, marketing lead, booking agent, and venue team. For high-impact decisions assign one final approver. Include an escalation route for harassment, financial misuse, discrimination, threats, or unsafe conditions.',
'example':'A tour crew member says a venue security officer threatened them. Protect immediate safety, remove the affected person from danger, document the report accurately and involve appropriate authorities or specialists where needed. Do not trade safety for a performance fee.',
'checklist':'Names and roles; emergency contacts; approval thresholds; confidential reporting route; incident documentation; anti-retaliation commitment.'},
'w4l1':{
'framework':'Two protected assets often exist in a track: the recorded performance (master) and the musical composition (songwriting/publishing). There can be several performers, writers, producers, sample owners, publishers or distributors. Document who contributed to each work and who can grant each permission. A split sheet records agreed composition contributions, not every possible licence.',
'example':'An artist buys a beat from a producer on social media. The invoice alone does not tell you whether the transaction was exclusive, whether samples were cleared, or who owns the underlying composition. Do not distribute until the paperwork and releases match the planned uses.',
'checklist':'Master owner; songwriter shares; producer agreement; session permissions; samples/interpolations; licence scope; metadata; copies of executed documents.'},
'w4l2':{
'framework':'Map revenue by activity and rights holder. Recording streaming royalties differ from songwriting royalties. Live fees, sync licences and merchandise are other routes with different contracts and accounting. Keep identifier and metadata records consistent. The US Mechanical Licensing Collective is not an all-purpose Nigerian collection body.',
'example':'A streaming dashboard displays payment for sound-recording use. The artist assumes this settles all songwriting income. It may not. Check registrations and territory-specific collection rules, and ask a locally qualified rights professional which organisations are relevant in each market.',
'checklist':'Separate composition and master income; verify identifiers; reconcile payments; log licence territory; confirm beneficiaries; investigate unpaid or unmatched uses.'},
'w4l3':{
'framework':'Build a contract issue-spotting table with clause, present wording, business consequence, questions for counsel, and proposed negotiation point. Focus on commission basis, term, territory, exclusivity, sunset payments, expenses, approvals, accounting, audit and termination. Managers should raise business issues but must not offer unsupervised legal advice.',
'example':'A proposed agreement commissions 20% of all earnings “forever,” including post-termination unrelated work, without audit rights. Note the broad scope and indefinite duration. Request competent Nigerian entertainment counsel to evaluate a narrower definition and a reasonable, documented sunset structure.',
'checklist':'Who signs? What gets paid? When does the term end? Who owns rights? Can the artist audit? What happens if the relationship breaks down?'},
'w5l1':{
'framework':'An artist brand is a consistent promise expressed through sound, story, experience, and values. Start with an authentic identity statement and a clearly described audience, then choose three content themes. Evidence must support the narrative; do not manufacture success stories. Test different presentations without abandoning the core creative identity.',
'example':'A singer from Enugu blends highlife guitars with contemporary R&B. Rather than copying an unrelated superstar’s image, the team builds content around live musicianship, the inspiration behind songs, and local cultural influences. Ask fans which examples feel most recognizable.',
'checklist':'Truthful story; target listener; three content pillars; visual consistency; safe consent for photos; approved bio and press kit.'},
'w5l2':{
'framework':'Work backward from release day: clear rights first, then distribution lead times, approved assets, messaging, content production, targeted pitching and a post-launch feedback loop. Assign one owner and due date to every deliverable. Build a realistic buffer for artwork revisions, metadata delays and changing artist availability.',
'example':'An artist schedules a Friday drop with no master confirmation, artwork and producer paperwork. A responsible manager risks a controlled delay rather than submitting incomplete files. A teaser and behind-the-scenes clip can preserve audience momentum while the release is made ready.',
'checklist':'Rights cleared; master approved; ISRC and metadata checked; distributor schedule confirmed; content bank ready; outreach owner set; follow-up metrics scheduled.'},
'w5l3':{
'framework':'Choose decision metrics, not vanity metrics. Track engaged listeners, repeat listening, saves or follows, community signups, content completion and live attendance. Compare weekly trends within the same audience segment and spend level. Use experiments to inform next actions, not to reverse-engineer inflated performance.',
'example':'Campaign A earns 30,000 low-engagement impressions; campaign B earns 2,000 targeted views, 180 saves and 40 newsletter subscribers. The smaller campaign may be more useful for long-term career-building. Validate data quality before scaling spend.',
'checklist':'Audience quality; baseline; test hypothesis; conversion metric; actual spending; human feedback; next action and owner.'},
'w6l1':{
'framework':'Prepare a basic forecast by transaction: expected money in, payment date, costs, agreed commission, taxes if applicable, and remaining cash. Document every expense with receipt and authorized approver. Distinguish forecast from cleared bank funds. Avoid commission calculations that silently exclude agreed refunds, chargebacks or costs.',
'example':'An event fee of ₦700,000 has ₦540,000 estimated costs. A 10% cost contingency adds ₦54,000, leaving ₦106,000 before any tax or negotiated commission. That may be insufficient for the disruption risk; the manager should discuss better terms or a different opportunity.',
'checklist':'Income dates; costs; contingency; contracts; receipts; VAT/tax questions; approvals; reconciled actuals; transparent artist statement.'},
'w6l2':{
'framework':'A show advance is the checklist of work done before a performance. Confirm promoter details, written offer, deposit, venue, stage dimensions, backline, soundcheck, transport, hotel, meals, security, permits, insurance where appropriate, timings, cancellation rules and settlement. Escalate any performer safety concern.',
'example':'A festival poster displays your artist’s name, but no deposit is paid and the venue cannot supply the agreed monitors. A manager should not assume the show is secured. Request written confirmation and a workable technical plan before announcing irreversible travel arrangements.',
'checklist':'Deposit received; production rider accepted; ground transport booked; venue contacts stored offline; travel and safety contingencies agreed.'},
'w6l3':{
'framework':'Before negotiation, define must-haves, nice-to-haves and walk-away triggers. Calculate all-in costs and alternatives. Ask what the buyer values: date certainty, publicity, exclusivity or content rights. Exchange concessions rather than giving away value for free, and require written approval before binding an artist.',
'example':'A promoter cannot increase the artist fee but can cover secure ground transport and accommodation and pay a larger deposit. Compare net risk and actual cost savings instead of rejecting or accepting only on headline price.',
'checklist':'Net value; risk; alternatives; approved negotiation range; written revised terms; owners and payment deadlines.'},
'w7l1':{
'framework':'A commercial partnership is a bundle of rights and obligations. Calculate the fee against duration, content volume, territory, exclusivity, editing rights, usage period and reputational fit. Short-term cash should not quietly remove the artist’s future options. Know when legal review is non-negotiable.',
'example':'An endorsement offers ₦2 million for 24 months of category exclusivity and unlimited reuse of the artist’s likeness. Break the proposal into negotiated parts: campaign term, posting obligations, reuse window, territories and renewal conditions. Have counsel assess the wording.',
'checklist':'Counterparty verified; fee timing; exclusivity scope; approvals; image use; moral clauses; termination; dispute process and rights reversion.'},
'w7l2':{
'framework':'Prepare before a crisis by assigning fact-checking, welfare, legal escalation, spokesperson and recordkeeping. In an active incident, first distinguish urgent safety facts from unverified online claims. Preserve evidence lawfully, show concern for people affected, and avoid speculative or retaliatory statements.',
'example':'A rumour alleges an artist missed an event intentionally. Before posting, confirm the timeline, transport failure, venue communications and contractual promises. If people may be unsafe or harmed, act on safety immediately; if it is a scheduling dispute, respond narrowly with what can be verified.',
'checklist':'Human safety; verification; affected stakeholders; legal review; decision log; holding statement; corrections and follow-up.'},
'w7l3':{
'framework':'A career strategy should combine creative progress, sustainable work rhythms, financial resilience and relationships. Plan for recording, live events, rights income, audience communities and learning. Ask the artist what success means in their life, not just what the manager can report as a vanity metric.',
'example':'A promising artist is gaining streams but cancelling rehearsals from exhaustion. Rather than scheduling more appearances, build recovery time, inspect workload and prioritize higher-value opportunities. A sustainable artist can continue to create.',
'checklist':'Quarterly goals; cash runway; creative practice; health and rest boundaries; team skills; catalogue assets; diversified opportunities.'},
'w8l1':{
'framework':'Use confirmed facts to build a present-state record. For each asset or claim identify the source, date, owner and unresolved question. Rank risks by likelihood and severity rather than mood or fear. Make a decision to seek evidence when confidence is low and document privacy permissions for any real artist material.',
'example':'Your proposed capstone artist has 12 released singles, two unknown co-writer agreements, one upcoming show and inconsistent metadata. The honest audit lists unresolved rights documentation as a priority risk before large promotion.',
'checklist':'Consent; catalogue; contracts; rights; roles; audience; cash; live diary; strengths; constraints; ranked risk register.'},
'w8l2':{
'framework':'Turn your audit into a 90-day plan. State three outcomes, measurable milestones and a task owner for every step. Write a cash budget and escalation process, schedule listening and artist check-ins, and build deliberate checkpoints for deciding whether to continue, pivot or stop a tactic.',
'example':'Goal one: resolve rights records for the next single. Goal two: grow the engaged subscriber list by an agreed amount using ethically obtained permission. Goal three: secure one financially viable live opportunity. Make the measurement and cost assumptions explicit.',
'checklist':'Three priority outcomes; timeline; responsibility map; cash forecast; measurement dashboard; risk response; clear decision rights.'},
'w8l3':{
'framework':'Your final dossier must be understandable to a real artist and defensible under questioning. Explain what you know, what you assume, what you would test and what you would decline. Include constructive creative critique, an example of professional disagreement and a plan for transparent reporting. Reviewers judge the reasoning, not impressive formatting.',
'example':'A thoughtful capstone may recommend postponing a release until split documents are completed, even if the campaign could generate near-term impressions. Describe why, who should approve the change, the expected cost and how you will keep the audience engaged.',
'checklist':'Artist consent; 90-day roadmap; music review; rights audit; budget; team decisions; dispute script; risk register; ethical growth plan; KPI review and references.'}
}
