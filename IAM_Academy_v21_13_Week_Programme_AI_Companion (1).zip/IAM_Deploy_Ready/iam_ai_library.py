"""Approved, source-linked IAM AI knowledge material. No external inference is used."""
import json, re
from pathlib import Path
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parent
CORE=ROOT/'iam-knowledge-v19-private.json'
ALLOWED_STATUS={'draft','published','withdrawn'}
VIDEO_LIBRARY=[
 {'id':'iam-v1','title':'Media Interview Best Practices Guide','publisher':'ASTHO / Klick Health','kind':'video','url':'https://www.youtube.com/watch?v=nANkJlwZo0w','youtube_id':'nANkJlwZo0w','description':'A scenario resource used in IAM Module 9 for interview preparation.','module':9,'topics':['interview','media','press','publicity'],'embed_status':'unverified'},
 {'id':'iam-v2','title':'How to Pitch to Playlists','publisher':'Spotify for Artists','kind':'video','url':'https://www.youtube.com/watch?v=Dwo42-7Xjis','youtube_id':'Dwo42-7Xjis','description':'Official artist marketing tutorial included in IAM Module 10.','module':10,'topics':['spotify','playlist','release','pitch'],'embed_status':'unverified'},
 {'id':'iam-v3','title':'YouTube for Artists Creator Guidance','publisher':'YouTube Creators','kind':'video','url':'https://www.youtube.com/watch?v=FmqifH4Ai9M','youtube_id':'FmqifH4Ai9M','description':'Video resource used in IAM Module 10 on video strategy.','module':10,'topics':['youtube','video','creator','content'],'embed_status':'unverified'},
]

def allowed_url(value):
 try:
  uri=urlsplit(value.strip())
  return uri.scheme=='https' and bool(uri.hostname) and uri.username is None and uri.password is None and len(value)<500
 except (ValueError,TypeError,AttributeError):return False

def normalise_article(payload):
 title=str(payload.get('title','')).strip()
 guidance=str(payload.get('guidance','')).strip()
 exercise=str(payload.get('exercise','')).strip()
 keywords=str(payload.get('keywords','')).strip()
 source_name=str(payload.get('source_name','')).strip()
 source_url=str(payload.get('source_url','')).strip()
 jurisdiction=str(payload.get('jurisdiction','Global')).strip()
 status=str(payload.get('status','draft')).strip().lower()
 module=int(payload.get('module') or 1)
 if not (8<=len(title)<=150 and 50<=len(guidance)<=4000 and 12<=len(exercise)<=1500):raise ValueError('Provide a title (8–150), guidance (50–4000) and an exercise (12–1500 characters).')
 if not (2<=len(source_name)<=100 and allowed_url(source_url)):raise ValueError('A source name and public HTTPS reference URL are required.')
 if not (1<=module<=13 and status in ALLOWED_STATUS and len(keywords)<=450 and len(jurisdiction)<=60):raise ValueError('Invalid module, status, keywords or jurisdiction.')
 return dict(title=title,guidance=guidance,exercise=exercise,keywords=keywords,source_name=source_name,source_url=source_url,jurisdiction=jurisdiction or 'Global',status=status,module=module)

def public_library(connection):
 data=json.loads(CORE.read_text(encoding='utf-8'))
 rows=connection.execute("SELECT * FROM iam_knowledge_articles WHERE status='published' ORDER BY id DESC LIMIT 500").fetchall()
 for row in rows:
  x=dict(row);sid='iam-admin-source-'+str(x['id'])
  data['sources'].append(dict(id=sid,title=x['source_name'],publisher=x['source_name'],url=x['source_url'],kind='reference',description='Reviewed IAM educational source'))
  data['topics'].append(dict(id='iam-admin-topic-'+str(x['id']),title=x['title'],guidance=x['guidance'],exercise=x['exercise'],keywords=x['keywords'].replace(',',' ').split(),source_ids=[sid],module=x['module'],jurisdiction=x['jurisdiction'],reviewed_at=x['updated_at']))
 data['sources'].extend(VIDEO_LIBRARY)
 data['library_info']={'mode':'curated','article_count':len(data['topics']),'review_note':'The IAM library is periodically reviewed, not an exhaustive or real-time internet index.','version':'21.0'}
 return data
