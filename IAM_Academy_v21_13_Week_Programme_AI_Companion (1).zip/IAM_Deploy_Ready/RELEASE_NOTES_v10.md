# IAM Academy V10 — Media interviews and authentic artist publicity

Added **two optional masterclasses** to the eight-module, 24-lesson assessed foundation programme, for **ten downloadable private career portfolio project templates**. The core 24 lessons, eight quizzes, eight staff-reviewed assignments and certificate requirements remain **unchanged** for existing students.

- Masterclass 9: securing the right interview, electronic press kits, media outreach, realistic interview rehearsal, respectful handling of sensitive questions, follow-up and measurement.
- Masterclass 10: ethical artist story and positioning, city-specific audience research, genuine community moments, creator collaborations, an affordable 4-week campaign, fan conversion metrics, and risk controls.
- New authenticated student pages `/career/masterclass/9` and `/career/masterclass/10`, with original instructional reading, outcome list, scenario simulation, reflection prompts, self-check answers, and independent third-party reading and topic-based video discovery.
- Extended private drafts, 10 downloadable working templates, and private PDF portfolio export to include projects 9 and 10. No new user table or schema migration required: existing portfolio-drafts table accepts new week numbers.
- Updated `/career-information`, `/career`, `/curriculum`, homepage value proposition and pricing inclusions.
- Added readable navy / warm-ivory styles without altering original IAM logo, favicon or colors.
- No payment gateway changes, accreditation claims or guaranteed media placement. Publicity training rejects manufactured scandals, bought streams, fake followers and nondisclosed paid promotion.

Test new pages and PDF output locally before deploying to existing Railway instance. Keep persistent `/data` database and `IAM_DATABASE` environment variable. Do not put student database in GitHub.
