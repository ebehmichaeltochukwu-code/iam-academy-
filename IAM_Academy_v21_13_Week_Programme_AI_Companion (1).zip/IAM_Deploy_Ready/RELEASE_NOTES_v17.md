# IAM Academy Version 17: Floating Voice Companion (beta)

## Included
- Globally available IAM-branded floating launch button, accessible dialog and close control. The floating panel embeds the **actual existing** study companion as an iframe, not a disconnected simulation.
- Voice/Chat mode switch in the companion.
- Voice session starts **only after explicit permission and user selection**, detects speech and 1.55 seconds of silence, transcribes locally via the existing Whisper-tiny browser integration, auto-sends to existing IAM knowledge answer pipeline, reads aloud through browser speech synthesis, then resumes listening.
- Mute, unmute, end session, switch to chat, corrected transcript controls; microphone stops when inactive, switching mode or leaving the page.
- IAM self-introduction and independently grounded institution description.
- Original navy/gold IAM styling, unchanged institutional header and certificate features.

## Limitations / truthful status
- Browser speech synthesis voices and quality vary by device; some system voices may be cloud-backed. IAM does not call paid TTS APIs. Human-quality voices **not** established.
- Whisper-tiny.en downloaded on demand; real Nigerian English accent accuracy and Android memory/performance **not yet verified**.
- No true full-duplex/interruption-free ChatGPT-style conversation: listening pauses during reply to avoid feedback. Turn detection is RMS/silence heuristic, not an advanced trained VAD. Voice requires mic permission and HTTPS.
- This is an optional beta, with keyboard chat remaining the universal fallback.
- Test microphone, model load, and actual response audio on real Android and desktop devices prior to broad launch.
- No inference API keys, tokens or payment AI endpoints added. Internet/model download and hosting costs may remain.
- No auto-deploy: package must be committed to IAM GitHub and deployed to Railway with database volume untouched.
