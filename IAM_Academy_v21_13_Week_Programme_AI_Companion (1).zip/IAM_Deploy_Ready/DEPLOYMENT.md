# Deploying the IAM Academy application

This is a runnable website but has **not** been deployed by ChatGPT. Hosting, domain activation and payment credentials require action by IAM's owner.

## Recommended pilot deployment

Use a Linux host with Python 3.12 and persistent storage, or deploy the included Dockerfile to a host with a persistent `/data` volume. The SQLite database **must not** be on a disposable container filesystem. If the provider has multiple concurrent app instances, migrate database operations to PostgreSQL first.

Set these secret environment variables in the host control panel:

```
IAM_APP_SECRET=<cryptographically-random-secret-64+characters>
IAM_HTTPS=1
IAM_BASE_URL=https://yourdomain.example
IAM_DATABASE=/data/iam.db
IAM_TUITION_NGN=100000
# Only after Paystack business verification:
PAYSTACK_SECRET_KEY=<your-live-or-test-secret-key>
```

Start using `uvicorn app:app --host 0.0.0.0 --port ${PORT:-8000}`. Set up HTTPS and make sure the filesystem directory is owned by the process user. Create your private admin with `python manage.py` inside the same environment **after** your persistent volume is mounted.

## Verify before accepting money

- Use Paystack test mode to check successful checkout, failed checkout, wrong amounts, refunds and access permissions. This version verifies payment on the return URL; add a signed Paystack webhook plus retry/reconciliation before live payments.
- Use your verified local bank account for manual receipts and reconcile deposits before an admin approves a manual payment. Never rely on an uploaded screenshot.
- Publish your full legal entity details, privacy policy, terms, refund policy and legitimate admissions contact details.
- Review all external YouTube embeds, readings, course claims and locally applicable IP/rights guidance.
- Test restore from database backup and HTTPS cookie behaviour.
- Arrange independent code and payment security review.
- IAM completion certificate is an institute-issued proof of course completion; do **not** market it as government approved or accredited unless separately authorized.

## Operator guide

**Applications:** `/admin?tab=applications` → Approve or reject.

**Tuition:** `/admin?tab=payments` → mark paid only after externally verifying bank deposit, with unique transaction reference. Paystack students become paid after verified checkout response.

**Assessment:** `/admin?tab=submissions` → review assignments, approve or request revision with written feedback.

**Video management:** `/admin/videos` → enter replacement 11-character YouTube IDs.

**Learners:** `/dashboard` → lessons, quizzes, practical assignments, certificate.

**Certificate checks:** public `/verify/<certificate-code>` endpoint.

**Updates to curriculum text/quizzes:** edit `content.py` and `deep_dives.py`, then redeploy.

## Unified deployment architecture (v2)

Provision **one hostname**, for example `academy.yourdomain.example`, and point it at **one IAM Python server**. All pages route through the same FastAPI application and SQLite data store. Do not deploy admissions, courses, certificate verification and administration as separate sites. Configure one `IAM_BASE_URL`, and use a shared persistent `IAM_DATABASE`. Students and IAM staff share `/login`; the `/portal` route sends them to the correct role-based dashboard.

The course reader is already included as `docs/IAM_8_Week_Course_Reader.pdf` and is accessible only via the authenticated `/course-handbook` route, not as a separately hosted document. Admin records, payment data, assessment approvals and learner progress are stored in one IAM database.

## Railway first-time deployment (root-level repo)

This root-level package is ready for a **private GitHub repository** deployed as a Railway Dockerfile service.

1. Upload the contents of this folder to the repository root. Do not upload `.env`, any `*.db` or other credentials.
2. Deploy the GitHub repository to Railway and create a persistent volume mounted at `/data` before accepting applications.
3. Set `IAM_DATABASE=/data/iam.db`, `IAM_HTTPS=1`, `IAM_TUITION_NGN=100000`, and a unique 64+ character `IAM_APP_SECRET`.
4. Set `IAM_ADMIN_EMAIL` to the owner's private email, and `IAM_ADMIN_BOOTSTRAP_PASSWORD` to a randomly generated secret of at least 16 characters. The admin is created on first start when it does not already exist. Remove the bootstrap password variable after successful login, and configure future password resets securely.
5. Generate a Railway public domain, then set `IAM_BASE_URL` to the full `https://...` URL.
6. Confirm `/health`, the landing page, application submission, admin review, student access controls, course completion and certificate verification.
7. Payments remain off unless Paystack credentials are configured; do not enable live collection until webhook/reconciliation and the compliance checks above are completed.

**Avoid free-ephemeral deployments for genuine student records.** Without the Railway `/data` volume, the SQLite database may disappear during redeploys. Also avoid horizontal replica scaling with this SQLite architecture.
