# IAM Academy v5: academic website refresh

This ZIP contains the full self-hosted FastAPI application. It does not contain accounts, passwords, cookies or production student records.

## Changes
- Separate `/about` page and an About IAM section on the home page, with honest IAM-issued credential statement.
- Four accessible hero slides, including new original CSS-rendered online campus/study visual.
- Auto-advancing carousel (7.5 seconds), pausing on focus/hover, with manual next/previous and play/pause controls; reduced-motion setting disables auto-play.
- Larger type across public pages, student forms, staff screens; nav font and mobile controls adjusted.
- User-supplied transparent logo retained and scaled down within header/footer.
- Existing student database, individual portal, admission workflow, payment verification and administrator management routes retained.

## Upload from Android
1. Download `IAM_Academy_v5.zip`.
2. Open `https://github.com/ebehmichaeltochukwu-code/iam-academy-/upload/main` (sign in).
3. Tap *Choose your files* and select the ZIP (do not extract).
4. Scroll down and *Commit changes*.
5. Railway uses a custom start command that downloads a release ZIP. **The service must be configured for `IAM_Academy_v5.zip`; merely uploading the file does not update the live website.**
6. Deploy with the new URL and validated SHA256. Maintain existing `/data` volume and `IAM_DATABASE` settings. Check `/health`, `/about`, homepage carousel, and admin routes before announcing production.

## Administrator access
Admin bootstrap remains environment-based. Do not put passwords in public repository, screenshots or source code. Set `IAM_OWNER_EMAIL` and `IAM_OWNER_INIT_PASSWORD` privately in Railway for first login; remove bootstrap variable after login and change to a strong unique password.

Do not claim that IAM provides government-accredited certificates.
