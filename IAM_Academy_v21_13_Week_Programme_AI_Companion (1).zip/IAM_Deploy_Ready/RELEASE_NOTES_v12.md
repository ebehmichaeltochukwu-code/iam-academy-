# IAM Academy V12 — Ten Weeks, Admin Previews and Applied Video Learning

- Public and learner pages present 10 modules across a recommended, self-paced 10-week programme. No minimum elapsed time is imposed.
- Course reader rebuilt with the original 24 foundation lessons plus Week 9 (Media Interviews) and Week 10 (Artist Publicity) teaching notes and verified video resources.
- Advanced lessons use ASTHO official media-training recordings and existing YouTube Creators/Spotify for Artists companion videos, with watch-and-apply prompts. Availability of third-party videos can change.
- Admin-only read-only index `/admin/lessons` opens any of the 24 lessons and both applied modules. No completion, quizzes, notes, or portfolio actions in preview.
- Admin-only `/admin/certificate-preview` returns inline PDF with prominent SAMPLE — NOT VALID watermark. It uses the same renderer as the real certificate but does not insert any certificate or verification record.
- Certificate wording, verification page, downloadable reader and SEO now use ten-week course language while retaining the existing graded requirements and saved progress.
- No changes to fees, payment credentials or student tables.
