# IAM v18: Public Admissions Guide + Enrolled Student AI

- Public `/study-companion` is a limited institutional admissions guide only. It does not load the student tutor, local voice AI or full learning interface. Public floating launcher targets the public guide.
- Enrolled students whose application is approved and payment is verified access `/student/iam-ai`. Other users are redirected to login or dashboard. The student float launcher and portal links target the gated route.
- The student voice assistant remains permission-based, using browser-local audio capture and optional local speech model. Adjusted silence window around one second to reduce latency; speech detection remains heuristic, not guaranteed.
- Visible source lookup and optional WebLLM generation status, plus animated loading dots. Loading status represents processing, not human-like reasoning.
- Existing database schema, registration, payments, modules and certificates are unchanged. No paid AI inference API.
- Voice accuracy, latency, and human-like sound still require device testing. Student knowledge API retains the approved public-reference catalogue; it must not include any restricted lessons.
