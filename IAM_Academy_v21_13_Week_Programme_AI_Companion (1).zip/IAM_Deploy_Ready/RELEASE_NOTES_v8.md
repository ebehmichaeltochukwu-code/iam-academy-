# IAM Academy Version 8: Reflection & Learning Journal

## Student functionality

- Private, account-specific learning journal from within every lesson
- Three writing spaces per lesson: learning notes, inspiration and next action
- Save with a button and optional debounced autosave (~1.8 seconds when online)
- Three key learning points per lesson, based on IAM-written material
- Reflection moments after each lesson
- Eight unique end-of-module Reflection Labs including realistic practice scenarios
- Four-criterion self-assessment rubric per module, with self-reported count
- The official instructor-reviewed assignments, quizzes and certification rules remain unchanged
- A Journal page showing entries across all 24 lessons and eight modules
- PDF and UTF-8 text download of only the student's saved notes and reflections
- No automatic transcription of YouTube audio; this export is a transcript of student-authored text

## Security and data preservation

- New SQLite tables are created with `CREATE TABLE IF NOT EXISTS`, without deleting existing user records
- User ID scoping on each journal query and write; enrollment gating and CSRF validation
- PDF and text downloads include `Cache-Control: private, no-store`
- Form field limits of 16,000 characters per field
- Self-scores DO NOT count towards course certification
- Kept Paystack's existing dormant integration unchanged; Flutterwave support is intentionally NOT included in this release, per the user's request to revisit payments later.
- Preserve existing `IAM_DATABASE=/data/iam.db` Railway variable and volume mount on deployment.

## Deployment

1. Upload `IAM_Academy_v8_Learning_Journal.zip` to `ebehmichaeltochukwu-code/iam-academy-` GitHub repository without extracting.
2. Update the Railway `iam-web` start command to download and unpack this archive, verifying its SHA256 checksum, then install requirements and run Uvicorn.
3. Keep all other Railway variables and `/data` storage unchanged.
4. After successful deployment, sign in with an approved paid TEST student, open one lesson, save notes and inspiration, open one reflection lab, self-check, then test PDF and TXT exports. Do not publish learner credentials.

## Testing

`python -m pytest -q` (8 tests) covers public pages, student flow, admissions review, journal persistence, student data isolation, exports, CSRF and access controls, and certificate separation.
