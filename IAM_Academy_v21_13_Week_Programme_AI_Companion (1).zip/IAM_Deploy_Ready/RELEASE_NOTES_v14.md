# IAM v14 University Editorial & Contact Edition

- Independent academic redesign inspired by the clarity and hierarchy of university websites (not a copy of or affiliated with Cambridge University).
- Four-slide hero refined: editorial serif, larger headlines, navy/cream/red-accent while retaining original IAM logo and licensed photo credits.
- New public `/contact` route stores validated enquiries in an IAM-only SQLite table with CSRF and a spam honeypot; admin can review at `/admin/messages`. No automatic outgoing emails are claimed.
- Free `/study-companion`: locally curated browser-only knowledge assistant with practical artist-management scenarios. **Not a generative AI model**, no third-party AI costs or API keys.
- Accessible links on main navigation and footer, plus search-indexing of the new public pages.
- No modifications to assessment or payment status, student journal data, certificate issuance or existing logins.
