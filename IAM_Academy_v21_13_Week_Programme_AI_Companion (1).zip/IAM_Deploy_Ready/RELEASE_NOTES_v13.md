# IAM v13 In-Class Video Studio

- Fix administrator preview banner contrast and title layout in Modules 9 and 10.
- Inline YouTube video companions on all 24 foundation lesson pages (previously extra external video links).
- Modules 9 and 10 now embed third-party instructional videos instead of navigating to external video sources.
- Original caption-driven IAM case-study videos for media interviews and Spotify release strategy; both play natively from the app's static folder.
- Retain original source attribution and optional reading links; publishers control whether their YouTube videos permit third-party embedding.
- No changes to student data, grading, tuition, payment settings, or certificate requirements.
