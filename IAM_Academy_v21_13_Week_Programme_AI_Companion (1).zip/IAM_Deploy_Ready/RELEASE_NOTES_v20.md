# IAM Academy v20: Student Video and Reading Resource Library

- Added a searchable, filtered reading and watching shelf inside the **approved-student** IAM AI portal.
- Added 16 source-linked resources from WIPO and official YouTube for Artists/YouTube Help publications.
- WIPO: copyright, music IP, music-income modules, creator tools, and research presentations on digital music markets.
- YouTube: Official Artist Channels, Analytics for Artists, pre-release, release day, post-release and global audience strategy.
- Watch links open the original publisher; verified direct YouTube embeds can play inside IAM when explicitly supplied and embedding is permitted. The new WIPO and YouTube resource hubs do not have confirmed individual embeddable video IDs, so no fake iframe is shown.
- Public admissions guide remains separate from student learning library; source API still requires approved enrolment.
- Original IAM navy and gold website design preserved. No paid AI API added.
- Research reviewed 2026-10-19; references are links, not reproduced third-party copyrighted content.
