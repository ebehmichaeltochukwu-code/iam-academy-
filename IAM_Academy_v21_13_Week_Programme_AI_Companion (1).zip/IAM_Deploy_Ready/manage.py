"""Create an owner account securely; run from the project folder."""
import getpass, sys
from app import db,password_hash

def main():
 email=input('Owner email: ').strip().lower()
 name=input('Owner full name: ').strip()
 pwd=getpass.getpass('Password (minimum 12 characters): ')
 if len(pwd)<12 or '@' not in email or len(name)<3:
  print('Invalid owner details');sys.exit(1)
 with db() as c:
  c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",(name,email,password_hash(pwd)))
 print('Owner account created. Sign in at /login.')
if __name__=='__main__':main()
