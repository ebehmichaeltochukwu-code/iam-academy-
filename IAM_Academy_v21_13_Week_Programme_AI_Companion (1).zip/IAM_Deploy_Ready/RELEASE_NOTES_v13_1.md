# IAM Academy v13.1 – Certificate Logo Containment Fix

- Updated the certificate PDF renderer to position the supplied IAM white-and-gold logo fully inside the two decorative certificate borders.
- Corrected its image proportions (198 × 121 points), preventing distortion.
- Applied the fix to both real student certificates and the administrator sample preview through their shared renderer.
- Left issuing, verification, student records, certificate eligibility, tuition settings, and lesson/video features unchanged.
- Inherited all Version 13 in-lesson videos and scenario clips.
