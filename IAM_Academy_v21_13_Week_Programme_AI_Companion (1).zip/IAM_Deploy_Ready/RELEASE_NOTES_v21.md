# IAM Academy V21: Thirteen-Week Professional Artist Management Programme

- Builds on Version 20's video and reading shelf and Version 19's public guide / private tutor.
- Adds **three original applied modules**, bringing the programme to **13 weeks and 13 modules**:
  - Week 11: Music Copyright, Rights and Sustainable Artist Income (WIPO resources).
  - Week 12: YouTube for Artists: Channels, Analytics and Release Campaigns (official YouTube for Artists resources).
  - Week 13: Global Digital Music Strategy, Rights and Artist Career Capstone (WIPO digital music and YouTube resources).
- Each new module includes seven original teaching chapters, learning outcomes, scenario simulation, three self-checks, reflections, curated official source links, a private saved portfolio assignment, and a downloadable practice template.
- Adds contextual IAM AI companion buttons within core lessons, advanced modules, portfolio projects and reflection labs; existing floating student tutor remains available while studying.
- Updates public programme, admissions guide, curriculum, homepage, student dashboard, career toolkit and admin preview to thirteen weeks.
- **No retroactive certificate eligibility change**: original eight graded modules remain the existing required assessments. Modules 9–13 are self-assessed applied enrichment; no misleading claims of government accreditation.
- Original ten-week PDF remains labelled foundation edition; new Weeks 11–13 supplement provided.
- No paid AI APIs. New video resources are publisher-linked; no unverified video embeds or reproduced copyrighted material.
- The original Railway database, payments and user records are not modified.

- Added 21 chapter-level study articles to the private IAM AI retrieval library, bringing curated topic count to 98. Added official publisher references for Weeks 11–13.
- Full 13-week PDF handbook generated, while legacy 10-week edition remains in the package for historical reference.
