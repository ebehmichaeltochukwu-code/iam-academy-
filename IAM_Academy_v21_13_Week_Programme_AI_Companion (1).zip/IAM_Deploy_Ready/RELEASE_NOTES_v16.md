# IAM Academy Version 16 – AI Study Companion Integration (Pre-release)

## What was actually implemented

- New responsive IAM AI study interface with source-grounded, device-light retrieval from 41 existing approved topics and 22 original resource links, plus three previously included IAM YouTube video references. Videos use the publisher's privacy-enhanced YouTube iframe where allowed. **The three video embeds' current playback availability is not confirmed.**
- Eight modes: Ask IAM, Explain Simply, Deep Study, Case Study Lab, Quiz & Revision, Interview Practice, Contract Simulator, Video Tutor. The fallback mode uses curated material and deterministic prompts, not a generative AI model; it is explicitly labeled as such.
- Opt-in **WebLLM** browser-local generation with prebuilt low-memory model selection, retrieved source context, and a clear WebGPU/device incompatibility fallback. Model download, caching, run time, license, and answer quality have NOT been tested on an actual Android device. The model-selection flow might need tuning per browser/model availability; it is not represented as a fully validated mobile AI deployment.
- Opt-in **Transformers.js + Whisper tiny English** speech transcription using browser MediaRecorder, local audio decoding/resampling to 16 kHz, editable transcript, and push-to-talk. Voice input has NOT been validated end-to-end on representative mobile hardware.
- Browser-provided SpeechSynthesis for spoken answers, pause/stop, and a checkbox to choose voice. Speech voices may be OS-provided or require network depending on device; we DO NOT guarantee on-device/offline synthesis. Kokoro local TTS and VAD were not implemented.
- In-page lessons and published videos are presented as recommendations; no third-party transcripts are scraped or rehosted.
- Local conversation history and study notes stored in localStorage; student can download or clear. No private text is sent to commercial inference APIs. Third-party CDN downloads (ML libraries/model files, video playback) may contact external providers upon opt-in.
- Persistent, admin-only article editor: create, edit, publish, unpublish, withdraw. Public JSON library includes ONLY published custom articles, alongside the existing curated library. HTTPS source validation and CSRF/session checks implemented. Existing IAM student DB volume remains the target data store.

## Testing

- `pytest -q`: 29 tests passed, including 4 new integration/security/schema tests.
- `node --check static/iam-ai-v16.js` succeeds and `python -m py_compile` succeeds.
- Full Chromium browser navigation was blocked by the environment's administrator policy (net::ERR_BLOCKED_BY_ADMINISTRATOR), so interactive browser controls, local WebLLM loading, ASR, voice quality, Android speed, and YouTube playback are NOT independently verified. They require staging/field testing.
- No paid AI API keys or inference endpoints added.

## Architecture

FastAPI + SQLite (existing) / static JSON versioned library / browser-based lexical scoring / opt-in WebLLM running over WebGPU / optional browser Transformers.js Whisper transcription / browser SpeechSynthesis / localStorage. No paid hosted inference, premium vector search service, or artificial question credits.

## Research and licensing notes

Reference documentation for browser inference: https://github.com/mlc-ai/web-llm ; https://huggingface.co/docs/transformers.js/en/guides/webgpu ; https://github.com/hexgrad/kokoro/tree/main/kokoro.js ; https://support.google.com/youtube/answer/171780 . Do not assume model weights are covered by the software runtime license: check the actual model card and license before commercial production use. Check individual video embedding permissions. This release reuses the human-curated v15 knowledge rather than claiming to have exhaustively indexed worldwide copyrighted databases. WIPO and NCC jurisdiction-specific legal details require subject-matter review before publication.

## Gaps against the complete master prompt

- No verified local TTS model (Kokoro, Sherpa) and no local VAD or interruptible conversational turn-taking.
- No measured on-device WebLLM/Whisper operation on Android, license audit of chosen weights, or offline PWA/cache implementation.
- No semantic vector embeddings or multi-stage ingest from external verified sources; legacy lexical ranking remains; dynamic SQLite articles extend it.
- No verified universal video library, transcript extraction, caption timestamps, or publisher-embedding status checks.
- Simulated quizzes/scenarios are guided prompts, not adaptive scored pedagogy. More curriculum-aligned item banks and trained instructional review needed.
- LocalStorage is not synced across browsers or devices. The reader must choose to save notes.

## Deployment

This ZIP is *not automatically deployed*. Upload `IAM_Academy_v16_Conversational_AI_Beta.zip` to the existing IAM GitHub repository and explicitly request deployment. Deploy with the existing Railway volume `/data` and `IAM_DATABASE=/data/iam.db` unchanged. Staging with real-browser/device QA is strongly recommended before full production exposure.
