import re
from fastapi.testclient import TestClient
import app as iam

def login(c,email,password):
    html=c.get('/login').text
    token=re.search(r'name="csrf"[^>]*value="([^"]+)"',html).group(1)
    r=c.post('/login',data=dict(csrf=token,email=email,password=password),follow_redirects=False)
    assert r.status_code==303

def test_inline_videos_admin_lessons_and_modules(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'test.db');iam.init_db()
    with iam.db() as d:
        d.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('Director','boss@iam.test',iam.password_hash('StrongPassphrase!')))
    c=TestClient(iam.app);login(c,'boss@iam.test','StrongPassphrase!')
    for i in (1,5,8):
        lesson=c.get(f'/lesson/w{i}l2').text
        assert 'v13-video-grid' in lesson
        assert '<iframe' in lesson
        assert 'Watch on YouTube ↗' not in lesson
    assert '/static/iam-scenarios/spotify-release.mp4' in c.get('/lesson/w5l2').text
    for n in (9,10):
        r=c.get(f'/career/masterclass/{n}')
        assert r.status_code==200
        assert 'ADMIN READ-ONLY PREVIEW' in r.text
        assert 'v13-video-card' in r.text
        assert '<video' in r.text
        assert '<iframe' in r.text
        assert 'format' not in r.text or 'youtube' in r.text
        assert 'Open official video resource' not in r.text
    assert 'nANkJlwZo0w' in c.get('/career/masterclass/9').text
    assert 'Dwo42-7Xjis' in c.get('/career/masterclass/10').text
    assert c.get('/static/v13.css').status_code==200
    assert '.v9-page-hero .v12-admin-preview-note' in c.get('/static/v13.css').text
    for slug in ('media-interview','spotify-release'):
        r=c.get('/static/iam-scenarios/'+slug+'.mp4')
        assert r.status_code==200
        assert r.headers['content-type'].startswith('video/mp4')
        assert len(r.content)>20000
    c.close()
