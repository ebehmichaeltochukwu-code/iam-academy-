import re
from fastapi.testclient import TestClient
import app as iam
from career_content import APPLIED_MODULE_VIDEOS

def login(c,email,password):
    page=c.get('/login').text
    m=re.search(r'name="csrf"[^>]*value="([^"]+)"',page)
    assert m
    return c.post('/login',data={'csrf':m.group(1),'email':email,'password':password},follow_redirects=False)

def test_10_weeks_display_in_public_and_reader(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'test12.db');iam.init_db()
    c=TestClient(iam.app)
    home=c.get('/').text
    assert '13 MODULES' in home
    assert 'Thirteen weeks of recommended study' in home
    assert 'thirteen weeks as a suggested schedule' in home
    assert '8-week programme' not in home
    assert 'thirteen-week curriculum' in c.get('/curriculum').text
    assert 'thirteen-week' in c.get('/about').text
    assert c.get('/admin/lessons',follow_redirects=False).status_code==303
    assert c.get('/admin/certificate-preview',follow_redirects=False).status_code==303
    assert c.get('/career/masterclass/9',follow_redirects=False).status_code==303
    c.close()

def test_admin_can_preview_all_lessons_and_certificate_with_no_writes(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'test12.db');iam.init_db()
    with iam.db() as db:
       db.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",('Director','director@example.org',iam.password_hash('StrongPassphrase!')))
    c=TestClient(iam.app)
    assert login(c,'director@example.org','StrongPassphrase!').status_code==303
    idx=c.get('/admin/lessons')
    assert idx.status_code==200 and idx.text.count('class="v12-admin-module"')==13
    for k in ('w1l1','w8l3'):
        l=c.get('/lesson/'+k)
        assert l.status_code==200
        assert 'ADMIN READ-ONLY PREVIEW' in l.text
        assert 'Save my notes' not in l.text
        assert 'Mark lesson complete' not in l.text
    for n in (9,10):
        result=c.get('/career/masterclass/'+str(n))
        assert result.status_code==200
        assert 'WATCH & APPLY' in result.text
        assert 'ADMIN READ-ONLY PREVIEW' in result.text
        assert 'Save my response' not in result.text
    assert c.get('/admin').text.find('Certificate preview')>0
    res=c.get('/admin/certificate-preview')
    assert res.status_code==200 and res.content[:4]==b'%PDF'
    assert res.headers['cache-control']=='private, no-store'
    with iam.db() as db:
        assert db.execute('SELECT COUNT(*) FROM certificates').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM progress').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM lesson_journals').fetchone()[0]==0
    assert len(APPLIED_MODULE_VIDEOS[9])>=1 and len(APPLIED_MODULE_VIDEOS[10])>=1
    c.close()

def test_student_cannot_open_admin_certificate_preview(tmp_path,monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'test12.db');iam.init_db()
    with iam.db() as db:
       db.execute("INSERT INTO users(full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'student','approved','paid')",('Student','learner@example.org',iam.password_hash('StrongPassphrase!')))
    c=TestClient(iam.app)
    assert login(c,'learner@example.org','StrongPassphrase!').status_code==303
    assert c.get('/admin/certificate-preview',follow_redirects=False).status_code==403
    assert c.get('/admin/lessons',follow_redirects=False).status_code==403
    assert c.get('/lesson/w1l1').status_code==200
    assert 'Save my notes' in c.get('/lesson/w1l1').text
    assert 'WATCH & APPLY' in c.get('/career/masterclass/10').text
    c.close()
