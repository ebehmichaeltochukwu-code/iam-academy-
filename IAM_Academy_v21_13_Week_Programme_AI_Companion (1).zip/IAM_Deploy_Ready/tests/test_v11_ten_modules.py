import re
from fastapi.testclient import TestClient
import app as iam
from career_content import ADVANCED_MODULES,PORTFOLIO
from learning_companion import MODULE_ACTIVITIES


def form_csrf(c,path):
 m=re.search(r'name="csrf"[^>]*value="([^"]+)"',c.get(path).text)
 assert m is not None
 return m.group(1)


def student(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'v11.sqlite3')
 iam.init_db()
 with iam.db() as db:
  db.execute('INSERT INTO users(full_name,email,password_hash,application_status,payment_status) VALUES (?,?,?,?,?)',('Test Student','student-v11@example.org',iam.password_hash('A-StrongPassw0rd!'),'approved','paid'))
 c=TestClient(iam.app)
 resp=c.post('/login',data={'email':'student-v11@example.org','password':'A-StrongPassw0rd!','csrf':form_csrf(c,'/login')},follow_redirects=False)
 assert resp.status_code==303
 return c


def test_ten_modules_presented_consistently(tmp_path,monkeypatch):
 assert len(iam.WEEKS)==8 and len(iam.LESSONS)==24
 assert len(ADVANCED_MODULES)==5 and len(PORTFOLIO)==13
 assert set(MODULE_ACTIVITIES)==set(range(1,14))
 with TestClient(iam.app) as c:
  home=c.get('/').text
  curr=c.get('/curriculum').text
  assert 'Thirteen practical modules.' in home
  assert home.count('class="week-card"')==13
  assert curr.count('class="course-week"')==13
  assert 'MODULE 09 / 13' in curr and 'MODULE 10 / 13' in curr


def test_module_9_and_10_reflections_private_and_exported(tmp_path,monkeypatch):
 c=student(tmp_path,monkeypatch)
 dash=c.get('/dashboard').text
 assert 'Your thirteen-week journey' in dash
 assert 'Study Module 9' in dash and 'Study Module 10' in dash
 for num in (9,10):
  resp=c.get(f'/module/{num}/reflect')
  assert resp.status_code==200
  assert f'MODULE {num:02}' in resp.text
  token=form_csrf(c,f'/module/{num}/reflect')
  result=c.post(f'/module/{num}/reflect',data={'csrf':token,'insight':f'Module {num} inspired me to rehearse','practice_response':'I am planning a real, ethical publicity and media campaign','check_0':'on'},follow_redirects=False)
  assert result.status_code==303
  assert f'Module {num} inspired' in c.get('/journal/download.txt').text
 assert 'MODULE 09' in c.get('/journal').text
 assert 'MODULE 10' in c.get('/journal').text
 assert 'MODULE 9' in c.get('/journal/download.txt').text
 assert 'MODULE 10' in c.get('/journal/download.txt').text
 assert c.get('/journal/download.pdf').content.startswith(b'%PDF')
 assert c.get('/career/masterclass/9').status_code==200
 assert c.get('/career/masterclass/10').status_code==200
 c.close()
