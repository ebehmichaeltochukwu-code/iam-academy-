import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_resource_metadata():
 kb=json.loads((ROOT/'iam-knowledge-v19-private.json').read_text())
 for sid in ['wipo-music','wipo-copyright','wipo-music-career','wipo-digital-music','yt-resources','yt-masterclasses','yt-channel','yt-analytics','yt-release','yt-pre','yt-day','yt-post']:
  source=next((s for s in kb['sources'] if s['id']==sid),None)
  assert source and source['url'].startswith('https://')
def test_library_remains_private():
 app=(ROOT/'app.py').read_text()
 assert "@app.get('/api/iam-ai/library')" in app
 assert "status_code=403" in app
def test_resource_page():
 html=(ROOT/'templates/study_companion_v16.html').read_text()
 assert 'v20-resource-grid' in html and 'iam-ai-v20.js' in html
 js=(ROOT/'static/iam-ai-v20.js').read_text()
 assert 'credentials:' in js and 'youtube-nocookie.com/embed/' in js
