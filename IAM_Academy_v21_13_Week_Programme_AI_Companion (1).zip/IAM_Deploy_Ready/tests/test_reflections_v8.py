import re
from fastapi.testclient import TestClient
import app as iam


def csrf(client, path):
    html = client.get(path).text
    match = re.search(r'name="csrf"[^>]*value="([^"]+)"', html)
    assert match, f"Missing CSRF on {path}"
    return match.group(1)


def student(client, email, password):
    token = csrf(client, '/login')
    result = client.post('/login', data={'csrf': token, 'email': email, 'password': password}, follow_redirects=False)
    assert result.status_code == 303


def add_user(email, status='paid'):
    with iam.db() as c:
        c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?, ?, ?, 'student','approved',?)", ('Reflection Student', email, iam.password_hash('VeryGoodPassword123!'), status))


def test_personal_notes_reflections_and_downloads(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path / 'iam_reflect.db')
    iam.init_db()
    add_user('one@iam.example')
    add_user('two@iam.example')
    a,b=TestClient(iam.app),TestClient(iam.app)
    student(a,'one@iam.example','VeryGoodPassword123!')
    student(b,'two@iam.example','VeryGoodPassword123!')
    for route in ('/journal','/module/1/reflect','/lesson/w1l1'):
        response=a.get(route)
        assert response.status_code==200,route
    assert 'Your learning notes' not in a.get('/lesson/w1l1').text  # label is "My learning notes"
    assert 'My learning notes' in a.get('/lesson/w1l1').text
    note={'csrf':csrf(a,'/lesson/w1l1'),'notes':'Never promise an artist guaranteed fame <script>bad()</script>', 'inspiration':'Artist management needs empathy.', 'next_step':'Draft a professional boundaries checklist.'}
    assert a.post('/lesson/w1l1/notes',data=note,follow_redirects=False).status_code==303
    assert 'Never promise an artist' in a.get('/lesson/w1l1').text
    assert '&lt;script&gt;' in a.get('/lesson/w1l1').text
    note['notes']='A revised lesson note about consent.'
    ajax=a.post('/lesson/w1l1/notes',data=note,headers={'X-Requested-With':'XMLHttpRequest'})
    assert ajax.json()['saved'] is True
    assert 'A revised lesson note' in a.get('/journal').text
    assert 'A revised lesson note' not in b.get('/journal').text
    assert 'Module reflection' in a.get('/module/1/reflect').text or 'MODULE 01' in a.get('/module/1/reflect').text
    payload={'csrf':csrf(a,'/module/1/reflect'), 'insight':'Trust before fame is the principle I will remember.', 'challenge':'I sometimes rush plans.', 'commitment':'Schedule first meetings next week.', 'practice_response':'Five questions, three boundaries, two risks, one follow-up.', 'check_0':'on','check_1':'on','check_2':'on'}
    assert a.post('/module/1/reflect',data=payload,follow_redirects=False).status_code==303
    html=a.get('/module/1/reflect').text
    assert '3 of 4' in html
    assert 'Trust before fame' in html
    assert '3 of 4' not in b.get('/module/1/reflect').text
    transcript=a.get('/journal/download.txt')
    assert transcript.status_code==200 and 'attachment;' in transcript.headers['content-disposition']
    assert 'A revised lesson note' in transcript.text and 'Trust before fame' in transcript.text
    assert '3/4' in transcript.text
    assert 'automatic transcription of YouTube' in transcript.text
    assert 'A revised lesson note' not in b.get('/journal/download.txt').text
    pdf=a.get('/journal/download.pdf')
    assert pdf.status_code==200 and pdf.content[:4]==b'%PDF'
    assert pdf.headers['cache-control']=='private, no-store'
    with iam.db() as c:
        count=c.execute('select count(*) from lesson_journals').fetchone()[0]
        reflection_count=c.execute('select count(*) from module_reflections').fetchone()[0]
    assert count==1 and reflection_count==1
    a.close();b.close()


def test_security_authorization_and_cert_separation(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path / 'iam_reflect_security.db')
    iam.init_db()
    add_user('paid@iam.example')
    add_user('unpaid@iam.example', status='unpaid')
    with iam.db() as c:
        c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?, ?, ?, 'admin','approved','paid')",('Admin','admin@iam.example',iam.password_hash('AdminPass123456!')))
    c=TestClient(iam.app)
    assert c.get('/journal',follow_redirects=False).status_code==303
    assert c.get('/journal/download.pdf',follow_redirects=False).status_code==303
    student(c,'unpaid@iam.example','VeryGoodPassword123!')
    assert c.get('/module/3/reflect',follow_redirects=False).status_code==303
    assert c.post('/lesson/w1l1/notes',data={'csrf':'fake','notes':'x'},follow_redirects=False).status_code==303
    c.close()
    a=TestClient(iam.app)
    student(a,'paid@iam.example','VeryGoodPassword123!')
    denied=a.post('/lesson/w1l1/notes',data={'csrf':'wrong','notes':'x'})
    assert denied.status_code==400
    ctoken=csrf(a,'/lesson/w1l1')
    assert a.post('/lesson/not_a_lesson/notes',data={'csrf':ctoken,'notes':'x'}).status_code==404
    assert a.post('/lesson/w1l1/notes',data={'csrf':ctoken,'notes':'x'*16001}).status_code==400
    assert a.post('/module/1/reflect',data={'csrf':ctoken,'insight':''}).status_code==400
    assert iam.course_state(1)['certificate'] is None
    with iam.db() as dbc:
        dbc.execute('INSERT INTO module_reflections (user_id,week,insight) VALUES (1,1,?)',('Module completed on my own!',))
    assert iam.course_state(1)['certificate'] is None
    a.close()
