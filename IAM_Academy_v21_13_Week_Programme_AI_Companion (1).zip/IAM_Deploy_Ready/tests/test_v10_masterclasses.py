import re
from fastapi.testclient import TestClient
import app as iam
from career_content import PORTFOLIO, BONUS_MASTERCLASSES

def csrf(client, path):
    match=re.search(r'name="csrf"[^>]*value="([^"]+)"',client.get(path).text)
    assert match, path
    return match.group(1)

def login(client, email, payment='paid'):
    with iam.db() as db:
        db.execute('INSERT INTO users(full_name,email,password_hash,application_status,payment_status) VALUES (?,?,?,?,?)',
                   ('IAM Test Student',email,iam.password_hash('LongStrongPassphrase!'),'approved',payment))
    r=client.post('/login',data={'email':email,'password':'LongStrongPassphrase!','csrf':csrf(client,'/login')},follow_redirects=False)
    assert r.status_code==303

def test_public_modules_and_core_preservation(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-v10.db');iam.init_db()
    assert len(PORTFOLIO)==13
    assert len(BONUS_MASTERCLASSES)==5
    assert len(iam.WEEKS)==8 and len(iam.LESSONS)==24
    with TestClient(iam.app) as c:
        page=c.get('/').text
        assert 'Thirteen practical portfolio projects' in page
        assert 'media' in c.get('/career-information').text.lower()
        assert 'Media interviews' in c.get('/curriculum').text
        assert c.get('/career/masterclass/9',follow_redirects=False).status_code==303

def test_bonus_student_access_privacy_and_portfolio_export(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-v10.db');iam.init_db()
    a=TestClient(iam.app);b=TestClient(iam.app)
    login(a,'person-a@example.org');login(b,'person-b@example.org')
    assert a.get('/career/masterclass/9').status_code==200
    assert a.get('/career/masterclass/10').status_code==200
    assert 'Simulation: An emerging Afrobeats artist' in a.get('/career/masterclass/9').text
    assert a.get('/career/toolkit/9.txt').status_code==200
    assert 'RELEASE' not in a.get('/career/toolkit/9.txt').text[:100]
    assert a.get('/career/toolkit/10.txt').status_code==200
    r=a.post('/career/project/9',data={'csrf':csrf(a,'/career/project/9'),'body':'A fictional radio interview with approved talking points'},follow_redirects=False)
    assert r.status_code==303
    assert 'A fictional radio interview' in a.get('/career/project/9').text
    assert 'A fictional radio interview' not in b.get('/career/project/9').text
    assert a.get('/career/portfolio.pdf').content.startswith(b'%PDF')
    assert '10' in a.get('/career').text
    a.close();b.close()

def test_unpaid_cannot_access_bonus(tmp_path, monkeypatch):
    monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-v10.db');iam.init_db()
    with TestClient(iam.app) as c:
        login(c,'unpaid-v10@example.org',payment='unpaid')
        for url in ('/career/masterclass/9','/career/masterclass/10','/career/project/9','/career/toolkit/10.txt'):
            assert c.get(url,follow_redirects=False).status_code==303
