from fastapi.testclient import TestClient
from app import app
import json
from pathlib import Path

def test_public_guide_is_institution_first():
 c=TestClient(app);r=c.get('/study-companion');assert r.status_code==200
 assert 'iam-public-guide-v19.js' in r.text
 js=c.get('/static/iam-public-guide-v19.js').text
 assert 'tell me about this school' in js
 assert 'Institute of Artist Management' in js
 assert 'iam-answer-cta' in js
 assert 'Enrol' in js or 'enrol' in js

def test_private_library_requires_enrolment():
 c=TestClient(app);r=c.get('/api/iam-ai/library')
 assert r.status_code==403
 assert 'topics' not in r.json()

def test_knowledge_expansion_and_attribution():
 p=Path(__file__).resolve().parents[1]/'iam-knowledge-v19-private.json'
 kb=json.loads(p.read_text())
 assert len(kb['topics'])>=70
 assert all(t.get('source_ids') for t in kb['topics'])
 assert any(s['publisher']=='World Intellectual Property Organization' for s in kb['sources'])
