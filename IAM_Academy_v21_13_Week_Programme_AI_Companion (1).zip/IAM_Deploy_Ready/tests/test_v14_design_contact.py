import os,sys
from pathlib import Path
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app as iam

def test_pages_and_private_enquiries(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam.db')
 iam.init_db()
 client=TestClient(iam.app)
 home=client.get('/')
 assert home.status_code==200 and '/static/v14.css' in home.text
 assert '/contact' in home.text and '/study-companion' in home.text
 assert client.get('/study-companion').status_code==200
 assert 'IAM AI · Admissions Guide' in client.get('/study-companion').text
 form=client.get('/contact')
 assert form.status_code==200
 assert client.get('/admin/messages',follow_redirects=False).status_code in (302,303,401,403)
 csrf=client.cookies.get('iam_session')
 from bs4 import BeautifulSoup
 token=BeautifulSoup(form.text,'html.parser').select_one('input[name=csrf]')['value']
 data={'csrf':token,'full_name':'Ayo Test','email':'ayo@example.com','topic':'Admissions','message':'I would like details about the programme.','website':''}
 good=client.post('/contact',data=data,follow_redirects=False)
 assert good.status_code==303 and '/contact?sent=1' in good.headers['location']
 with iam.db() as con:
  rows=con.execute('SELECT * FROM contact_messages').fetchall()
  assert len(rows)==1 and rows[0]['email']=='ayo@example.com'
 bad=client.post('/contact',data={**data,'csrf':'wrong'},follow_redirects=False)
 assert bad.status_code==400
