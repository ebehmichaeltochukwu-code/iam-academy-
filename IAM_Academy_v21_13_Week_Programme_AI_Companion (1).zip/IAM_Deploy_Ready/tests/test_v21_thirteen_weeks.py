import re
from fastapi.testclient import TestClient
import app as iam
from career_content import ADVANCED_MODULES,PORTFOLIO,BONUS_MASTERCLASSES
from learning_companion import MODULE_ACTIVITIES

def test_public_thirteen_week_site(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'v21.db');iam.init_db()
 assert len(iam.WEEKS)==8 and len(iam.LESSONS)==24
 assert len(PORTFOLIO)==13 and len(ADVANCED_MODULES)==5 and len(BONUS_MASTERCLASSES)==5
 assert set(MODULE_ACTIVITIES)==set(range(1,14))
 with TestClient(iam.app) as c:
  for url in ('/','/curriculum','/about','/career-information','/study-companion'):
   r=c.get(url);assert r.status_code==200,(url,r.status_code)
  assert c.get('/curriculum').text.count('class="course-week"')==13
  assert 'Thirteen weeks' in c.get('/').text
  assert 'Music Copyright' in c.get('/curriculum').text
  assert 'YouTube for Artists' in c.get('/curriculum').text
  assert 'Global Digital Music' in c.get('/curriculum').text
  for n in (11,12,13):
   assert c.get(f'/career/masterclass/{n}',follow_redirects=False).status_code==303
   assert c.get(f'/career/toolkit/{n}.txt',follow_redirects=False).status_code==303
  assert c.get('/course-handbook',follow_redirects=False).status_code==303

def test_private_applied_modules_ai_reflection_portfolio(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'v21.db');iam.init_db()
 with iam.db() as db:
  db.execute('INSERT INTO users(full_name,email,password_hash,application_status,payment_status) VALUES (?,?,?,?,?)',('Student','s@example.org',iam.password_hash('SecurePassword123!'),'approved','paid'))
 with TestClient(iam.app) as c:
  t=re.search(r'name="csrf"[^>]*value="([^"]+)"',c.get('/login').text).group(1)
  assert c.post('/login',data={'email':'s@example.org','password':'SecurePassword123!','csrf':t},follow_redirects=False).status_code==303
  assert c.get('/dashboard').text.count('class="learning-week"')==13
  for n in (11,12,13):
   page=c.get(f'/career/masterclass/{n}')
   assert page.status_code==200
   assert 'IAM AI · ALWAYS HERE' in page.text
   assert 'Official professional learning resources' in page.text
   assert 'wipo.int' in page.text or 'artists.youtube' in page.text
   assert c.get(f'/career/toolkit/{n}.txt').status_code==200
   assert c.get(f'/module/{n}/reflect').status_code==200
   assert c.get(f'/career/project/{n}').status_code==200
  pdf=c.get('/course-handbook');assert pdf.status_code==200 and pdf.content.startswith(b'%PDF')
  assert c.get('/course-addendum').status_code==200
