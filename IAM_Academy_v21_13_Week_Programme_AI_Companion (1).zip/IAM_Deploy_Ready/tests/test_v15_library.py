import json,pathlib
from fastapi.testclient import TestClient
from app import app

root=pathlib.Path(__file__).parents[1]

def test_curated_library_is_usable_and_traces_to_sources():
    library=json.loads((root/'iam-knowledge-v19-private.json').read_text())
    assert len(library['topics'])>=40
    assert len(library['sources'])>=20
    sources={s['id']:s for s in library['sources']}
    for topic in library['topics']:
        assert topic['guidance'] and topic['exercise']
        assert topic['source_ids']
        for ref in topic['source_ids']:
            assert ref in sources, (topic['title'],ref)
    for source in sources.values():
        assert source['url'].startswith('https://')

def test_companion_page_and_library_endpoints():
    client=TestClient(app)
    page=client.get('/study-companion')
    assert page.status_code==200
    assert 'IAM AI · Admissions Guide' in page.text
    assert 'iam-public-guide-v19.js' in page.text
    student=client.get('/student/iam-ai',follow_redirects=False)
    assert student.status_code==303
    library=client.get('/api/iam-ai/library')
    assert library.status_code==403
    assert client.get('/static/iam-knowledge-v15.json').status_code==404
