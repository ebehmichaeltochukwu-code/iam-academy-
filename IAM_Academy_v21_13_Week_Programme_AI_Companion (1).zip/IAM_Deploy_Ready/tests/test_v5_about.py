from fastapi.testclient import TestClient
import app as iam

def test_about_page_and_home_school_experience():
    client=TestClient(iam.app)
    home=client.get('/')
    assert home.status_code==200
    assert home.text.count('data-slide aria-')==4
    assert 'data-go="3"' in home.text
    assert 'data-toggle-autoplay' in home.text
    assert 'id="about"' in home.text
    assert 'iam-user-logo.svg?v=8' in home.text
    about=client.get('/about')
    assert about.status_code==200
    assert 'our purpose' in about.text.lower()
    assert 'government-accredited' in about.text
    assert '/apply' in about.text

def test_admin_redirect_still_protected():
    client=TestClient(iam.app)
    response=client.get('/admin',follow_redirects=False)
    assert response.status_code==303
    assert response.headers['location']=='/login'
