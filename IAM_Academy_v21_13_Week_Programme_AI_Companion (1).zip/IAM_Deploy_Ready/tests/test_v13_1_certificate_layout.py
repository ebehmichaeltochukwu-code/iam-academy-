"""Keep the IAM certificate logo safely inside its decorative borders."""
from reportlab.pdfgen.canvas import Canvas as OriginalCanvas
import app as iam


def test_certificate_logo_stays_inside_inner_border(monkeypatch):
    observed=[]

    class LogoCheckingCanvas(OriginalCanvas):
        def drawImage(self, image, x, y, width=None, height=None, **kwargs):
            observed.append((x,y,width,height))
            return super().drawImage(image,x,y,width=width,height=height,**kwargs)

    monkeypatch.setattr(iam.canvas,'Canvas',LogoCheckingCanvas)
    for preview in (True,False):
        pdf=iam.render_certificate_pdf('Sample Student Name','IAM-SAMPLE-NOT-ISSUED','SAMPLE DATE',preview=preview)
        assert pdf.startswith(b'%PDF')
        x,y,width,height=observed[-1]
        # Inner border: x=39..803, y=39..556. Reserve 12 pt padding from top.
        assert x >= 39 and x+width <= 803
        assert y >= 39 and y+height <= 544
        assert abs(width/height - 1353/828)<0.01
