from pathlib import Path
p=Path(__file__).parent/'app.py'
s=p.read_text()
s=s.replace('from learning_companion import MODULE_ACTIVITIES, lesson_key_points','from iam_ai_library import normalise_article,public_library\nfrom learning_companion import MODULE_ACTIVITIES, lesson_key_points')
s=s.replace(" CREATE TABLE IF NOT EXISTS contact_messages (id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL, topic TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);"," CREATE TABLE IF NOT EXISTS contact_messages (id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL, topic TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);\n CREATE TABLE IF NOT EXISTS iam_knowledge_articles (id INTEGER PRIMARY KEY, title TEXT NOT NULL, guidance TEXT NOT NULL, exercise TEXT NOT NULL, keywords TEXT NOT NULL DEFAULT '', source_name TEXT NOT NULL, source_url TEXT NOT NULL, jurisdiction TEXT NOT NULL DEFAULT 'Global', module INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'draft', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);" )
start="@app.get('/study-companion')\ndef study_companion(request:Request):\n return page(request,'study_companion.html')"
new='''@app.get('/study-companion')
def study_companion(request:Request):
 return page(request,'study_companion_v16.html')

@app.get('/api/iam-ai/library')
def iam_ai_public_library():
 with db() as c: content=public_library(c)
 return JSONResponse(content,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

@app.get('/admin/iam-ai')
def iam_ai_admin(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role']!='admin':return denied(request,'Administrator only',403)
 with db() as c:records=c.execute('SELECT * FROM iam_knowledge_articles ORDER BY id DESC LIMIT 250').fetchall()
 return page(request,'iam_ai_admin.html',records=records)

@app.post('/admin/iam-ai/article')
def iam_ai_admin_add(request:Request,csrf:str=Form(''),title:str=Form(''),guidance:str=Form(''),exercise:str=Form(''),keywords:str=Form(''),source_name:str=Form(''),source_url:str=Form(''),jurisdiction:str=Form('Global'),module:int=Form(1),status:str=Form('draft')):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role']!='admin':return denied(request,'Administrator only',403)
 if not valid_token(request,csrf):return denied(request,'Security token expired. Reload this page.')
 try:a=normalise_article(locals())
 except (ValueError,TypeError) as exc:return denied(request,str(exc))
 with db() as c:
  c.execute('INSERT INTO iam_knowledge_articles (title,guidance,exercise,keywords,source_name,source_url,jurisdiction,module,status) VALUES (:title,:guidance,:exercise,:keywords,:source_name,:source_url,:jurisdiction,:module,:status)',a)
 log(user['id'],'knowledge_article_created',note=a['title'][:120])
 return redirect('/admin/iam-ai')

@app.post('/admin/iam-ai/article/{article_id}/status')
def iam_ai_admin_status(request:Request,article_id:int,csrf:str=Form(''),status:str=Form('draft')):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role']!='admin':return denied(request,'Administrator only',403)
 if not valid_token(request,csrf):return denied(request,'Security token expired. Reload this page.')
 if status not in ('draft','published','withdrawn'):return denied(request,'Invalid status.')
 with db() as c:
  found=c.execute('SELECT id,title FROM iam_knowledge_articles WHERE id=?',(article_id,)).fetchone()
  if not found:return denied(request,'No article found.',404)
  c.execute('UPDATE iam_knowledge_articles SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(status,article_id))
 log(user['id'],'knowledge_article_'+status,article_id)
 return redirect('/admin/iam-ai')
'''
assert start in s
s=s.replace(start,new)
p.write_text(s)

b=Path(__file__).parent/'templates/base.html'
base=b.read_text().replace('<a href="/admin/messages">Enquiries</a>','<a href="/admin/messages">Enquiries</a><a href="/admin/iam-ai">AI Knowledge</a>')
b.write_text(base)
