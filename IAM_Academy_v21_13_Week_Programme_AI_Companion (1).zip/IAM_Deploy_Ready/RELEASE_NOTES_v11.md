# IAM Academy V11 — Ten integrated learning modules

The public site, curriculum, private dashboard and career toolkit now display 10 numbered training modules.

- Modules 1–8 remain the original 24 assessed core lessons, eight graded quizzes and eight staff-reviewed assignments.
- Modules 9–10 cover media interviews/artist representation and genuine publicity/cultural relevance with full original teaching pages, private portfolio drafts, reflections and four-criterion self-assessments.
- Private PDF/text journal transcript now includes the added module reflections.
- Certificate eligibility remains unchanged for enrolled students and verified graduates. Modules 9–10 are part of the learning pathway, but are not retrospectively graded prerequisites.
- No student database migrations, fees, checkout, accreditation, jobs or logo changes.
