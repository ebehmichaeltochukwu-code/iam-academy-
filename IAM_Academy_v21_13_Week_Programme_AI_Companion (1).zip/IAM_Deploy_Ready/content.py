"""IAM original teaching curriculum. Companion videos are third-party YouTube embeds, not IAM-owned."""
VIDEOS = {
 'manager':('-6UdUQpH3Hw','How To Become An Artist Manager','Industry companion: music management'),
 'manager2':('7aDEcc6unvc','How to Be a Good Artist Manager','Industry companion: SmartistU'),
 'terms':('Mp0QIcY2aiQ','15 Terms an Artist Manager Should Know','Music business vocabulary'),
 'career':('Dvtbakkt1l0','How to Become a Music Artist Manager Today','Industry companion: music careers'),
 'business':('8PGMUaHoDTw','What Does a Music Business Manager Do?','Industry companion: music finance'),
 'rights':('vBQr8Z7GnVU','Copyright of a Song: Masters & Publishing','Industry companion: copyright'),
 'royalty':('qQx1j7YNiqM','About The MLC in 60 Seconds','The MLC: US mechanical rights'),
 'royalty2':('tmdVndkIWNc','What is The Mechanical Licensing Collective?','Songtrust / MLC webinar: US context'),
 'great':('BJc_4N0nFWs','What Makes a Great Music Manager?','Industry companion: manager skills'),
 'finance':('nBCLasFvYY4','Why Artists Need Business Managers','Industry companion: commercial controls')
}
# Three purpose-built lessons per week. video field supports admin override of the companion.
WEEKS = [
 {'title':'The Artist Manager’s Foundation','theme':'Build trust before building a career','outcome':'Explain the manager’s duties, boundaries, and responsibilities to an emerging artist.','scenario':'An emerging Afrobeats singer wants you to sign a 5-year exclusive management deal tonight, before you have reviewed the music, finances or the proposed terms. Draft a respectful 200–300 word response and a due-diligence checklist.',
  'lessons':[
   ('What an artist manager actually does','manager','Think of a manager as a steward of the artist’s long-term interests, not the owner of the artist’s creativity.','A manager coordinates priorities, opportunities, teams, and decisions. Booking agents, lawyers, distributors, and publicists have different functions. Never promise outcomes you do not control.','Write a one-page responsibility map: artist decisions, manager decisions, decisions requiring mutual agreement.'),
   ('Trust, ethics and professional boundaries','manager2','Trust is built through clear authority, confidentiality, and disciplined follow-through.','Put approval thresholds in writing. Maintain separate personal and artist finances. Disclose conflicts, retain records, protect private health and family details, and refer legal advice to a qualified professional.','Draft five operating principles for your management relationship.'),
   ('The first 30 days with an artist','terms','Discovery should precede strategy. Ask before you prescribe.','Audit the catalogue, unreleased songs, audience, platforms, contracts, collaborators, debts, capacity, budget and ambitions. Turn vague goals into measurable 90-day milestones.','Create a first-meeting agenda with ten diagnostic questions.')],
  'quiz':[
   ('A manager’s primary job is to…',['own the artist’s creative identity','coordinate decisions and protect long-term career interests','guarantee viral hits','replace the artist’s lawyer'],1),
   ('Which is the best first step with a new artist?',['promise bookings','sign a long exclusive deal','conduct a discovery and risk audit','spend the full marketing budget'],2),
   ('When manager and artist have different goals, the best first move is…',['listen and clarify decision rights','threaten to resign','post the issue online','make the decision secretly'],0),
   ('Why keep business and personal money separate?',['it increases streams','it reduces the need for contracts','it ensures taxes disappear','it improves accountability and recordkeeping'],3)]},
 {'title':'Understanding the Music','theme':'Learn to listen before giving feedback','outcome':'Identify song structure, audience fit and production issues without pretending to be the producer.','scenario':'An artist plays you a new single with a compelling chorus but an overlong introduction and vocals that are hard to hear. The artist says the song is perfect. Write a supportive critique using observation, impact, suggestion and artist choice.',
  'lessons':[
   ('Listen like a manager','great','Separate taste from evidence: what is the song trying to make a listener feel and do?','Listen three times. First for emotional response; second for verse, pre-chorus, chorus, bridge and hook; third for vocal clarity, pacing, transitions, arrangement and replay value. Compare only against an agreed reference, not your favourite genre.','Complete a structured song review: objective, strengths, risks, two testable changes.'),
   ('Song structure, hooks and audience fit','terms','A useful review connects music choices to target listeners.','Distinguish intro, verse, chorus, bridge and outro. Watch when the hook arrives and whether it is memorable. Cultural context matters: Afrobeats, Amapiano, gospel, hip-hop and highlife audiences can expect different arrangements.','Map the structure and timestamps of an artist-approved song, then suggest one controlled A/B test.'),
   ('Giving creative feedback without controlling the artist','manager2','A manager can challenge a choice while preserving the artist’s authorship.','Use “I noticed…”, “For our audience, this may…”, “Could we test…?” Avoid “this is bad.” Invite disagreement, document the decision, and decide whether feedback needs an engineer, producer or coach.','Write a 90-second feedback conversation that begins with strengths and ends with an experiment.')],
  'quiz':[
   ('The most useful creative feedback is…',['specific and testable','a personal insult','a manager’s order','based only on current charts'],0),
   ('Which part most often carries the main repeated idea?',['invoice','chorus / hook','metadata','booking rider'],1),
   ('If vocals are difficult to hear, a manager should first…',['delete the song','buy more followers','describe the issue and request a producer/engineer review','claim production credits'],2),
   ('When a manager dislikes a genre, they should…',['ignore the audience','reject all tracks','force a different artist identity','judge against artist goals and target listeners'],3)]},
 {'title':'Communication, Conflict & Leadership','theme':'Disagree constructively, agree deliberately','outcome':'Handle difficult conversations, feedback and boundaries under pressure.','scenario':'Your artist refuses a radio interview 20 minutes before airtime after a public disagreement. The station threatens to ban the artist. Prepare a three-part response: private conversation, external message and prevention plan.',
  'lessons':[
   ('How to agree and disagree professionally','great','Disagreement is a process, not a personality contest.','State the shared goal, summarise the artist’s view accurately, explain the concern with evidence, name trade-offs, and offer two options. Reserve final creative choices for the agreed decision-maker.','Write a disagreement script on whether to release a song this Friday.'),
   ('Difficult conversations and repair','manager2','Address behaviour early and privately. Attack the problem, not the person.','Use situation, behaviour, impact and request. Ask what information you are missing. Agree a follow-up deadline. Document material business decisions, but never weaponise private conversations.','Prepare a repair conversation after missing a deadline.'),
   ('Team leadership and safeguarding','manager','Protect a safe working environment for artists, staff, contractors and fans.','Define roles for producer, A&R, lawyer, publicist and promoter. Establish escalation for harassment, exploitation, threats or unsafe touring. Do not conceal serious allegations to protect short-term publicity.','Create a one-page team code of conduct and escalation ladder.')],
  'quiz':[
   ('A productive disagreement starts with…',['an ultimatum','a shared objective and listening','public criticism','a threat'],1),
   ('The best way to challenge a risky creative decision is…',['state evidence, options and ownership','take away the artist’s login','publish a complaint','ignore the artist'],0),
   ('If an artist reports unsafe behaviour on tour, the manager should…',['hide the report','prioritise a sponsor','wait for a viral video','protect safety and follow an escalation process'],3),
   ('Which phrase is most constructive?',['You always ruin everything','My taste is better','I noticed the intro may delay the hook; could we test a shorter cut?','We are done discussing this'],2)]},
 {'title':'Music Rights, Agreements & Royalties','theme':'Understand the paperwork before signing','outcome':'Distinguish recording and composition rights, read commercial terms and spot when counsel is needed.','scenario':'A producer offers an artist a low-cost beat but refuses written clearance or a split sheet. The single is scheduled tomorrow. Identify at least five risks and write your recommendation. This is educational, not legal advice.',
  'lessons':[
   ('Masters, compositions and split sheets','rights','A recording and the underlying song are separate rights assets.','Distinguish master ownership, songwriting shares, publishing administration, neighbouring rights and permissions. Agree contributions and document splits before disputes. Do not assume the artist owns a beat or sample because they paid for studio time.','Design a rights-and-credits inventory for three tracks.'),
   ('Royalties, metadata and territory','royalty','Revenue depends on rights, uses, territories and correct data.','Map recording income, performance and mechanical royalties, sync and live income. The MLC is specific to US digital mechanical royalties; Nigeria has different collection and licensing systems requiring local checks. Match titles, ISRCs, ISWCs and contributor data.','Build a royalty checklist and identify three missing metadata fields.'),
   ('Agreements and red flags','royalty2','Good managers know what questions to ask, not how to impersonate a lawyer.','Review term, territory, exclusivity, commission basis, sunset clauses, expenses, approvals, audit rights, termination, IP, accounting and dispute process. Refer enforceability questions to Nigerian entertainment counsel.','Flag six issues in a fictional management term sheet.')],
  'quiz':[
   ('Master rights relate primarily to…',['the sound recording','a tour itinerary','a logo','a personal biography'],0),
   ('A split sheet is useful to…',['replace a lawyer','document agreed composition contributors and shares','guarantee a hit','purchase radio play'],1),
   ('The MLC is relevant mainly to…',['all Nigerian licensing','ticketing','US digital mechanical royalties','concert visas'],2),
   ('A manager reviewing a complex contract should…',['sign without reading','ignore exclusivity','offer legal guarantees','involve qualified entertainment counsel'],3)]},
 {'title':'Brand, Audience & Digital Growth','theme':'Turn identity into a repeatable discovery system','outcome':'Create an ethical artist positioning statement and measured release campaign.','scenario':'An emerging singer has ₦150,000 for one single. A vendor promises 100,000 guaranteed streams for ₦90,000. Build a safe eight-week campaign plan, allocate the budget, and explain how you will measure results.',
  'lessons':[
   ('Artist positioning and story','career','A recognizable identity grows from truth, not fabricated hype.','Document artist purpose, musical identity, audience problem or emotion, visual language and three content pillars. Ensure photos, bios and press releases match real accomplishments. Avoid purchased credentials or fake endorsements.','Write a 60-word artist positioning statement and three proof points.'),
   ('Release strategy from pre-save to post-release','manager2','A release is a sequence of opportunities, not a single upload day.','Use a six-to-eight-week calendar: rights readiness, distributor lead time, content production, pitching, teasers, release assets, community engagement and post-release analysis. Assign owners and contingency dates.','Build a six-week release calendar with owners and deliverables.'),
   ('Analytics, community and ethical promotion','business','Streams alone are not a business model.','Track engaged listeners, repeat listening, retention, email signups, ticket interest, costs and conversions. Segment by geography and content, and use controlled tests. Reject bots, spam, fabricated engagement and payola.','Create a weekly dashboard using 5 metrics and decision rules.')],
  'quiz':[
   ('Artist positioning should be based on…',['invented awards','clear identity and audience evidence','competitor imitation alone','trending slang'],1),
   ('Which practice is high risk?',['audience feedback','email signup','bought fake streams','organic collaboration'],2),
   ('A release timeline should include…',['only release day','only artwork','no responsible owner','pre-release and post-release tasks'],3),
   ('An effective marketing metric is…',['repeat engagement among target listeners','the manager’s follower count','how expensive a poster looks','how many vague impressions are claimed'],0)]},
 {'title':'Money, Touring & Operations','theme':'Run an accountable artist business','outcome':'Build budgets, forecast cash flow and coordinate safe, profitable events.','scenario':'A promoter offers ₦700,000 for a show. Transport, dancers, accommodation and production will cost ₦540,000 before contingency. Write a negotiation position, a budget and a go/no-go decision.',
  'lessons':[
   ('Budgets, commissions and accounting','business','Profit is revenue after costs and agreed entitlements, not bank balance.','Create deal-by-deal budgets, purchase approvals, receipts, invoices, taxes and a monthly management report. Define commissionable income in contracts. Use two-person controls for larger payments and regular reconciliation.','Build a simple event profit-and-loss report including 10% contingency.'),
   ('Show booking, riders and travel','finance','A good-looking fee is not always a good deal.','Confirm promoter identity, location, fee schedule, deposits, technical rider, hospitality, transport, accommodation, security, cancellations, permits and settlement method. Use a written run of show and emergency contacts.','Create a 20-point show-advance checklist.'),
   ('Negotiation and vendor management','great','Negotiate around interests, alternatives and documented obligations.','Set a walk-away figure, identify non-cash benefits, request written revisions, and record who approves concessions. Avoid verbal side deals. Use local counsel for cross-border tax, visas and employment requirements.','Write a counteroffer to a fictional promoter with three negotiable terms.')],
  'quiz':[
   ('A show that pays ₦700k and costs ₦540k before contingency has…',['₦700k guaranteed profit','₦540k guaranteed profit','₦160k before contingency and other costs','no expenses'],2),
   ('An event budget should include…',['only artiste fee','contingency and documented expenses','only accommodation','projected streams'],1),
   ('The best protection in a booking is…',['a verbal promise','a famous promoter photo','advance all expenses personally','written terms and payment milestones'],3),
   ('A manager’s commission should be…',['defined in the agreement and correctly accounted','whatever they choose later','hidden from the artist','always charged on gross with no exception'],0)]},
 {'title':'Deals, Risk & Career Development','theme':'Protect the artist while creating opportunities','outcome':'Evaluate partnerships, manage crisis and construct career decisions across multiple income streams.','scenario':'An unknown brand offers ₦2 million for an exclusive 24-month endorsement across Africa with unlimited content rights. The artist’s current audience is modest. Produce a deal scorecard and a list of clauses to negotiate.',
  'lessons':[
   ('Evaluating labels, brands and partnerships','finance','The headline number is one of many contract variables.','Analyse cash timing, deliverables, exclusivity, moral clauses, licensing scope, creative approval, duration, usage territories and exit rights. Compare offers against current strategic priorities and realistic opportunity cost.','Create a weighted partner evaluation with 6 criteria.'),
   ('Crisis, reputation and digital safety','manager2','Crisis planning makes fast, humane decisions possible.','Verify facts, protect people, keep legal and safeguarding issues separate from public relations, choose a spokesperson and log actions. Do not speculate or promise secrecy where safety or legal obligations apply.','Write an internal 60-minute incident-response protocol.'),
   ('Long-term development and wellbeing','great','Sustainable careers require rest, skills, healthy collaboration and diversified income.','Plan catalogues, live business, merchandise, publishing, partnerships and education carefully. Hold quarterly reviews with the artist’s stated definition of success. Notice burnout and encourage qualified professional support where needed.','Write a 12-month career roadmap with quarterly priorities.')],
  'quiz':[
   ('A long exclusivity clause should be assessed for…',['opportunity cost and scope','logo colour','song tempo','festival weather'],0),
   ('In a crisis, first priority is usually…',['viral speed','safety, accurate facts and responsible escalation','deleting all records','blaming critics'],1),
   ('A strong partnership scorecard considers…',['headline cash only','social buzz only','rights, obligations, term and cash flow','free merchandise alone'],2),
   ('A sustainable artist development plan contains…',['no review dates','only touring','only streams','quarterly goals and wellbeing considerations'],3)]},
 {'title':'The Professional Management Capstone','theme':'Prove you can manage the artist, not just pass a quiz','outcome':'Deliver a complete, ethical 90-day artist management plan with a signed-off decision framework.','scenario':'FINAL PROJECT: Choose a fictional artist or a consenting real artist. Submit 800–1,500 words covering audit, artistic positioning, 3 priority goals, 90-day release schedule, rights checklist, budget, risk register, communication agreement, one disagreement script, and a measurement dashboard. Do not submit confidential material without permission.',
  'lessons':[
   ('Auditing an emerging artist’s business','terms','Document the present state before you promise growth.','Create a current-state snapshot: music assets, collaborators, audience, contracts, rights records, finances, live opportunities and weaknesses. Identify unknowns distinctly from confirmed facts.','Complete a two-page artist audit with a risk register.'),
   ('Constructing the 90-day roadmap','business','Your roadmap should translate ambition into accountable work.','Choose three goals that can be measured. Establish one owner per task, milestones, cash requirements, decision deadlines and stop/go triggers. Balance audience growth with rights readiness and rest.','Submit a calendar, budget and KPI tracker for your 90-day roadmap.'),
   ('Professional judgement and final presentation','manager2','A competent manager can explain the rationale for a decision and its risks.','Write an executive summary for the artist in plain language. Show one respectful disagreement and how consent and responsibilities are documented. Peer feedback can help, but IAM reviewers make certification decisions.','Submit the full capstone dossier for human review.')],
  'quiz':[
   ('A credible 90-day plan must include…',['guaranteed fame','measurable milestones and responsible owners','only motivational quotes','no budget'],1),
   ('When a source is uncertain, the manager should…',['describe it as confirmed','omit it secretly','label it as unverified and investigate','post it publicly'],2),
   ('Who makes final creative decisions?',['the manager in every case','the marketer','the distributor','the artist according to agreed decision rights'],3),
   ('What qualifies a student for IAM’s course certificate?',['all lessons, weekly pass marks and approved practical submissions','payment alone','a social post','watching one video'],0)]}
]
for week_i, week in enumerate(WEEKS,1):
 week['number']=week_i
 week['lessons']=[{'id':f'w{week_i}l{j}','title':row[0],'video_key':row[1],'principle':row[2],'reading':row[3],'practice':row[4], 'number':j} for j,row in enumerate(week['lessons'],1)]
LESSONS={l['id']:(w,l) for w in WEEKS for l in w['lessons']}
READINGS = {
 1:('Artist manager responsibilities','https://soundcharts.com/en/blog/the-mechanics-of-management'),
 2:('Research on the artist-manager relationship','https://knowledge.lancashire.ac.uk/id/eprint/35945/3/35945%20The%20Artist%20Manager%20Relationship.pdf'),
 3:('Working with a music manager','https://orphiq.com/resources/working-with-music-manager'),
 4:('Music publishing basics','https://www.tunecore.com/guides/music-publishing-101'),
 5:('YouTube artist learning resources','https://artists.youtube.com/intl/en-GB/resources/'),
 6:('Music finance and management roles','https://soundcharts.com/en/blog/the-mechanics-of-management'),
 7:('Artist rights and copyright primer','https://www.mi.edu/in-the-know/music-copyright-law-publishing-rights-masters-rights-royalties/'),
 8:('YouTube release strategy resources','https://artists.youtube.com/intl/en-GB/resources/')
}

from deep_dives import DEEP
for lesson_id, details in DEEP.items():
    LESSONS[lesson_id][1]['deep'] = details
