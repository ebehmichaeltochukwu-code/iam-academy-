"""IAM Academy: standalone FastAPI + SQLite admissions and learning platform."""
import os, re, hmac, hashlib, secrets, sqlite3, uuid, json, io, time
from datetime import datetime, timezone
from pathlib import Path
from contextlib import contextmanager
from urllib import request as urlrequest, error as urlerror
from urllib.parse import urlencode
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, Response, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from xml.sax.saxutils import escape as xml_escape
from learning_companion import MODULE_ACTIVITIES, lesson_key_points
from content import WEEKS, LESSONS, VIDEOS, READINGS
from lesson_extensions import LESSON_WORKSHEETS
from career_content import PORTFOLIO, SUPPLEMENTARY_VIDEOS, MODULE_VIDEO_IDS, VIDEOS_BY_ID, CAREER_SOURCES, CAREER_STEPS, BONUS_MASTERCLASSES, ADVANCED_MODULES, APPLIED_MODULE_VIDEOS

ROOT=Path(__file__).resolve().parent
DB_PATH=Path(os.getenv('IAM_DATABASE',str(ROOT/'iam.db')))
PRICE_NGN=int(os.getenv('IAM_TUITION_NGN','100000'))
APP_SECRET=os.getenv('IAM_APP_SECRET','local-development-only-change-before-deployment')
if os.getenv('IAM_HTTPS')=='1' and APP_SECRET=='local-development-only-change-before-deployment':
 raise RuntimeError('Set a secure IAM_APP_SECRET before enabling production HTTPS.')
PAYSTACK_SECRET=os.getenv('PAYSTACK_SECRET_KEY','')
BASE_URL=os.getenv('IAM_BASE_URL','http://127.0.0.1:8000').rstrip('/')
app=FastAPI(title='IAM | Institute of Artist Management')
app.add_middleware(SessionMiddleware,secret_key=APP_SECRET,session_cookie='iam_session',same_site='lax',https_only=os.getenv('IAM_HTTPS','0')=='1',max_age=60*60*24*14)
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
templates=Jinja2Templates(directory=str(ROOT/'templates'))
templates.env.globals['tuition']=PRICE_NGN
templates.env.globals['weeks']=WEEKS
templates.env.globals['advanced_modules']=ADVANCED_MODULES
templates.env.globals['career_steps']=CAREER_STEPS
templates.env.globals['fmt_money']=lambda n:'₦'+format(int(n),',')

@contextmanager
def db():
 DB_PATH.parent.mkdir(parents=True,exist_ok=True)
 c=sqlite3.connect(str(DB_PATH),timeout=30)
 c.row_factory=sqlite3.Row
 c.execute('PRAGMA foreign_keys = ON')
 try:
  yield c
  c.commit()
 except Exception:
  c.rollback(); raise
 finally:c.close()

def init_db():
 with db() as c:
  c.executescript('''
 CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', application_status TEXT NOT NULL DEFAULT 'pending', payment_status TEXT NOT NULL DEFAULT 'unpaid', motivation TEXT NOT NULL DEFAULT '', experience TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), reference TEXT NOT NULL UNIQUE, amount INTEGER NOT NULL, status TEXT NOT NULL, provider TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS progress (user_id INTEGER NOT NULL REFERENCES users(id), lesson_id TEXT NOT NULL, completed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id,lesson_id));
 CREATE TABLE IF NOT EXISTS quiz_attempts (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), week INTEGER NOT NULL, score INTEGER NOT NULL, total INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS submissions (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), week INTEGER NOT NULL, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', feedback TEXT NOT NULL DEFAULT '', submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_at TEXT);
 CREATE TABLE IF NOT EXISTS certificates (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL UNIQUE REFERENCES users(id), code TEXT NOT NULL UNIQUE, issued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS video_overrides (lesson_id TEXT PRIMARY KEY, youtube_id TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, actor_id INTEGER, event TEXT NOT NULL, subject_id INTEGER, note TEXT, at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS auth_attempts (email TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, last_attempt INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS admissions_reviews (id INTEGER PRIMARY KEY, applicant_id INTEGER NOT NULL REFERENCES users(id), reviewer_id INTEGER NOT NULL REFERENCES users(id), decision TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS lesson_journals (user_id INTEGER NOT NULL REFERENCES users(id), lesson_id TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', inspiration TEXT NOT NULL DEFAULT '', next_step TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,lesson_id));
 CREATE TABLE IF NOT EXISTS module_reflections (user_id INTEGER NOT NULL REFERENCES users(id), week INTEGER NOT NULL, insight TEXT NOT NULL DEFAULT '', challenge TEXT NOT NULL DEFAULT '', commitment TEXT NOT NULL DEFAULT '', practice_response TEXT NOT NULL DEFAULT '', self_checks TEXT NOT NULL DEFAULT '[false,false,false,false]', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,week));
 CREATE TABLE IF NOT EXISTS portfolio_drafts (user_id INTEGER NOT NULL REFERENCES users(id), week INTEGER NOT NULL, body TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,week));
 CREATE TABLE IF NOT EXISTS career_opportunities (id INTEGER PRIMARY KEY, title TEXT NOT NULL, organization TEXT NOT NULL, location TEXT NOT NULL DEFAULT 'Unspecified', work_type TEXT NOT NULL DEFAULT 'See listing', url TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', deadline TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS contact_messages (id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL, topic TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'new', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS public_pageviews (day TEXT NOT NULL, path TEXT NOT NULL, hits INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day,path));
 ''')
init_db()

COMMON_PASSWORDS={'password','password123','password1','12345678','123456789','qwerty123','welcome123','iloveyou','admin123','letmein123','iamacademy','iam12345'}
def acceptable_student_password(pwd):
 # Pilot: characters, spaces and punctuation allowed; no arbitrary uppercase/symbol rules.
 return 8 <= len(pwd) <= 128 and pwd.casefold().strip() not in COMMON_PASSWORDS and not re.fullmatch(r'(.)\1{7,}',pwd)

def login_locked(email):
 with db() as c:
  record=c.execute('SELECT attempts,last_attempt FROM auth_attempts WHERE email=?',(email,)).fetchone()
  return bool(record and record['attempts'] >= 6 and int(time.time())-record['last_attempt'] < 900)

def record_login_result(email,success):
 with db() as c:
  if success:c.execute('DELETE FROM auth_attempts WHERE email=?',(email,))
  else:
   now=int(time.time()); previous=c.execute('SELECT attempts,last_attempt FROM auth_attempts WHERE email=?',(email,)).fetchone()
   attempts=(previous['attempts']+1 if previous and now-previous['last_attempt'] < 900 else 1)
   c.execute('INSERT INTO auth_attempts (email,attempts,last_attempt) VALUES (?,?,?) ON CONFLICT(email) DO UPDATE SET attempts=excluded.attempts,last_attempt=excluded.last_attempt',(email,attempts,now))

def password_hash(pwd):
 salt=secrets.token_bytes(16)
 return salt.hex()+':'+hashlib.scrypt(pwd.encode(),salt=salt,n=16384,r=8,p=1).hex()

def password_valid(pwd, digest):
 try:
  salt,hashpart=digest.split(':',1)
  return hmac.compare_digest(hashlib.scrypt(pwd.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex(),hashpart)
 except Exception:return False

def bootstrap_owner_from_environment():
 """Optional one-time owner creation for cloud deploys, never uses default credentials."""
 email=os.getenv('IAM_ADMIN_EMAIL','').strip().lower()
 pwd=os.getenv('IAM_ADMIN_BOOTSTRAP_PASSWORD','')
 name=os.getenv('IAM_ADMIN_NAME','IAM Administrator').strip()
 if not email and not pwd:
  return
 if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(pwd)<16:
  raise RuntimeError('IAM_ADMIN_EMAIL and a 16+ character IAM_ADMIN_BOOTSTRAP_PASSWORD are required together.')
 with db() as c:
  existing=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()
  if existing:
   return
  c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",
            (name,email,password_hash(pwd)))

bootstrap_owner_from_environment()

def initialize_requested_owner():
 """Create the owner from private Railway variables, never from a hard-coded website password.
 Remove IAM_OWNER_INIT_PASSWORD once the initial login works.
 """
 email=os.getenv('IAM_OWNER_EMAIL','').strip().lower()
 pwd=os.getenv('IAM_OWNER_INIT_PASSWORD','')
 if not email or not pwd:
  return
 if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or len(pwd)<8:
  raise RuntimeError('Provide IAM_OWNER_EMAIL and IAM_OWNER_INIT_PASSWORD (8+ characters).')
 name=os.getenv('IAM_OWNER_NAME','IAM Administrator').strip() or 'IAM Administrator'
 with db() as c:
  existing=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()
  hashed=password_hash(pwd)
  if existing:
   c.execute("UPDATE users SET role='admin',password_hash=?,application_status='approved' WHERE id=?",(hashed,existing['id']))
  else:
   c.execute("INSERT INTO users (full_name,email,password_hash,role,application_status,payment_status) VALUES (?,?,?,'admin','approved','paid')",(name,email,hashed))

initialize_requested_owner()

def get_user(request):
 uid=request.session.get('uid')
 if not uid:return None
 with db() as c:return c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()

def token(request):
 if not request.session.get('csrf'):
  request.session['csrf']=secrets.token_urlsafe(24)
 return request.session['csrf']

def valid_token(request, submitted):return hmac.compare_digest(str(token(request)),str(submitted))

def page(request,name,**data):
 return templates.TemplateResponse(request,name,{'user':get_user(request),'csrf':token(request),'price':PRICE_NGN,**data})

def redirect(where):return RedirectResponse(where,status_code=303)

def denied(request, msg='Unable to complete this action.', status_code=400):
 return HTMLResponse(page(request,'message.html',heading='Action not completed',message=msg).body,status_code=status_code)

def log(actor,event,subject=None,note=''):
 with db() as c:c.execute('INSERT INTO audit_log (actor_id,event,subject_id,note) VALUES (?,?,?,?)',(actor,event,subject,note))

def enrollment_ok(user):return user and user['application_status']=='approved' and user['payment_status']=='paid'

def student_gate(request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role'] in ('admin','reviewer'):return redirect('/admin')
 if not enrollment_ok(user):return redirect('/dashboard')
 return None

def admin_gate(request):
 user=get_user(request)
 return None if user and user['role'] in ('admin','reviewer') else redirect('/login')

def course_state(uid):
 with db() as c:
  done={r['lesson_id'] for r in c.execute('SELECT lesson_id FROM progress WHERE user_id=?',(uid,))}
  passes={r['week'] for r in c.execute('SELECT week FROM quiz_attempts WHERE user_id=? GROUP BY week HAVING MAX(1.0*score/total)>=0.75',(uid,))}
  submissions=c.execute('SELECT * FROM submissions WHERE user_id=? ORDER BY id DESC',(uid,)).fetchall()
  cert=c.execute('SELECT * FROM certificates WHERE user_id=?',(uid,)).fetchone()
 return {'done':done,'passes':passes,'submissions':submissions,'approved':{s['week'] for s in submissions if s['status']=='approved'},'certificate':cert,'percent':round(100*len(done)/24)}

def maybe_certificate(uid):
 st=course_state(uid)
 if len(st['done'])==24 and len(st['passes'])==8 and len(st['approved'])==8:
  with db() as c:
   prior=c.execute('SELECT code FROM certificates WHERE user_id=?',(uid,)).fetchone()
   if prior:return prior['code']
   code='IAM-'+uuid.uuid4().hex[:12].upper()
   c.execute('INSERT INTO certificates (user_id,code) VALUES (?,?)',(uid,code))
   return code
 return None

@app.middleware('http')
async def anonymous_public_metrics(request:Request, call_next):
 response=await call_next(request)
 path=request.url.path.rstrip('/') or '/'
 visible={'/','/about','/curriculum','/apply','/career-information','/contact','/study-companion'}
 user_agent=request.headers.get('user-agent','').lower()
 # Count aggregate page views only. No IP, cookies, identifiers or individual student pages.
 if request.method=='GET' and path in visible and response.status_code==200 and not any(bot in user_agent for bot in ('bot','crawler','spider','preview','headless')):
  try:
   with db() as c:
    c.execute('INSERT INTO public_pageviews(day,path,hits) VALUES (?,?,1) ON CONFLICT(day,path) DO UPDATE SET hits=hits+1', (datetime.now(timezone.utc).date().isoformat(),path))
  except sqlite3.Error: pass
 return response

@app.get('/')
def index(request:Request):return page(request,'index.html')

@app.get('/about')
def about(request:Request):return page(request,'about.html')

@app.get('/curriculum')
def curriculum(request:Request):return page(request,'curriculum.html')

@app.get('/contact')
def contact(request:Request, sent:str=''):
 return page(request,'contact.html',sent=bool(sent))

@app.post('/contact')
def contact_send(request:Request, csrf:str=Form(''), full_name:str=Form(''), email:str=Form(''), topic:str=Form(''), message:str=Form(''), website:str=Form('')):
 if not valid_token(request,csrf):return denied(request,'Security token expired. Reload the contact page and try again.')
 if website:return redirect('/contact?sent=1')  # honeypot
 full_name=full_name.strip();email=email.strip().lower();topic=topic.strip();message=message.strip()
 if not 2<=len(full_name)<=100 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not 2<=len(topic)<=100 or not 15<=len(message)<=2500:
  return denied(request,'Please enter your name, valid email, topic and a message of 15–2500 characters.')
 with db() as c:c.execute('INSERT INTO contact_messages(full_name,email,topic,message) VALUES (?,?,?,?)',(full_name,email,topic,message))
 return redirect('/contact?sent=1')

@app.get('/admin/messages')
def admin_messages(request:Request):
 gate=admin_gate(request)
 if gate:return gate
 with db() as c:messages=c.execute('SELECT * FROM contact_messages ORDER BY id DESC LIMIT 250').fetchall()
 return page(request,'admin_messages.html',messages=messages)

@app.post('/admin/messages/{message_id}/reviewed')
def admin_message_reviewed(request:Request,message_id:int,csrf:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if not valid_token(request,csrf):return denied(request,'Invalid security token')
 with db() as c:c.execute("UPDATE contact_messages SET status='reviewed' WHERE id=?",(message_id,))
 return redirect('/admin/messages')

@app.get('/study-companion')
def study_companion(request:Request):
 return page(request,'study_companion.html')

@app.get('/apply')
def apply_form(request:Request):return page(request,'apply.html')

@app.post('/apply')
def apply_post(request:Request,csrf:str=Form(''),full_name:str=Form(''),email:str=Form(''),password:str=Form(''),experience:str=Form(''),motivation:str=Form('')):
 if not valid_token(request,csrf):return denied(request,'Session expired. Refresh and submit again.')
 full_name=full_name.strip();email=email.lower().strip()
 if not 3<=len(full_name)<=100 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email) or not acceptable_student_password(password) or len(motivation.strip())<30:
  return page(request,'apply.html',error='Enter your name, valid email, password (8+ characters, avoid common passwords), and a motivation of at least 30 characters.')
 with db() as c:
  if c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone():return page(request,'apply.html',error='An account with this email already exists. Please sign in.')
  c.execute('INSERT INTO users (full_name,email,password_hash,experience,motivation) VALUES (?,?,?,?,?)',(full_name,email,password_hash(password),experience[:2000],motivation[:4000]))
  uid=c.execute('SELECT last_insert_rowid()').fetchone()[0]
 request.session.clear();request.session['uid']=uid
 log(uid,'application_submitted',uid)
 return redirect('/portal')

@app.get('/login')
def login_form(request:Request):return page(request,'login.html')

@app.post('/login')
def login_post(request:Request,csrf:str=Form(''),email:str=Form(''),password:str=Form('')):
 if not valid_token(request,csrf):return denied(request,'Session expired. Please refresh and retry.')
 email=email.strip().lower()
 if login_locked(email):return page(request,'login.html',error='Too many attempts. Please wait 15 minutes before trying again.')
 with db() as c:row=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
 if not row or not password_valid(password,row['password_hash']):
  record_login_result(email,False)
  return page(request,'login.html',error='Incorrect email or password.')
 record_login_result(email,True)
 request.session.clear();request.session['uid']=row['id']
 return redirect('/portal')

@app.post('/logout')
def logout(request:Request,csrf:str=Form('')):
 if not valid_token(request,csrf):return denied(request,'Session expired.')
 request.session.clear();return redirect('/')

@app.get('/portal')
def portal(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 return redirect('/admin' if user['role'] in ('admin','reviewer') else '/dashboard')

@app.get('/course-handbook')
def course_handbook(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role'] not in ('admin','reviewer') and not enrollment_ok(user):return redirect('/dashboard')
 return FileResponse(ROOT/'docs'/'IAM_10_Week_Course_Reader.pdf', media_type='application/pdf',filename='IAM_10_Week_Course_Reader.pdf')

@app.get('/dashboard')
def dashboard(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role'] in ('admin','reviewer'):return redirect('/admin')
 st=course_state(user['id'])
 next_lesson=next((lesson['id'] for week in WEEKS for lesson in week['lessons'] if lesson['id'] not in st['done']),None)
 with db() as c: journal_count=c.execute('SELECT COUNT(*) FROM lesson_journals WHERE user_id=?',(user['id'],)).fetchone()[0];reflection_count=c.execute('SELECT COUNT(*) FROM module_reflections WHERE user_id=?',(user['id'],)).fetchone()[0]
 return page(request,'dashboard.html',st=st,next_lesson=next_lesson,access=enrollment_ok(user),paystack_enabled=bool(PAYSTACK_SECRET),journal_count=journal_count,reflection_count=reflection_count)


# -------------------- PRIVATE PERSONAL LEARNING JOURNAL --------------------
def journal_data(uid):
 with db() as c:
  notes={r['lesson_id']:r for r in c.execute('SELECT * FROM lesson_journals WHERE user_id=?',(uid,))}
  reflections={r['week']:r for r in c.execute('SELECT * FROM module_reflections WHERE user_id=?',(uid,))}
 return notes,reflections

@app.get('/journal')
def journal_overview(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 notes,reflections=journal_data(user['id'])
 return page(request,'journal.html',notes=notes,reflections=reflections)

@app.post('/lesson/{lesson_id}/notes')
def save_lesson_notes(request:Request,lesson_id:str,csrf:str=Form(''),notes:str=Form(''),inspiration:str=Form(''),next_step:str=Form('')):
 gate=student_gate(request)
 if gate:return gate
 if not valid_token(request,csrf):return denied(request,'Session expired. Refresh and save again.')
 if lesson_id not in LESSONS:return denied(request,'Lesson not found.',404)
 if max(len(notes),len(inspiration),len(next_step))>16000:return denied(request,'Each note field must be 16,000 characters or fewer.')
 uid=get_user(request)['id']
 with db() as c:
  c.execute('''INSERT INTO lesson_journals (user_id,lesson_id,notes,inspiration,next_step,updated_at)
   VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)
   ON CONFLICT(user_id,lesson_id) DO UPDATE SET notes=excluded.notes,inspiration=excluded.inspiration,next_step=excluded.next_step,updated_at=CURRENT_TIMESTAMP''',
   (uid,lesson_id,notes.strip(),inspiration.strip(),next_step.strip()))
 if request.headers.get('X-Requested-With')=='XMLHttpRequest':return JSONResponse({'saved':True,'lesson':lesson_id})
 return redirect('/lesson/'+lesson_id+'#learning-journal')

@app.get('/module/{week_no}/reflect')
def module_reflect(request:Request,week_no:int):
 gate=student_gate(request)
 if gate:return gate
 if week_no not in MODULE_ACTIVITIES:return redirect('/dashboard')
 uid=get_user(request)['id']
 with db() as c:
  existing=c.execute('SELECT * FROM module_reflections WHERE user_id=? AND week=?',(uid,week_no)).fetchone()
  done={row['lesson_id'] for row in c.execute('SELECT lesson_id FROM progress WHERE user_id=?',(uid,))}
 if 1<=week_no<=len(WEEKS):
  week=WEEKS[week_no-1]
  completed=sum(l['id'] in done for l in week['lessons'])
 else:
  from types import SimpleNamespace
  item=next((x for x in ADVANCED_MODULES if x['number']==week_no),None)
  if item is None:return redirect('/dashboard')
  week=SimpleNamespace(number=week_no,title=item['title'])
  completed=None
 checks=json.loads(existing['self_checks']) if existing else [False]*4
 score=sum(bool(x) for x in checks[:4])
 return page(request,'module_reflect.html',week=week,activity=MODULE_ACTIVITIES[week_no],entry=existing,checks=checks,score=score,completed=completed)

@app.post('/module/{week_no}/reflect')
def module_reflect_save(request:Request,week_no:int,csrf:str=Form(''),insight:str=Form(''),challenge:str=Form(''),commitment:str=Form(''),practice_response:str=Form(''),check_0:str=Form(''),check_1:str=Form(''),check_2:str=Form(''),check_3:str=Form('')):
 gate=student_gate(request)
 if gate:return gate
 if not valid_token(request,csrf):return denied(request,'Session expired. Refresh and retry.')
 if week_no not in MODULE_ACTIVITIES:return denied(request,'Module not found.',404)
 parts=(insight,challenge,commitment,practice_response)
 if any(len(x)>16000 for x in parts):return denied(request,'Each reflection field must be 16,000 characters or fewer.')
 if not any(x.strip() for x in parts):return denied(request,'Write at least one reflection before saving.')
 checks=[x=='on' for x in (check_0,check_1,check_2,check_3)]
 uid=get_user(request)['id']
 with db() as c:
  c.execute('''INSERT INTO module_reflections (user_id,week,insight,challenge,commitment,practice_response,self_checks,updated_at)
   VALUES (?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
   ON CONFLICT(user_id,week) DO UPDATE SET insight=excluded.insight,challenge=excluded.challenge,commitment=excluded.commitment,practice_response=excluded.practice_response,self_checks=excluded.self_checks,updated_at=CURRENT_TIMESTAMP''',
   (uid,week_no,*[x.strip() for x in parts],json.dumps(checks)))
 return redirect('/module/'+str(week_no)+'/reflect#saved')

def journal_transcript(uid,name):
 notes,reflections=journal_data(uid)
 lines=['IAM ACADEMY | PERSONAL LEARNING JOURNAL','Student: '+name,'Compiled: '+datetime.now(timezone.utc).strftime('%d %B %Y %H:%M UTC'),'','This is a transcript of the student’s SAVED WRITTEN NOTES and reflections.','It is not an automatic transcription of YouTube videos, speech, or classes.','']
 if not notes and not reflections: lines.append('Nothing saved yet. Return to your lessons to add notes and reflections.')
 for week in WEEKS:
  entries=[(l,notes[l['id']]) for l in week['lessons'] if l['id'] in notes]
  reflection=reflections.get(week['number'])
  if not entries and not reflection:continue
  lines.extend(['='*58,'MODULE '+str(week['number'])+' | '+week['title'],''])
  for lesson,row in entries:
   lines.extend(['LESSON: '+lesson['title'],'Updated: '+row['updated_at']])
   for title,key in [('My notes','notes'),('Inspiration and ideas','inspiration'),('Next action','next_step')]:
    if row[key]:lines.extend([title+':',row[key]])
   lines.append('')
  if reflection:
   lines.extend(['MODULE REFLECTION','Updated: '+reflection['updated_at']])
   for title,key in [('My biggest learning','insight'),('My challenge','challenge'),('My commitment','commitment'),('Practice response','practice_response')]:
    if reflection[key]:lines.extend([title+':',reflection[key]])
   checks=json.loads(reflection['self_checks'])[:4]
   lines.append('Self-review: '+str(sum(bool(x) for x in checks))+'/4 criteria ticked (self-reported; not an IAM grade)')
   for i,label in enumerate(MODULE_ACTIVITIES[week['number']]['rubric']):
    lines.append(('YES' if i<len(checks) and checks[i] else 'NOT YET')+' | '+label)
   lines.append('')
 for item in ADVANCED_MODULES:
  reflection=reflections.get(item['number'])
  if not reflection:continue
  lines.extend(['='*58,'MODULE '+str(item['number'])+' | '+item['title'],'','MODULE REFLECTION','Updated: '+reflection['updated_at']])
  for title,key in [('My biggest learning','insight'),('My challenge','challenge'),('My commitment','commitment'),('Practice response','practice_response')]:
   if reflection[key]: lines.extend([title+':',reflection[key]])
  checks=json.loads(reflection['self_checks'])[:4]
  lines.append('Self-review: '+str(sum(bool(x) for x in checks))+'/4 criteria ticked (self-reported; not an IAM grade)')
  for i,label in enumerate(MODULE_ACTIVITIES[item['number']]['rubric']):
   lines.append(('YES' if i<len(checks) and checks[i] else 'NOT YET')+' | '+label)
  lines.append('')
 lines.extend(['','Private student work. Generated by IAM Academy.'])
 return '\n'.join(lines)

@app.get('/journal/download.txt')
def journal_download_text(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 body=journal_transcript(user['id'],user['full_name'])
 return Response(content=body,media_type='text/plain; charset=utf-8',headers={'Content-Disposition':'attachment; filename="IAM_Learning_Journal.txt"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'})

@app.get('/journal/download.pdf')
def journal_download_pdf(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 transcript=journal_transcript(user['id'],user['full_name'])
 out=io.BytesIO()
 doc=SimpleDocTemplate(out,pagesize=A4,rightMargin=47,leftMargin=47,topMargin=55,bottomMargin=54,title='IAM Personal Learning Journal',author='Institute of Artist Management')
 styles=getSampleStyleSheet()
 styles.add(ParagraphStyle(name='IamBody',parent=styles['Normal'],fontName='Helvetica',fontSize=9.5,leading=15,spaceAfter=6,textColor=HexColor('#1c3048'),wordWrap='CJK'))
 styles.add(ParagraphStyle(name='IamTitle',parent=styles['Heading1'],fontName='Helvetica-Bold',fontSize=17,leading=21,textColor=HexColor('#122b49'),spaceAfter=15))
 styles.add(ParagraphStyle(name='IamSection',parent=styles['Heading3'],fontSize=12,leading=17,textColor=HexColor('#174f86'),spaceBefore=13,spaceAfter=6))
 story=[]
 for i,line in enumerate(transcript.splitlines()):
  if i==0:story.append(Paragraph(xml_escape(line),styles['IamTitle']))
  elif line.startswith('MODULE ') or line.startswith('LESSON:') or line=='MODULE REFLECTION':story.append(Paragraph(xml_escape(line),styles['IamSection']))
  elif line.startswith('====='):story.append(Spacer(1,12))
  elif not line.strip():story.append(Spacer(1,7))
  else:story.append(Paragraph(xml_escape(line).replace('\t','&nbsp;'),styles['IamBody']))
 doc.build(story)
 return Response(content=out.getvalue(),media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="IAM_Learning_Journal.pdf"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'})

@app.get('/lesson/{lesson_id}')
def lesson(request:Request,lesson_id:str):
 user=get_user(request)
 if not user:return redirect('/login')
 admin_preview=user['role']=='admin'
 if not admin_preview:
  gate=student_gate(request)
  if gate:return gate
 if lesson_id not in LESSONS:return redirect('/admin/lessons' if admin_preview else '/dashboard')
 week,lesson=LESSONS[lesson_id];st=({'done':set()} if admin_preview else course_state(user['id']))
 with db() as c:override=c.execute('SELECT youtube_id FROM video_overrides WHERE lesson_id=?',(lesson_id,)).fetchone()
 video=VIDEOS[lesson['video_key']]
 vid=override['youtube_id'] if override else video[0]
 saved_note=None
 if not admin_preview:
  with db() as c:saved_note=c.execute('SELECT * FROM lesson_journals WHERE user_id=? AND lesson_id=?',(user['id'],lesson_id)).fetchone()
 return page(request,'lesson.html',week=week,lesson=lesson,video_id=vid,video=video,reading=READINGS[week['number']],workbook=LESSON_WORKSHEETS.get(lesson_id),st=st,saved_note=saved_note,admin_preview=admin_preview,key_points=lesson_key_points(lesson),extra_videos=[VIDEOS_BY_ID[video_id] for video_id in MODULE_VIDEO_IDS.get(week['number'],[])])

@app.post('/lesson/{lesson_id}/complete')
def lesson_complete(request:Request,lesson_id:str,csrf:str=Form('')):
 gate=student_gate(request)
 if gate:return gate
 if not valid_token(request,csrf) or lesson_id not in LESSONS:return denied(request)
 uid=get_user(request)['id']
 with db() as c:c.execute('INSERT OR IGNORE INTO progress (user_id,lesson_id) VALUES (?,?)',(uid,lesson_id))
 maybe_certificate(uid)
 return redirect('/dashboard#week-'+str(LESSONS[lesson_id][0]['number']))

@app.get('/quiz/{week_no}')
def quiz(request:Request,week_no:int):
 gate=student_gate(request)
 if gate:return gate
 if week_no<1 or week_no>8:return redirect('/dashboard')
 w=WEEKS[week_no-1];st=course_state(get_user(request)['id'])
 return page(request,'quiz.html',week=w,st=st)

@app.post('/quiz/{week_no}')
async def quiz_submit(request:Request,week_no:int):
 gate=student_gate(request)
 if gate:return gate
 if not 1<=week_no<=8:return redirect('/dashboard')
 form=await request.form()
 if not valid_token(request,form.get('csrf','')):return denied(request,'Session expired. Refresh and retry.')
 w=WEEKS[week_no-1]; correct=0
 for i,(_,_,answer) in enumerate(w['quiz']):
  try:correct+=int(form.get('q'+str(i),'-1'))==answer
  except ValueError:pass
 uid=get_user(request)['id']
 with db() as c:c.execute('INSERT INTO quiz_attempts (user_id,week,score,total) VALUES (?,?,?,?)',(uid,week_no,correct,len(w['quiz'])))
 maybe_certificate(uid)
 return page(request,'quiz_result.html',week=w,correct=correct,total=len(w['quiz']),passed=correct/len(w['quiz'])>=.75)

@app.post('/submission/{week_no}')
def submit_assignment(request:Request,week_no:int,csrf:str=Form(''),body:str=Form('')):
 gate=student_gate(request)
 if gate:return gate
 if not valid_token(request,csrf) or not 1<=week_no<=8:return denied(request)
 if len(body.strip())<160 or len(body)>18000:return denied(request,'Submission must be at least 160 characters and no more than 18,000.')
 if week_no==8 and not 800<=len(body.split())<=1500:return denied(request,'Final capstone must contain 800 to 1,500 words. Prepare a full professional management plan.')
 uid=get_user(request)['id']
 with db() as c:c.execute('INSERT INTO submissions (user_id,week,body) VALUES (?,?,?)',(uid,week_no,body.strip()))
 log(uid,'assignment_submitted',uid,'Week '+str(week_no))
 return redirect('/dashboard#week-'+str(week_no))

@app.post('/pay')
def pay(request:Request, csrf:str=Form('')):
 if not valid_token(request,csrf):return denied(request,'Session expired.')
 user=get_user(request)
 if not user:return redirect('/login')
 if user['application_status']!='approved':return redirect('/dashboard')
 if user['payment_status']=='paid':return redirect('/dashboard')
 if not PAYSTACK_SECRET:return page(request,'message.html',heading='Payment activation pending',message='Online payments are not yet enabled. An IAM administrator must configure the Paystack secret key. You can contact admissions for available verified payment instructions.')
 ref='IAM-'+secrets.token_hex(12)
 payload=json.dumps({'email':user['email'],'amount':PRICE_NGN*100,'currency':'NGN','reference':ref,'callback_url':BASE_URL+'/pay/verify/'+ref,'metadata':{'applicant_id':user['id']}}).encode()
 req=urlrequest.Request('https://api.paystack.co/transaction/initialize',data=payload,headers={'Authorization':'Bearer '+PAYSTACK_SECRET,'Content-Type':'application/json'})
 try:
  with urlrequest.urlopen(req,timeout=15) as r:obj=json.load(r)
  if not obj.get('status') or not obj.get('data',{}).get('authorization_url'):raise ValueError('Payment provider rejected initialization')
  with db() as c:c.execute('INSERT INTO payments (user_id,reference,amount,status,provider) VALUES (?,?,?,?,?)',(user['id'],ref,PRICE_NGN,'pending','paystack'))
  return redirect(obj['data']['authorization_url'])
 except Exception:
  return page(request,'message.html',heading='Payment unavailable',message='The payment service is temporarily unavailable. You have not been charged by IAM. Please retry later.')

@app.get('/pay/verify/{ref}')
def pay_verify(request:Request,ref:str):
 user=get_user(request)
 if not user:return redirect('/login')
 with db() as c:payment=c.execute('SELECT * FROM payments WHERE reference=? AND user_id=?',(ref,user['id'])).fetchone()
 if not payment:return denied(request,'Unrecognized payment reference.',404)
 if not PAYSTACK_SECRET:return denied(request,'Paystack is not configured.')
 req=urlrequest.Request('https://api.paystack.co/transaction/verify/'+ref,headers={'Authorization':'Bearer '+PAYSTACK_SECRET})
 try:
  with urlrequest.urlopen(req,timeout=15) as r:obj=json.load(r)
  d=obj.get('data') or {}
  if obj.get('status') and d.get('status')=='success' and d.get('reference')==ref and d.get('currency')=='NGN' and d.get('amount')==PRICE_NGN*100:
   with db() as c:
    c.execute('UPDATE payments SET status=? WHERE reference=?',('verified',ref))
    c.execute('UPDATE users SET payment_status=? WHERE id=?',('paid',user['id']))
   log(user['id'],'paystack_payment_verified',user['id'],ref)
  else:return page(request,'message.html',heading='Not verified yet',message='Paystack has not confirmed a successful payment. You can retry verification using your payment reference.')
 except Exception:return page(request,'message.html',heading='Verification unavailable',message='The provider could not be reached. IAM will not unlock enrolment until verification succeeds.')
 return redirect('/dashboard')

@app.get('/admin')
def admin(request:Request, tab:str='overview'):
 gate=admin_gate(request)
 if gate:return gate
 with db() as c:
  counts={k:c.execute('SELECT COUNT(*) FROM users WHERE '+cond).fetchone()[0] for k,cond in [('applications',"role='student'"),('pending',"application_status='pending'"),('approved',"role='student' AND application_status='approved'"),('paid',"role='student' AND payment_status='paid'")]}
  students=c.execute("""SELECT u.*,
      (SELECT COUNT(*) FROM progress p WHERE p.user_id=u.id) AS lessons_complete,
      (SELECT COUNT(*) FROM (SELECT week FROM quiz_attempts q WHERE q.user_id=u.id GROUP BY week HAVING MAX(1.0*score/total)>=0.75)) AS quizzes_passed,
      (SELECT COUNT(DISTINCT week) FROM submissions s WHERE s.user_id=u.id AND s.status='approved') AS projects_approved,
      (SELECT code FROM certificates cert WHERE cert.user_id=u.id) AS certificate_code
      FROM users u WHERE u.role='student' ORDER BY u.created_at DESC, u.id DESC""").fetchall()
  submissions=c.execute('SELECT s.*,u.full_name,u.email FROM submissions s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC').fetchall()
  payments=c.execute('SELECT p.*,u.full_name,u.email FROM payments p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC').fetchall()
  logs=c.execute('SELECT a.*,u.full_name FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 35').fetchall()
 return page(request,'admin.html',counts=counts,students=students,submissions=submissions,payments=payments,logs=logs,tab=tab)

@app.get('/admin/applicant/{uid}')
def admin_applicant_detail(request:Request,uid:int):
 gate=admin_gate(request)
 if gate:return gate
 with db() as c:
  applicant=c.execute("SELECT * FROM users WHERE id=? AND role='student'",(uid,)).fetchone()
  if not applicant:return denied(request,'Applicant not found.',404)
  reviews=c.execute('SELECT r.*,u.full_name AS reviewer_name FROM admissions_reviews r JOIN users u ON u.id=r.reviewer_id WHERE r.applicant_id=? ORDER BY r.id DESC',(uid,)).fetchall()
  assignments=c.execute('SELECT week,status,submitted_at,feedback FROM submissions WHERE user_id=? ORDER BY week',(uid,)).fetchall()
  lessons=c.execute('SELECT COUNT(*) FROM progress WHERE user_id=?',(uid,)).fetchone()[0]
 return page(request,'admin_applicant.html',applicant=applicant,reviews=reviews,assignments=assignments,lessons=lessons)

@app.post('/admin/applicant/{uid}')
def review_applicant(request:Request,uid:int,csrf:str=Form(''),decision:str=Form(''),note:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if not valid_token(request,csrf) or decision not in ('approved','rejected'):return denied(request)
 with db() as c:
  candidate=c.execute("SELECT id FROM users WHERE id=? AND role='student'",(uid,)).fetchone()
  if not candidate:return denied(request,'Applicant not found.',404)
  c.execute("UPDATE users SET application_status=? WHERE id=? AND role='student'",(decision,uid))
  c.execute('INSERT INTO admissions_reviews (applicant_id,reviewer_id,decision,note) VALUES (?,?,?,?)',(uid,get_user(request)['id'],decision,note.strip()[:2000]))
 log(get_user(request)['id'],'application_'+decision,uid,note.strip()[:200])
 return redirect('/admin/applicant/'+str(uid))

@app.post('/admin/payment/{uid}')
def manual_payment(request:Request,uid:int,csrf:str=Form(''),reference:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if get_user(request)['role']!='admin':return denied(request,'Only an administrator can verify payments.',403)
 if not valid_token(request,csrf):return denied(request)
 if not 6<=len(reference.strip())<=120:return denied(request,'Provide an independently checked bank reference (6 to 120 characters).')
 with db() as c:
  student=c.execute("SELECT * FROM users WHERE id=? AND role='student'",(uid,)).fetchone()
  if not student or student['application_status']!='approved':return denied(request,'Only approved applicants can have payments recorded.')
  if c.execute('SELECT id FROM payments WHERE reference=?',(reference.strip(),)).fetchone():return denied(request,'Reference already used.')
  c.execute('INSERT INTO payments (user_id,reference,amount,status,provider) VALUES (?,?,?,?,?)',(uid,reference.strip(),PRICE_NGN,'verified','manual_review'))
  c.execute("UPDATE users SET payment_status='paid' WHERE id=?",(uid,))
 log(get_user(request)['id'],'manual_payment_verified',uid,reference.strip())
 return redirect('/admin?tab=payments')

@app.post('/admin/submission/{sid}')
def review_submission(request:Request,sid:int,csrf:str=Form(''),decision:str=Form(''),feedback:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if not valid_token(request,csrf) or decision not in ('approved','revision'):return denied(request)
 if len(feedback.strip())<12:return denied(request,'Provide meaningful written feedback of at least 12 characters.')
 with db() as c:
  s=c.execute('SELECT * FROM submissions WHERE id=?',(sid,)).fetchone()
  if not s:return denied(request,'Submission not found.',404)
  c.execute("UPDATE submissions SET status=?, feedback=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(decision,feedback.strip()[:3000],sid))
 log(get_user(request)['id'],'submission_'+decision,s['user_id'],'Week '+str(s['week']))
 maybe_certificate(s['user_id'])
 return redirect('/admin?tab=submissions')

@app.get('/admin/videos')
def admin_videos(request:Request):
 gate=admin_gate(request)
 if gate:return gate
 with db() as c:overrides={r['lesson_id']:r['youtube_id'] for r in c.execute('SELECT * FROM video_overrides')}
 return page(request,'videos.html',overrides=overrides,vids=VIDEOS)

@app.post('/admin/videos/{lesson_id}')
def admin_video_edit(request:Request,lesson_id:str,csrf:str=Form(''),youtube_id:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if not valid_token(request,csrf) or lesson_id not in LESSONS:return denied(request)
 # Input is a bare YouTube video ID, not arbitrary embed HTML or a URL.
 if not re.fullmatch(r'[A-Za-z0-9_-]{11}',youtube_id):return denied(request,'Enter a valid 11-character YouTube video ID.')
 with db() as c:c.execute('INSERT INTO video_overrides (lesson_id,youtube_id) VALUES (?,?) ON CONFLICT(lesson_id) DO UPDATE SET youtube_id=excluded.youtube_id',(lesson_id,youtube_id))
 log(get_user(request)['id'],'video_updated',None,lesson_id)
 return redirect('/admin/videos')

def render_certificate_pdf(student_name:str,code:str,issue_date:str,preview:bool=False)->bytes:
 """Same award layout for real certificates and admin-only watermarked preview."""
 b=io.BytesIO();c=canvas.Canvas(b,pagesize=(842,595));c.setTitle('IAM Certificate of Course Completion'+(' - PREVIEW' if preview else ''))
 navy=HexColor('#0F2745');gold=HexColor('#d9b45f')
 c.setFillColor(navy);c.rect(0,0,842,595,fill=1,stroke=0)
 c.setStrokeColor(gold);c.setLineWidth(2);c.rect(27,27,788,541,stroke=1,fill=0)
 c.setStrokeColor(HexColor('#67809a'));c.setLineWidth(.6);c.rect(39,39,764,517,stroke=1,fill=0)
 # Place the original supplied white-and-gold IAM artwork, with only its black
 # background removed; no redrawn or invented identity elements.
 logo=ImageReader(str(ROOT/'static'/'iam-certificate-logo.png'))
 # Keep the full logo, at its original proportions, entirely inside both
 # decorative borders with breathing room above the graduation cap.
 c.drawImage(logo,322,423,width=198,height=121,mask='auto')
 c.setStrokeColor(gold);c.line(180,418,662,418)
 c.setFillColor(HexColor('#ffffff'));c.setFont('Helvetica-Bold',19);c.drawCentredString(421,391,'CERTIFICATE OF COURSE COMPLETION')
 c.setFont('Helvetica',13);c.drawCentredString(421,361,'This certifies that')
 name=' '.join(student_name.split())[:85]
 name_size=30 if len(name)<33 else (23 if len(name)<49 else 17)
 c.setFillColor(gold);c.setFont('Helvetica-Bold',name_size);c.drawCentredString(421,316,name)
 c.setFillColor(HexColor('#ffffff'));c.setFont('Helvetica',14)
 c.drawCentredString(421,279,'has completed the assessed Professional Artist Management programme')
 c.drawCentredString(421,256,'within IAM Academy’s ten-week self-paced learning pathway')
 c.setStrokeColor(gold);c.line(275,239,567,239)
 c.setFillColor(HexColor('#e7c579'));c.setFont('Helvetica',11)
 c.drawCentredString(421,207,'Certificate ID: '+code)
 c.drawCentredString(421,188,'Date of issue: '+issue_date)
 c.setFillColor(HexColor('#f0f0ef'));c.setFont('Helvetica',8.6)
 c.drawCentredString(421,114,'Issued by IAM Academy upon completion of its assessed foundation requirements.')
 c.drawCentredString(421,98,'Independent training credential; not a government-accredited qualification.')
 if preview:
  c.setFillColor(HexColor('#ffd897'));c.setFont('Helvetica-Bold',30)
  c.saveState();c.translate(421,143);c.rotate(0);c.drawCentredString(0,0,'SAMPLE - NOT VALID');c.restoreState()
  c.setFont('Helvetica-Bold',10);c.drawCentredString(421,67,'ADMIN PREVIEW - NO CREDENTIAL ISSUED OR RECORDED')
 else:
  c.setFont('Helvetica',9);c.setFillColor(gold)
  c.drawCentredString(421,65,'Verify this certificate: '+BASE_URL+'/verify/'+code)
 c.showPage();c.save();return b.getvalue()

@app.get('/certificate')
def certificate(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role'] in ('admin','reviewer'):return redirect('/admin/certificate-preview') if user['role']=='admin' else redirect('/admin')
 st=course_state(user['id'])
 if not st['certificate']:return redirect('/dashboard')
 payload=render_certificate_pdf(user['full_name'],st['certificate']['code'],st['certificate']['issued_at'][:10])
 return Response(content=payload,media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="IAM-certificate.pdf"','Cache-Control':'private, no-store'})

@app.get('/admin/certificate-preview')
def admin_certificate_preview(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role']!='admin':return denied(request,'Administrator access required.',403)
 content=render_certificate_pdf('Sample Student Name','IAM-SAMPLE-NOT-ISSUED','SAMPLE DATE',preview=True)
 return Response(content=content,media_type='application/pdf',headers={'Content-Disposition':'inline; filename="IAM_Certificate_SAMPLE_Not_Issued.pdf"','Cache-Control':'private, no-store','X-Robots-Tag':'noindex, nofollow'})

@app.get('/admin/lessons')
def admin_lessons_preview_index(request:Request):
 user=get_user(request)
 if not user:return redirect('/login')
 if user['role']!='admin':return denied(request,'Administrator access required.',403)
 return page(request,'admin_lessons.html',applied_modules=ADVANCED_MODULES)

@app.get('/verify')
def verify_lookup(request:Request, code:str=''):
 code=code.strip().upper()
 if code and re.fullmatch(r'[A-Z0-9-]{1,50}',code):return redirect('/verify/'+code)
 return page(request,'verify_lookup.html',invalid=bool(code))

@app.get('/verify/{code}')
def verify(request:Request,code:str):
 with db() as c:row=c.execute('SELECT c.code,c.issued_at,u.full_name FROM certificates c JOIN users u ON u.id=c.user_id WHERE c.code=?',(code,)).fetchone()
 return page(request,'verify.html',cert=row)



# ---------- CAREER READINESS AND GRADUATE OPPORTUNITIES ----------
@app.get('/career-information')
def career_information(request:Request):
 return page(request,'career_public.html',portfolio=PORTFOLIO)

@app.get('/career')
def career_roadmap(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 st=course_state(user['id'])
 with db() as c:
  drafts={r['week']:r for r in c.execute('SELECT week,updated_at FROM portfolio_drafts WHERE user_id=?',(user['id'],))}
 return page(request,'career.html',portfolio=PORTFOLIO,drafts=drafts,st=st,career_sources=CAREER_SOURCES)

@app.get('/career/masterclass/{week_no}')
def career_masterclass(request:Request,week_no:int):
 user=get_user(request)
 if not user:return redirect('/login')
 admin_preview=user['role']=='admin'
 if not admin_preview:
  gate=student_gate(request)
  if gate:return gate
 masterclass=BONUS_MASTERCLASSES.get(week_no)
 if masterclass is None:return redirect('/career')
 return page(request,'career_masterclass.html',masterclass=masterclass,brief=PORTFOLIO[week_no-1],week_no=week_no,admin_preview=admin_preview,companion_videos=APPLIED_MODULE_VIDEOS.get(week_no,[]))

@app.get('/career/project/{week_no}')
def career_project(request:Request,week_no:int):
 gate=student_gate(request)
 if gate:return gate
 if not 1<=week_no<=len(PORTFOLIO):return redirect('/career')
 user=get_user(request)
 with db() as c:draft=c.execute('SELECT * FROM portfolio_drafts WHERE user_id=? AND week=?',(user['id'],week_no)).fetchone()
 return page(request,'career_project.html',brief=PORTFOLIO[week_no-1],draft=draft,masterclass=BONUS_MASTERCLASSES.get(week_no))

@app.post('/career/project/{week_no}')
def save_career_project(request:Request,week_no:int,csrf:str=Form(''),body:str=Form('')):
 gate=student_gate(request)
 if gate:return gate
 if not 1<=week_no<=len(PORTFOLIO) or not valid_token(request,csrf):return denied(request)
 if len(body)>40000:return denied(request,'Please keep this draft under 40,000 characters.')
 with db() as c:
  c.execute('INSERT INTO portfolio_drafts(user_id,week,body) VALUES (?,?,?) ON CONFLICT(user_id,week) DO UPDATE SET body=excluded.body,updated_at=CURRENT_TIMESTAMP', (get_user(request)['id'],week_no,body.strip()))
 return redirect(f'/career/project/{week_no}?saved=1')

@app.get('/career/toolkit/{week_no}.txt')
def download_career_toolkit(request:Request,week_no:int):
 gate=student_gate(request)
 if gate:return gate
 if not 1<=week_no<=len(PORTFOLIO):return redirect('/career')
 b=PORTFOLIO[week_no-1]
 lines=[f'IAM ACADEMY | MODULE {week_no} WORKING TEMPLATE',b['title'].upper(),'',b['purpose'],'',f'DELIVERABLE: {b["deliverable"]}','']
 for title,prompt in b['sections']:lines.extend([title.upper(),prompt,'Your work:','_'*65,''])
 lines+=['SELF-ASSESSMENT CHECKLIST:']+[f'[ ] {x}' for x in b['checklist']]+['','Disclaimer: an IAM practice template, not legal advice or a guaranteed job outcome.']
 return Response('\n'.join(lines),media_type='text/plain; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="{b["file"]}"','Cache-Control':'private, no-store'})

@app.get('/career/portfolio.pdf')
def download_career_portfolio(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 with db() as c:drafts={r['week']:r['body'] for r in c.execute('SELECT week,body FROM portfolio_drafts WHERE user_id=?',(user['id'],))}
 buff=io.BytesIO()
 styles=getSampleStyleSheet()
 doc=SimpleDocTemplate(buff,pagesize=A4,topMargin=46,bottomMargin=46)
 story=[Paragraph('IAM ACADEMY | PERSONAL CAREER PORTFOLIO',styles['Title']),Paragraph(xml_escape(user['full_name']),styles['Heading2']),Spacer(1,12)]
 for brief in PORTFOLIO:
  story.append(Paragraph(f"Module {brief['week']}: {xml_escape(brief['title'])}",styles['Heading2']))
  story.append(Paragraph(xml_escape(brief['deliverable']),styles['Normal']))
  story.append(Spacer(1,10))
  if drafts.get(brief['week']):
   for paragraph in drafts[brief['week']].splitlines():story.append(Paragraph(xml_escape(paragraph) or ' ',styles['Normal']))
  else:story.append(Paragraph('Not yet completed',styles['Italic']))
  story.append(Spacer(1,18))
 doc.build(story)
 return Response(buff.getvalue(),media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="IAM_Personal_Career_Portfolio.pdf"','Cache-Control':'private, no-store'})

@app.get('/graduate-opportunities')
def graduate_opportunities(request:Request):
 gate=student_gate(request)
 if gate:return gate
 user=get_user(request)
 st=course_state(user['id'])
 graduated=bool(st['certificate'])
 with db() as c:
  items=c.execute("SELECT * FROM career_opportunities WHERE active=1 AND (deadline IS NULL OR deadline='' OR deadline>=date('now')) ORDER BY id DESC LIMIT 100").fetchall() if graduated else []
 return page(request,'graduate_opportunities.html',graduated=graduated,st=st,items=items,sources=CAREER_SOURCES)

@app.get('/admin/opportunities')
def manage_opportunities(request:Request):
 gate=admin_gate(request)
 if gate:return gate
 if get_user(request)['role']!='admin':return denied(request,'Administrator access required.',403)
 with db() as c:items=c.execute('SELECT * FROM career_opportunities ORDER BY id DESC LIMIT 100').fetchall()
 return page(request,'admin_opportunities.html',items=items)

@app.post('/admin/opportunities')
def add_opportunity(request:Request,csrf:str=Form(''),title:str=Form(''),organization:str=Form(''),location:str=Form(''),work_type:str=Form(''),url:str=Form(''),note:str=Form(''),deadline:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if get_user(request)['role']!='admin':return denied(request,'Administrator access required.',403)
 if not valid_token(request,csrf):return denied(request)
 title=title.strip();organization=organization.strip();url=url.strip();deadline=deadline.strip()
 if not 4<=len(title)<=150 or not 2<=len(organization)<=120 or len(note)>1800 or len(location)>150 or len(work_type)>80 or not re.fullmatch(r'https://[^\s<>"]{6,550}',url) or (deadline and not re.fullmatch(r'\d{4}-\d{2}-\d{2}',deadline)):
  return denied(request,'Provide a legitimate job title, organization, HTTPS job link, and optional YYYY-MM-DD closing date.')
 if deadline:
  try:datetime.strptime(deadline,'%Y-%m-%d')
  except ValueError:return denied(request,'Use a valid closing date.')
 with db() as c:c.execute('INSERT INTO career_opportunities(title,organization,location,work_type,url,note,deadline) VALUES (?,?,?,?,?,?,?)',(title,organization,location.strip() or 'See listing',work_type.strip() or 'See listing',url,note.strip(),deadline or None))
 log(get_user(request)['id'],'career_opportunity_published',None,title)
 return redirect('/admin/opportunities')

@app.post('/admin/opportunities/{opportunity_id}/disable')
def disable_opportunity(request:Request,opportunity_id:int,csrf:str=Form('')):
 gate=admin_gate(request)
 if gate:return gate
 if get_user(request)['role']!='admin':return denied(request,'Administrator access required.',403)
 if not valid_token(request,csrf):return denied(request)
 with db() as c:c.execute('UPDATE career_opportunities SET active=0 WHERE id=?',(opportunity_id,))
 log(get_user(request)['id'],'career_opportunity_archived',None,str(opportunity_id))
 return redirect('/admin/opportunities')

@app.get('/admin/analytics')
def admin_analytics(request:Request):
 gate=admin_gate(request)
 if gate:return gate
 if get_user(request)['role']!='admin':return denied(request,'Administrator access required.',403)
 with db() as c:
  pages=c.execute("SELECT path,SUM(hits) AS views FROM public_pageviews WHERE day>=date('now','-29 days') GROUP BY path ORDER BY views DESC").fetchall()
  days=c.execute("SELECT day,SUM(hits) AS views FROM public_pageviews WHERE day>=date('now','-29 days') GROUP BY day ORDER BY day DESC").fetchall()
 return page(request,'admin_analytics.html',pages=pages,days=days,total=sum(row['views'] for row in pages))

@app.get('/robots.txt')
def robots():
 return Response('User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /dashboard\nDisallow: /lesson/\nDisallow: /career/\nDisallow: /graduate-opportunities\nDisallow: /journal\nDisallow: /certificate\nSitemap: '+BASE_URL+'/sitemap.xml\n',media_type='text/plain')

@app.get('/sitemap.xml')
def sitemap():
 paths=['/','/about','/curriculum','/career-information','/apply']
 payload='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+xml_escape(BASE_URL+path)+'</loc></url>' for path in paths)+'</urlset>'
 return Response(payload,media_type='application/xml')

@app.get('/health')
def health():return {'status':'ok','product':'IAM Academy','modules':10,'core_lessons':len(LESSONS),'applied_modules':2}

if __name__=='__main__':
 import uvicorn
 uvicorn.run('app:app',host='127.0.0.1',port=int(os.getenv('PORT','8000')),reload=False)
