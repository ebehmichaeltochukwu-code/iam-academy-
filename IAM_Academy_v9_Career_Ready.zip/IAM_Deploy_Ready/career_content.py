"""IAM-owned practice briefs and curated third-party discovery resources.
External resource URLs checked 2026-10-17. Videos remain owned by the uploaders.
"""
PORTFOLIO = [
    dict(week=1, title='Artist discovery and ethical representation brief', file='01_artist_audit.txt',
         purpose='Evaluate a prospective artist without making promises or claiming rights you do not hold.',
         deliverable='Two-page artist audit, 10-question discovery interview, decision-rights matrix and 30-day onboarding checklist.',
         sections=[('The artist and goals','Describe a fictional artist or a consenting real artist: genre, hometown, catalogue, three clear career goals and the evidence available.'),('Evidence audit','List songs, ownership documentation, collaborators, live history, audience metrics and current contracts. Mark unknown facts as UNVERIFIED.'),('Responsibilities','Identify what the artist decides, what the manager coordinates, and when a lawyer or accountant must advise.'),('30-day action plan','Write five priority actions with owners, dates, risks and success indicators.')],
         checklist=['Ground claims in verifiable evidence','Respect artist consent and confidential information','Do not provide legal advice','List accountable owners and dates']),
    dict(week=2,title='Music listening and creative feedback report',file='02_song_review.txt',
         purpose='Make a constructive, artist-centred assessment of one song, not a personal taste review.',
         deliverable='Song structure map, three strengths, two measurable tests and a supportive feedback script.',
         sections=[('Song observations','List timings for intro, verse, hook, bridge and outro of an artist-approved or fictional song.'),('Audience and identity','Who is the intended listener? Explain why the track fits or challenges the artist identity.'),('Feedback script','Use observation, likely impact, proposed test and artist choice. Avoid ultimatums.'),('Evidence of improvement','Suggest an A/B listener test and define how you will judge the result.')],
         checklist=['Respect creative ownership','Use evidence rather than insults','Propose practical A/B testing','Get artist approval']),
    dict(week=3,title='Manager communication and crisis-response kit',file='03_communication_kit.txt',
         purpose='Handle professional conflict without harming relationships or public trust.',
         deliverable='Decision log, disagreement script, team responsibility map and one-page incident response plan.',
         sections=[('Shared objective','Describe the dispute, the artist priorities and why it needs a decision.'),('Private conversation','Write a respectful 200-word manager–artist discussion using listening and options.'),('Escalation table','State when a lawyer, production manager, safeguarding lead or publicist must be contacted.'),('Incident response','Draft a first-hour checklist prioritizing safety and verified facts.')],
         checklist=['Listen before deciding','Do not disclose private information','Escalate safety risks promptly','Document decisions with consent']),
    dict(week=4,title='Music rights and royalty readiness checklist',file='04_rights_checklist.txt',
         purpose='Map common rights questions and recognize when legal expertise is needed.',
         deliverable='Rights inventory and checklist for master recordings, compositions, splits and distribution.',
         sections=[('Work and collaborators','List a hypothetical single: songwriters, producers, performers, release name and identifiers.'),('Rights mapping','Separate composition, sound recording, publishing, master ownership and distribution permissions.'),('Royalty pathways','Describe potential collection channels, territories and what remains to verify.'),('Questions for counsel','Write five questions to send to a qualified Nigerian entertainment lawyer.')],
         checklist=['Do not assume ownership','Capture written split confirmations','Distinguish master from composition','Refer binding legal advice to counsel']),
    dict(week=5,title='Audience and six-week release marketing plan',file='05_release_campaign.txt',
         purpose='Design an ethical, measurable campaign for an emerging artist.',
         deliverable='Audience persona, channel calendar, modest budget, asset list and reporting dashboard.',
         sections=[('Audience research','Define one listener segment and identify qualitative and quantitative evidence.'),('Six-week calendar','List pre-release, launch and follow-up actions by week and owner.'),('Budget','Include creative, distribution, promotion, contingency and measurement costs with totals.'),('Metrics and review','Specify saves, engaged fans, video retention, email signups and qualitative feedback.')],
         checklist=['Use clear consent for fan outreach','Do not buy fake streams','Specify budget ceilings','Review outcomes weekly']),
    dict(week=6,title='Live show and business budget workbook',file='06_budget_and_live.txt',
         purpose='Build basic financial discipline for one event or release.',
         deliverable='Itemized income/expense forecast, cash-flow dates, contracts checklist and post-show reconciliation.',
         sections=[('Show assumptions','Venue, audience size, ticket assumptions, travel and artist constraints.'),('Financial forecast','Show tickets, fees, sponsorships, promoter splits, transport, lodging, production and contingency.'),('Cash controls','Explain who can approve, spend, reconcile and access funds.'),('Risks and reporting','Model a low-attendance scenario and agree a break-even decision.')],
         checklist=['Keep receipts','Do not mix personal funds','Use clear approval thresholds','Test worst-case cash flow']),
    dict(week=7,title='Partnership evaluation and 12-month career roadmap',file='07_partnership_roadmap.txt',
         purpose='Compare offers and prioritize sustainable career development over hype.',
         deliverable='Partnership scorecard, risk register, professional team map and four-quarter career roadmap.',
         sections=[('Offer comparison','Compare two fictional partnerships on cash timing, rights, duration, exclusivity and termination.'),('Decision framework','Set six weighted criteria and explain why you chose them.'),('Career goals','Draft realistic quarterly targets for catalogue, audience, live, income and wellbeing.'),('Review ritual','Describe a monthly check-in and exit/renegotiation triggers.')],
         checklist=['Consider rights and future cost','Avoid guaranteed outcomes','Include wellbeing and rest','Document decisions']),
    dict(week=8,title='Professional artist-management capstone dossier',file='08_90_day_capstone.txt',
         purpose='Demonstrate career-ready judgement with an integrated 90-day management plan.',
         deliverable='Artist audit, 90-day roadmap, campaign, rights checklist, budget, risk register and decision record.',
         sections=[('Executive brief','Write the artist profile, why this strategy fits and three measurable goals.'),('90-day plan','Provide a timeline with owners, milestones, dependencies and revision points.'),('Working documents','Attach or paste the audit, budget, risk register, marketing plan and roles matrix.'),('Ethical decision memo','Present one difficult decision, alternatives considered and rationale.'),('Personal career pitch','Write a 100-word pitch for an entry-level artist-management or artist-services role.')],
         checklist=['Integrates at least four earlier portfolio artifacts','Measurable 90-day milestones','Accounts for finances, rights and risk','Clear writing and informed consent'])
]

# Distinct videos below were confirmed by public YouTube search, not fabricated.
SUPPLEMENTARY_VIDEOS = [
 dict(id='g4XcSnJQd78', title='Your Guide to Spotify for Artists', source='Spotify for Artists', focus='Audience development and reporting'),
 dict(id='Dwo42-7Xjis', title='How to Pitch to Playlists', source='Spotify for Artists', focus='Release pitching and promotion'),
 dict(id='FmqifH4Ai9M', title='How to Use Analytics for Artists', source='YouTube Creators', focus='Understanding audience and content performance'),
 dict(id='4Q3s4ZyIKpM', title='The ULTIMATE Guide to Spotify for Artists', source='Andrew Southworth', focus='Hands-on artist analytics workflow'),
]
# Each module gets context-specific supplementary material. These are not IAM-owned.
MODULE_VIDEO_IDS = {
 1:['g4XcSnJQd78'],2:['FmqifH4Ai9M'],3:['g4XcSnJQd78'],4:['FmqifH4Ai9M'],
 5:['Dwo42-7Xjis','FmqifH4Ai9M'],6:['g4XcSnJQd78','4Q3s4ZyIKpM'],
 7:['4Q3s4ZyIKpM','Dwo42-7Xjis'],8:['g4XcSnJQd78','Dwo42-7Xjis','FmqifH4Ai9M']}
VIDEOS_BY_ID={v['id']:v for v in SUPPLEMENTARY_VIDEOS}

# Verified job discovery destinations; pages list changing external vacancies, NOT current IAM-posted offers.
CAREER_SOURCES = [
 dict(name='Music Business Worldwide Jobs',url='https://www.musicbusinessworldwide.com/jobs/',summary='Music labels, management, artist services, marketing and publishing roles worldwide.'),
 dict(name='Sony Music Careers',url='https://careers.sonymusic.com/',summary='Search Sony Music roles and check location/visa requirements.'),
 dict(name='Warner Music Group Careers',url='https://www.wmg.com/careers',summary='Global music roles including early-career routes and related teams.'),
 dict(name='Spotify Careers',url='https://www.spotifyjobs.com/',summary='Audio industry careers including creator, marketing, data and business operations.'),
]
CAREER_STEPS=[
 ('Build a one-page career CV','Highlight your IAM portfolio, professional judgement, tools and measurable results; do not invent experience.'),
 ('Create a 90-second introduction','Say who you help, the evidence in your portfolio and what you would contribute to a manager or label.'),
 ('Prepare two role-specific applications','Tailor a cover email and selection criteria to artist services, junior management, label operations or marketing.'),
 ('Research prospective employers','Create an evidence-based list of ten Nigerian labels, talent agencies or independent managers, with contacts obtained ethically.'),
 ('Track outreach and responses','Record where you applied, follow-up dates and interview reflections; avoid mass-spam or misleading representation.'),
]
