import sqlite3
from fastapi.testclient import TestClient
import app as iam
from iam_ai_library import allowed_url,normalise_article,public_library,VIDEO_LIBRARY
from bs4 import BeautifulSoup

CONTENT=dict(title='Publishing Administration Explained',guidance='For rights administration, managers must verify territories, earnings statements, songwriter ownership, contractual terms, data accuracy, and collection responsibilities before promising any payments.',exercise='Prepare an annotated checklist identifying four earnings categories and two missing rights metadata fields.',keywords='publishing, rights, royalties',source_name='WIPO',source_url='https://www.wipo.int/en/web/copyright/',jurisdiction='Nigeria',module=8,status='draft')

def test_public_library_and_source_provenance(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-ai-test.db');iam.init_db()
 client=TestClient(iam.app)
 response=client.get('/api/iam-ai/library')
 assert response.status_code==200
 assert response.headers.get('cache-control')=='no-store'
 body=response.json()
 assert len(body['topics'])>=41 and len(body['sources'])>=25
 assert len([s for s in body['sources'] if s.get('youtube_id')])>=3
 assert all(s['url'].startswith('https://') for s in body['sources'])
 with iam.db() as c:
  c.execute('INSERT INTO iam_knowledge_articles (title,guidance,exercise,keywords,source_name,source_url,jurisdiction,module,status) VALUES (:title,:guidance,:exercise,:keywords,:source_name,:source_url,:jurisdiction,:module,:status)',CONTENT)
  assert len(public_library(c)['topics'])==len(body['topics'])
  c.execute("UPDATE iam_knowledge_articles SET status='published' WHERE id=1")
 published=client.get('/api/iam-ai/library').json()
 assert len(published['topics'])==len(body['topics'])+1
 assert 'Publishing Administration Explained' in [x['title'] for x in published['topics']]
 assert 'https://www.wipo.int/en/web/copyright/' in [x['url'] for x in published['sources']]
 with iam.db() as c:c.execute("UPDATE iam_knowledge_articles SET status='withdrawn' WHERE id=1")
 assert len(client.get('/api/iam-ai/library').json()['topics'])==len(body['topics'])

def test_admin_editor_requires_login_and_csrf(tmp_path,monkeypatch):
 monkeypatch.setattr(iam,'DB_PATH',tmp_path/'iam-ai-admin.db');iam.init_db()
 client=TestClient(iam.app)
 assert client.get('/admin/iam-ai',follow_redirects=False).status_code==303
 assert client.post('/admin/iam-ai/article',data=CONTENT,follow_redirects=False).status_code==303
 with iam.db() as c:assert c.execute('SELECT count(*) FROM iam_knowledge_articles').fetchone()[0]==0

def test_article_validation_and_safe_urls():
 assert normalise_article(CONTENT)['status']=='draft'
 assert allowed_url('https://www.wipo.int/en/web/copyright/')
 assert not allowed_url('javascript:alert(1)')
 assert not allowed_url('http://localhost:8080/')
 for param, bad in [('guidance','tiny'),('source_url','file:///etc/passwd'),('module',11),('status','reviewed')]:
  altered=dict(CONTENT,**{param:bad})
  try:normalise_article(altered)
  except ValueError:continue
  raise AssertionError(f'Should reject {param}')

def test_frontend_has_opt_in_features():
 from pathlib import Path
 root=Path(__file__).parents[1]
 js=(root/'static/iam-ai-v16.js').read_text()
 assert 'CreateMLCEngine' in js
 assert 'automatic-speech-recognition' in js
 assert 'youtube-nocookie.com/embed/' in js
 assert "@mlc-ai/web-llm" in js
 assert 'speechSynthesis' in js
 assert 'localStorage' in js
 assert not any(x in js for x in ['api.openai.com','api.anthropic.com','generativelanguage.googleapis.com'])
